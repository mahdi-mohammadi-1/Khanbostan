$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$BackendEnv = Join-Path $Root 'backend\.env'
$FrontendEnv = Join-Path $Root 'frontend\.env'

function Escape-DotEnvValue([string]$Value) {
    if ($null -eq $Value) { return '' }
    return '"' + ($Value -replace '\\', '\\\\' -replace '"', '\\"') + '"'
}

Write-Host '== Khan Boostan local configuration ==' -ForegroundColor Cyan
Write-Host 'Press Enter to keep the value shown in brackets.' -ForegroundColor DarkGray

$dbHost = Read-Host 'MySQL host [127.0.0.1]'; if ([string]::IsNullOrWhiteSpace($dbHost)) { $dbHost='127.0.0.1' }
$dbPort = Read-Host 'MySQL port [3306]'; if ([string]::IsNullOrWhiteSpace($dbPort)) { $dbPort='3306' }
$dbName = Read-Host 'Database name [khanboostan]'; if ([string]::IsNullOrWhiteSpace($dbName)) { $dbName='khanboostan' }
$dbUser = Read-Host 'MySQL username [root]'; if ([string]::IsNullOrWhiteSpace($dbUser)) { $dbUser='root' }
$dbPassSecure = Read-Host 'MySQL password [blank for XAMPP default]' -AsSecureString
$dbPass = [System.Net.NetworkCredential]::new('', $dbPassSecure).Password

$adminEmail = Read-Host 'Admin email [admin@khanboostan.local]'; if ([string]::IsNullOrWhiteSpace($adminEmail)) { $adminEmail='admin@khanboostan.local' }
$adminPassSecure = Read-Host 'Admin password [KhanBoostan@2026]' -AsSecureString
$adminPass = [System.Net.NetworkCredential]::new('', $adminPassSecure).Password
if ([string]::IsNullOrWhiteSpace($adminPass)) { $adminPass='KhanBoostan@2026' }

$envText = Get-Content $BackendEnv -Raw
$replacements = @{
    'DB_HOST'=$dbHost; 'DB_PORT'=$dbPort; 'DB_DATABASE'=$dbName; 'DB_USERNAME'=$dbUser;
    'DB_PASSWORD'=$dbPass; 'ADMIN_EMAIL'=$adminEmail; 'ADMIN_PASSWORD'=$adminPass
}
foreach ($key in $replacements.Keys) {
    $value = Escape-DotEnvValue ([string]$replacements[$key])
    $pattern = '(?m)^' + [regex]::Escape($key) + '=.*$'
    $envText = [regex]::Replace($envText, $pattern, "$key=$value")
}
[System.IO.File]::WriteAllText($BackendEnv, $envText, [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText($FrontendEnv, "VITE_API_URL=http://127.0.0.1:8000/api`n", [System.Text.UTF8Encoding]::new($false))

Write-Host 'Environment files updated.' -ForegroundColor Green
