<?php

namespace Database\Seeders;

use App\Models\ContentItem;
use Illuminate\Database\Seeder;

class ContentSeeder extends Seeder
{
    public function run(): void
    {
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'home'], [
            'title' => 'Home',
            'data' => [
                'label' => 'Home',
                'to' => '/'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'about-us'], [
            'title' => 'About Us',
            'data' => [
                'label' => 'About Us',
                'to' => '/about'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'products'], [
            'title' => 'Products',
            'data' => [
                'label' => 'Products',
                'to' => '/products',
                'mega' => 'products'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'services'], [
            'title' => 'Services',
            'data' => [
                'label' => 'Services',
                'to' => '/services',
                'mega' => 'services'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'markets'], [
            'title' => 'Markets',
            'data' => [
                'label' => 'Markets',
                'to' => '/markets',
                'mega' => 'markets'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'company'], [
            'title' => 'Company',
            'data' => [
                'label' => 'Company',
                'mega' => 'company'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'nav', 'slug' => 'contact'], [
            'title' => 'Contact',
            'data' => [
                'label' => 'Contact',
                'to' => '/contact'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'agricultural'], [
            'title' => 'Agricultural Products',
            'data' => [
                'image' => '/img/grain-1.jpg',
                'blurb' => 'Grains, oilseeds and field crops sourced from trusted producers.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'food'], [
            'title' => 'Food Products',
            'data' => [
                'image' => '/img/saffron.jpg',
                'blurb' => 'Rice, sugar, dried fruits, nuts and premium spices.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'construction'], [
            'title' => 'Construction Materials',
            'data' => [
                'image' => '/img/construction-1.jpg',
                'blurb' => 'Cement, steel, marble and building materials.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'energy'], [
            'title' => 'Energy Products',
            'data' => [
                'image' => '/img/refinery-1.jpg',
                'blurb' => 'Fuel oils, coal and refined petroleum products.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'industrial'], [
            'title' => 'Industrial Products',
            'data' => [
                'image' => '/img/refinery-2.jpg',
                'blurb' => 'Intermediate goods and industrial consumables.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'raw'], [
            'title' => 'Raw Materials',
            'data' => [
                'image' => '/img/marble.jpg',
                'blurb' => 'Fertilizers, minerals and primary raw materials.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'machinery'], [
            'title' => 'Machinery & Equipment',
            'data' => [
                'image' => '/img/warehouse-1.jpg',
                'blurb' => 'Industrial machinery, equipment and spare parts.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'category', 'slug' => 'consumer'], [
            'title' => 'Consumer Products',
            'data' => [
                'image' => '/img/containers-1.jpg',
                'blurb' => 'Fast-moving consumer and household goods.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 7,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'milling-wheat'], [
            'title' => 'Milling Wheat Grain',
            'data' => [
                'category' => 'agricultural',
                'image' => '/img/grain-1.jpg',
                'blurb' => 'High-quality milling wheat for flour production, sourced from regional producers with consistent moisture and protein control.',
                'origin' => 'Afghanistan / Central Asia',
                'grade' => 'Milling grade — spec. on request',
                'packaging' => 'Bulk / 50 kg bags',
                'moq' => 'One 20ft container (approx. 25 MT)',
                'hsCode' => '1001.19',
                'incoterms' => 'FOB · CIF · EXW',
                'leadTime' => '2 – 6 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'cotton-fiber'], [
            'title' => 'Cotton Fiber',
            'data' => [
                'category' => 'agricultural',
                'image' => '/img/cotton.jpg',
                'blurb' => 'Raw cotton fiber for textile spinning mills, available in standard grades with documented quality parameters.',
                'origin' => 'Afghanistan / Central Asia',
                'grade' => 'Staple length & micronaire on request',
                'packaging' => 'High-density bales',
                'moq' => 'One 20ft container (approx. 10 MT)',
                'hsCode' => '5201.00',
                'incoterms' => 'FOB · CIF',
                'leadTime' => '3 – 6 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'long-grain-rice'], [
            'title' => 'Long-Grain Rice',
            'data' => [
                'category' => 'food',
                'image' => '/img/grain-2.jpg',
                'blurb' => 'Premium long-grain rice for wholesale and retail distribution, available in multiple packaging formats.',
                'origin' => 'Regional origins',
                'grade' => '5% / 15% broken — on request',
                'packaging' => '10 / 25 / 50 kg bags',
                'moq' => 'One 20ft container (approx. 26 MT)',
                'hsCode' => '1006.30',
                'incoterms' => 'FOB · CIF',
                'leadTime' => '2 – 5 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'dried-fruits-nuts'], [
            'title' => 'Dried Fruits & Nuts',
            'data' => [
                'category' => 'food',
                'image' => '/img/dryfruits.jpg',
                'blurb' => 'Raisins, almonds, pistachios, apricots and mixed dried fruit lines for export and regional distribution.',
                'origin' => 'Afghanistan',
                'grade' => 'Export grade — spec. on request',
                'packaging' => 'Cartons / bulk vacuum packs',
                'moq' => 'On request (mixed-load available)',
                'hsCode' => '0813.40',
                'incoterms' => 'FOB · EXW',
                'leadTime' => '2 – 4 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'saffron'], [
            'title' => 'Saffron (Crocus Sativus)',
            'data' => [
                'category' => 'food',
                'image' => '/img/saffron.jpg',
                'blurb' => 'Premium saffron threads for international buyers, handled with full traceability documentation.',
                'origin' => 'Afghanistan',
                'grade' => 'Category I — lab report on request',
                'packaging' => '1g – 1kg sealed packs',
                'moq' => '1 kg',
                'hsCode' => '0910.20',
                'incoterms' => 'FOB · EXW',
                'leadTime' => '1 – 3 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'portland-cement'], [
            'title' => 'Portland Cement',
            'data' => [
                'category' => 'construction',
                'image' => '/img/construction-1.jpg',
                'blurb' => 'OPC and composite cement for construction projects, supplied in bulk, jumbo bags or standard bags.',
                'origin' => 'Regional origins',
                'grade' => 'Type I / Type II — EN & ASTM ref.',
                'packaging' => 'Bulk / 50 kg bags / jumbo bags',
                'moq' => 'One 20ft container or bulk truck load',
                'hsCode' => '2523.29',
                'incoterms' => 'FOB · CIF · CPT',
                'leadTime' => '2 – 4 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'steel-rebar'], [
            'title' => 'Steel Rebar (Deformed Bars)',
            'data' => [
                'category' => 'construction',
                'image' => '/img/construction-2.jpg',
                'blurb' => 'Deformed reinforcing steel bars in standard diameters for infrastructure and building projects.',
                'origin' => 'Regional origins',
                'grade' => 'B500B / ASTM A615 equivalent',
                'packaging' => 'Bundles',
                'moq' => 'One 20ft container (approx. 25 MT)',
                'hsCode' => '7214.20',
                'incoterms' => 'FOB · CIF',
                'leadTime' => '3 – 6 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'marble-blocks'], [
            'title' => 'Marble & Natural Stone',
            'data' => [
                'category' => 'construction',
                'image' => '/img/marble.jpg',
                'blurb' => 'Marble blocks and slabs in Afghan and regional varieties for export to international stone markets.',
                'origin' => 'Afghanistan',
                'grade' => 'Commercial / premium selection',
                'packaging' => 'Containerized — block / slab',
                'moq' => 'One 20ft container',
                'hsCode' => '2515.12',
                'incoterms' => 'FOB · CIF',
                'leadTime' => '3 – 8 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 7,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'petroleum-products'], [
            'title' => 'Petroleum Products (Fuel Oils)',
            'data' => [
                'category' => 'energy',
                'image' => '/img/refinery-1.jpg',
                'blurb' => 'Diesel, gasoline, fuel oil and related refined products supplied against confirmed specifications.',
                'origin' => 'Regional refineries',
                'grade' => 'Spec. sheet on request',
                'packaging' => 'Bulk / tanker lots',
                'moq' => 'Tanker lot — on request',
                'hsCode' => '2710.19',
                'incoterms' => 'FOB · CIF · DAP',
                'leadTime' => '4 – 8 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 8,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'coal'], [
            'title' => 'Steam & Coking Coal',
            'data' => [
                'category' => 'energy',
                'image' => '/img/coal.jpg',
                'blurb' => 'Thermal and metallurgical coal for power generation and industrial use, with calorific value reporting.',
                'origin' => 'Afghanistan / Central Asia',
                'grade' => 'CV & ash spec. on request',
                'packaging' => 'Bulk / rail / truck lots',
                'moq' => 'Bulk lot — on request',
                'hsCode' => '2701.12',
                'incoterms' => 'FOB · CPT',
                'leadTime' => '3 – 6 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 9,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'white-sugar'], [
            'title' => 'White Sugar (ICUMSA)',
            'data' => [
                'category' => 'food',
                'image' => '/img/sugar.jpg',
                'blurb' => 'Refined white sugar for industrial and retail packaging lines, supplied to ICUMSA specifications.',
                'origin' => 'Regional refineries',
                'grade' => 'ICUMSA 45 — on request',
                'packaging' => '50 kg bags / 1 MT jumbo bags',
                'moq' => 'One 20ft container (approx. 26 MT)',
                'hsCode' => '1701.99',
                'incoterms' => 'FOB · CIF',
                'leadTime' => '3 – 6 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 10,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'fertilizers'], [
            'title' => 'Fertilizers (Urea & DAP)',
            'data' => [
                'category' => 'raw',
                'image' => '/img/containers-2.jpg',
                'blurb' => 'Urea, DAP and compound fertilizers for the agriculture sector, sourced from certified producers.',
                'origin' => 'Regional origins',
                'grade' => '46% N urea / 18-46-0 DAP',
                'packaging' => '50 kg bags / bulk',
                'moq' => 'Bulk lot — on request',
                'hsCode' => '3102.10',
                'incoterms' => 'FOB · CIF · CPT',
                'leadTime' => '3 – 6 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 11,
        ]);
        ContentItem::updateOrCreate(['type' => 'product', 'slug' => 'industrial-machinery'], [
            'title' => 'Industrial Machinery & Equipment',
            'data' => [
                'category' => 'machinery',
                'image' => '/img/warehouse-1.jpg',
                'blurb' => 'Industrial machinery, production lines, equipment and spare parts procured to buyer specifications.',
                'origin' => 'International origins',
                'grade' => 'Per buyer specification',
                'packaging' => 'Export crating',
                'moq' => 'Project-based',
                'hsCode' => '8479.89',
                'incoterms' => 'FOB · CIF · DAP',
                'leadTime' => '6 – 12 weeks from confirmation'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 12,
        ]);
        ContentItem::updateOrCreate(['type' => 'service', 'slug' => 'import'], [
            'title' => 'Import',
            'data' => [
                'icon' => 'Ship',
                'route' => '/services/import',
                'oneLiner' => 'Bringing goods into the market — sourced, verified and delivered.',
                'blurb' => 'We manage the complete import cycle: international sourcing, supplier verification, purchase coordination, shipping, customs and warehousing — so goods arrive reliably and compliantly.',
                'features' => [
                    'International sourcing',
                    'Supplier identification & verification',
                    'Price negotiation & purchase coordination',
                    'Shipping & freight coordination',
                    'Customs coordination & clearance',
                    'Warehousing & distribution'
                ],
                'steps' => [
                    [
                        't' => 'Requirement & Specification',
                        'd' => 'We define the product, specification, quantity and destination with you.'
                    ],
                    [
                        't' => 'Supplier Identification',
                        'd' => 'We shortlist qualified suppliers in the right origins.'
                    ],
                    [
                        't' => 'Verification & Due Diligence',
                        'd' => 'We check supplier credentials, capacity and documentation.'
                    ],
                    [
                        't' => 'Negotiation & Purchase',
                        'd' => 'We negotiate terms and place the purchase on your behalf.'
                    ],
                    [
                        't' => 'Shipping & Customs',
                        'd' => 'We coordinate freight, documentation and clearance.'
                    ],
                    [
                        't' => 'Warehousing & Distribution',
                        'd' => 'Goods are received, stored and distributed to the final point.'
                    ]
                ],
                'image' => '/img/ship-sunrise.jpg'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'service', 'slug' => 'export'], [
            'title' => 'Export',
            'data' => [
                'icon' => 'PackageSearch',
                'route' => '/services/export',
                'oneLiner' => 'Taking Afghan and regional products to international markets.',
                'blurb' => 'From product sourcing and quality control to export documentation, customs procedures and international delivery — we build reliable export channels for local producers.',
                'features' => [
                    'Product sourcing & consolidation',
                    'Quality control & inspection',
                    'Export-grade packaging',
                    'Export documentation',
                    'Customs procedures',
                    'Transportation & international delivery'
                ],
                'steps' => [
                    [
                        't' => 'Product Sourcing',
                        'd' => 'We source and consolidate the right product quality and volume.'
                    ],
                    [
                        't' => 'Quality Control',
                        'd' => 'Inspection and grading against the buyer specification.'
                    ],
                    [
                        't' => 'Packaging',
                        'd' => 'Export-grade packaging and labeling prepared.'
                    ],
                    [
                        't' => 'Export Documentation',
                        'd' => 'Commercial, customs and shipping documents issued.'
                    ],
                    [
                        't' => 'Customs & Clearance',
                        'd' => 'Export clearance at origin handled end to end.'
                    ],
                    [
                        't' => 'Transportation & Delivery',
                        'd' => 'International freight and delivery to the buyer.'
                    ]
                ],
                'image' => '/img/containers-2.jpg'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'service', 'slug' => 'trading'], [
            'title' => 'International Trading',
            'data' => [
                'icon' => 'Globe2',
                'route' => '/services',
                'oneLiner' => 'Structured buy–sell transactions across markets.',
                'blurb' => 'We act as a principal trading counterparty for commodities and goods, structuring transactions, documentation and payment flows between buyers and suppliers.',
                'features' => [
                    'Commodity & goods trading',
                    'Transaction structuring',
                    'Trade documentation',
                    'Payment & terms coordination',
                    'Market research & pricing',
                    'Commercial representation'
                ],
                'steps' => [],
                'image' => '/img/meeting-1.jpg'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'service', 'slug' => 'sourcing'], [
            'title' => 'Sourcing',
            'data' => [
                'icon' => 'SearchCheck',
                'route' => '/services/sourcing',
                'oneLiner' => 'We find, verify and secure the right suppliers for you.',
                'blurb' => 'A professional sourcing service for buyers who need reliable suppliers without the risk of the unknown — research, verification, negotiation and quality review, all handled for you.',
                'features' => [
                    'Customer requirement analysis',
                    'Market research',
                    'Supplier identification',
                    'Supplier verification',
                    'Price negotiation',
                    'Quality review',
                    'Purchase management',
                    'Logistics to destination'
                ],
                'steps' => [
                    [
                        't' => 'Customer Requirement',
                        'd' => 'We document exactly what you need.'
                    ],
                    [
                        't' => 'Market Research',
                        'd' => 'We map origins, suppliers and price ranges.'
                    ],
                    [
                        't' => 'Supplier Identification',
                        'd' => 'We shortlist the most suitable candidates.'
                    ],
                    [
                        't' => 'Supplier Verification',
                        'd' => 'Credentials, references and capacity checked.'
                    ],
                    [
                        't' => 'Price Negotiation',
                        'd' => 'We negotiate commercial terms on your behalf.'
                    ],
                    [
                        't' => 'Quality Review',
                        'd' => 'Samples, specs and quality are confirmed.'
                    ],
                    [
                        't' => 'Purchase',
                        'd' => 'The order is placed with agreed terms.'
                    ],
                    [
                        't' => 'Logistics',
                        'd' => 'Freight, customs and documentation coordinated.'
                    ],
                    [
                        't' => 'Delivery',
                        'd' => 'Goods delivered to your destination.'
                    ]
                ],
                'image' => '/img/warehouse-2.jpg'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'service', 'slug' => 'procurement'], [
            'title' => 'Procurement',
            'data' => [
                'icon' => 'FileCheck2',
                'route' => '/services/sourcing',
                'oneLiner' => 'Structured purchasing for businesses and institutions.',
                'blurb' => 'We run professional procurement cycles for companies, projects and institutions — specification, tendering where needed, supplier management and controlled delivery.',
                'features' => [
                    'Specification & requirement planning',
                    'Supplier evaluation',
                    'Comparative offers',
                    'Order management',
                    'Quality & compliance checks',
                    'Delivery & documentation'
                ],
                'steps' => [],
                'image' => '/img/meeting-2.jpg'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'service', 'slug' => 'logistics'], [
            'title' => 'Logistics & Supply Chain',
            'data' => [
                'icon' => 'Truck',
                'route' => '/services/logistics',
                'oneLiner' => 'Moving goods across borders — by road, rail, sea and air.',
                'blurb' => 'Multi-modal logistics coordination across Afghanistan and the region: road, rail, sea and air freight, warehousing, customs coordination and cross-border cargo management.',
                'features' => [
                    'Road transportation',
                    'Rail transportation',
                    'Sea freight',
                    'Air freight',
                    'Warehousing',
                    'Customs coordination',
                    'Cargo handling',
                    'Cross-border logistics'
                ],
                'steps' => [
                    [
                        't' => 'Origin & Consolidation',
                        'd' => 'Cargo is collected and consolidated.'
                    ],
                    [
                        't' => 'Documentation',
                        'd' => 'Transport and customs documents prepared.'
                    ],
                    [
                        't' => 'Border & Customs',
                        'd' => 'Cross-border procedures coordinated.'
                    ],
                    [
                        't' => 'Transit',
                        'd' => 'In-transit tracking and monitoring.'
                    ],
                    [
                        't' => 'Destination',
                        'd' => 'Arrival, customs and handover managed.'
                    ],
                    [
                        't' => 'Distribution',
                        'd' => 'Final-mile delivery where required.'
                    ]
                ],
                'image' => '/img/trucks-1.jpg'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_process', 'slug' => 'inquiry'], [
            'title' => 'Inquiry',
            'data' => [
                'icon' => 'MessageSquareText',
                'desc' => 'You tell us what you need — product, quantity, destination.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_process', 'slug' => 'sourcing'], [
            'title' => 'Sourcing',
            'data' => [
                'icon' => 'SearchCheck',
                'desc' => 'We identify and verify the right suppliers and origins.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_process', 'slug' => 'negotiation'], [
            'title' => 'Negotiation',
            'data' => [
                'icon' => 'Handshake',
                'desc' => 'Commercial terms, pricing and timelines are agreed.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_process', 'slug' => 'quality-documentation'], [
            'title' => 'Quality & Documentation',
            'data' => [
                'icon' => 'FileCheck2',
                'desc' => 'Specifications, quality and paperwork are secured.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_process', 'slug' => 'logistics'], [
            'title' => 'Logistics',
            'data' => [
                'icon' => 'Container',
                'desc' => 'Freight, customs and transit are coordinated.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_process', 'slug' => 'delivery'], [
            'title' => 'Delivery',
            'data' => [
                'icon' => 'MapPinCheck',
                'desc' => 'Goods arrive — on spec, on time, fully documented.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'reliable-trade-partner'], [
            'title' => 'Reliable Trade Partner',
            'data' => [
                'desc' => 'A single accountable counterparty for your import and export operations.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'international-market-access'], [
            'title' => 'International Market Access',
            'data' => [
                'desc' => 'Connections across Central Asia, South Asia, the Middle East and beyond.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'professional-sourcing'], [
            'title' => 'Professional Sourcing',
            'data' => [
                'desc' => 'Verified suppliers and documented product quality.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'supply-chain-coordination'], [
            'title' => 'Supply Chain Coordination',
            'data' => [
                'desc' => 'Multi-modal logistics, customs and documentation managed end to end.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'quality-focus'], [
            'title' => 'Quality Focus',
            'data' => [
                'desc' => 'Specifications, inspection and compliance at every step.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'transparent-communication'], [
            'title' => 'Transparent Communication',
            'data' => [
                'desc' => 'Clear pricing, clear status updates, clear documentation.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'business-to-business-approach'], [
            'title' => 'Business-to-Business Approach',
            'data' => [
                'desc' => 'Built for buyers, suppliers, distributors and institutions.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'why_us', 'slug' => 'customer-oriented-service'], [
            'title' => 'Customer-Oriented Service',
            'data' => [
                'desc' => 'Long-term partnerships, not one-off transactions.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 7,
        ]);
        ContentItem::updateOrCreate(['type' => 'market', 'slug' => 'market-1'], [
            'title' => 'market-1',
            'data' => [
                'region' => 'Central Asia',
                'countries' => [
                    'Uzbekistan',
                    'Tajikistan',
                    'Turkmenistan',
                    'Kazakhstan',
                    'Kyrgyzstan'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'market', 'slug' => 'market-2'], [
            'title' => 'market-2',
            'data' => [
                'region' => 'South Asia',
                'countries' => [
                    'Pakistan',
                    'India'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'market', 'slug' => 'market-3'], [
            'title' => 'market-3',
            'data' => [
                'region' => 'Middle East',
                'countries' => [
                    'UAE',
                    'Iran',
                    'Saudi Arabia',
                    'Qatar'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'market', 'slug' => 'market-4'], [
            'title' => 'market-4',
            'data' => [
                'region' => 'International Markets',
                'countries' => [
                    'China',
                    'Russia',
                    'Türkiye',
                    'Europe & other markets'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);


        ContentItem::updateOrCreate(['type' => 'home_story', 'slug' => 'regional-hub'], [
            'title' => 'Balkh at the Center',
            'data' => [
                'kicker' => 'Regional trade hub',
                'description' => 'Khan Boostan connects Afghan demand with suppliers across neighboring and regional markets.',
                'link' => '/markets',
                'linkLabel' => 'Explore our markets'
            ],
            'translations' => [
                'fa' => ['name' => 'بلخ در مرکز تجارت', 'kicker' => 'مرکز تجارت منطقه‌ای', 'description' => 'خان بوستان تقاضای افغانستان را با تأمین‌کنندگان کشورهای همسایه و بازارهای منطقه‌ای وصل می‌کند.', 'linkLabel' => 'بازارهای ما را ببینید'],
                'ru' => ['name' => 'Балх в центре торговли', 'kicker' => 'Региональный торговый узел', 'description' => 'Khan Boostan соединяет спрос Афганистана с поставщиками соседних стран и региональных рынков.', 'linkLabel' => 'Изучить наши рынки']
            ],
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'home_story', 'slug' => 'source-verify'], [
            'title' => 'Source and Verify',
            'data' => ['kicker' => 'Source & verify', 'description' => 'We identify suitable suppliers, compare commercial terms and verify the requested specification before purchase.', 'link' => '/services/sourcing', 'linkLabel' => 'Explore sourcing'],
            'translations' => [
                'fa' => ['name' => 'یافتن و بررسی تأمین‌کننده', 'kicker' => 'سورسینگ و اعتبارسنجی', 'description' => 'تأمین‌کنندگان مناسب را پیدا می‌کنیم، شرایط تجارتی را مقایسه و مشخصات موردنظر را پیش از خرید بررسی می‌کنیم.', 'linkLabel' => 'خدمات سورسینگ'],
                'ru' => ['name' => 'Поиск и проверка поставщика', 'kicker' => 'Поиск и проверка', 'description' => 'Мы находим подходящих поставщиков, сравниваем коммерческие условия и проверяем требуемую спецификацию до закупки.', 'linkLabel' => 'Поиск поставщиков']
            ],
            'is_active' => true, 'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'home_story', 'slug' => 'procure-consolidate'], [
            'title' => 'Procure and Consolidate',
            'data' => ['kicker' => 'Procure & consolidate', 'description' => 'Purchasing and consolidation are structured around quantity, grade, packaging, timing and final destination.', 'link' => '/products', 'linkLabel' => 'Explore products'],
            'translations' => [
                'fa' => ['name' => 'خرید و تجمیع', 'kicker' => 'تدارکات و تجمیع', 'description' => 'خرید و تجمیع بر اساس مقدار، درجه، بسته‌بندی، زمان‌بندی و مقصد نهایی تنظیم می‌شود.', 'linkLabel' => 'محصولات را ببینید'],
                'ru' => ['name' => 'Закупка и консолидация', 'kicker' => 'Закупка и консолидация', 'description' => 'Закупка и консолидация строятся вокруг объёма, качества, упаковки, сроков и конечного назначения.', 'linkLabel' => 'Каталог продукции']
            ],
            'is_active' => true, 'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'home_story', 'slug' => 'cross-border-movement'], [
            'title' => 'Cross-Border Movement',
            'data' => ['kicker' => 'Move across borders', 'description' => 'Road, rail and multimodal movements are coordinated from origin through border points toward the destination.', 'link' => '/services/logistics', 'linkLabel' => 'Explore logistics'],
            'translations' => [
                'fa' => ['name' => 'انتقال فرامرزی', 'kicker' => 'حرکت میان مرزها', 'description' => 'انتقال جاده‌ای، ریلی و چندوجهی از مبدأ تا گذرگاه‌های مرزی و مقصد هماهنگ می‌شود.', 'linkLabel' => 'خدمات لجستیک'],
                'ru' => ['name' => 'Трансграничное перемещение', 'kicker' => 'Перемещение через границы', 'description' => 'Автомобильные, железнодорожные и мультимодальные перевозки координируются от происхождения через границы до назначения.', 'linkLabel' => 'Логистические услуги']
            ],
            'is_active' => true, 'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'home_story', 'slug' => 'documents-customs'], [
            'title' => 'Documents Before Movement',
            'data' => ['kicker' => 'Documents & customs', 'description' => 'Commercial documents, customs coordination and shipment requirements are checked before cargo advances.', 'link' => '/services', 'linkLabel' => 'View trade services'],
            'translations' => [
                'fa' => ['name' => 'اسناد پیش از حرکت', 'kicker' => 'اسناد و گمرک', 'description' => 'اسناد تجارتی، هماهنگی گمرک و الزامات محموله پیش از ادامه مسیر بررسی می‌شوند.', 'linkLabel' => 'خدمات تجارتی'],
                'ru' => ['name' => 'Документы до отправки', 'kicker' => 'Документы и таможня', 'description' => 'Коммерческие документы, таможенная координация и требования к грузу проверяются до дальнейшего движения.', 'linkLabel' => 'Торговые услуги']
            ],
            'is_active' => true, 'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'home_story', 'slug' => 'delivery-custom-trade'], [
            'title' => 'Delivered for Your Business',
            'data' => ['kicker' => 'Deliver in Afghanistan', 'description' => 'Standard trade services can be combined with dedicated sourcing for customers who need a product outside the standard catalog.', 'link' => '/request-quote', 'linkLabel' => 'Start a trade inquiry'],
            'translations' => [
                'fa' => ['name' => 'تحویل برای کسب‌وکار شما', 'kicker' => 'تحویل در افغانستان', 'description' => 'برای مشتریانی که محصول خارج از کاتالوگ می‌خواهند، خدمات تجارتی با سورسینگ اختصاصی ترکیب می‌شود.', 'linkLabel' => 'درخواست تجارتی را شروع کنید'],
                'ru' => ['name' => 'Доставка для вашего бизнеса', 'kicker' => 'Доставка в Афганистане', 'description' => 'Стандартные торговые услуги можно объединить с индивидуальным поиском для товаров вне основного каталога.', 'linkLabel' => 'Начать торговый запрос']
            ],
            'is_active' => true, 'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_corridor', 'slug' => 'uzbekistan'], [
            'title' => 'Uzbekistan',
            'data' => ['country' => 'Uzbekistan', 'direction' => 'North', 'hub' => 'Hairatan', 'mode' => 'Road / Rail', 'status' => 'regional'],
            'translations' => null, 'is_active' => true, 'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_corridor', 'slug' => 'turkmenistan'], [
            'title' => 'Turkmenistan',
            'data' => ['country' => 'Turkmenistan', 'direction' => 'Northwest', 'mode' => 'Road / Rail', 'status' => 'regional'],
            'translations' => null, 'is_active' => true, 'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_corridor', 'slug' => 'tajikistan'], [
            'title' => 'Tajikistan',
            'data' => ['country' => 'Tajikistan', 'direction' => 'Northeast', 'mode' => 'Road', 'status' => 'regional'],
            'translations' => null, 'is_active' => true, 'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_corridor', 'slug' => 'iran'], [
            'title' => 'Iran',
            'data' => ['country' => 'Iran', 'direction' => 'West', 'mode' => 'Road / Rail', 'status' => 'regional'],
            'translations' => null, 'is_active' => true, 'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_corridor', 'slug' => 'pakistan'], [
            'title' => 'Pakistan',
            'data' => ['country' => 'Pakistan', 'direction' => 'Southeast', 'mode' => 'Road', 'status' => 'regional'],
            'translations' => null, 'is_active' => true, 'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'trade_corridor', 'slug' => 'china'], [
            'title' => 'China',
            'data' => ['country' => 'China', 'direction' => 'East', 'mode' => 'Multimodal', 'status' => 'extended'],
            'translations' => null, 'is_active' => true, 'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'agriculture'], [
            'title' => 'Agriculture',
            'data' => [
                'icon' => 'Wheat',
                'blurb' => 'Grains, oilseeds, fiber crops and fertilizers for the agricultural sector.',
                'related' => [
                    'agricultural',
                    'raw'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'food-beverage'], [
            'title' => 'Food & Beverage',
            'data' => [
                'icon' => 'Salad',
                'blurb' => 'Rice, sugar, edible staples and premium products for food businesses.',
                'related' => [
                    'food'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'energy'], [
            'title' => 'Energy',
            'data' => [
                'icon' => 'Zap',
                'blurb' => 'Fuel oils and energy products for power and industry.',
                'related' => [
                    'energy'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'oil-gas'], [
            'title' => 'Oil & Gas',
            'data' => [
                'icon' => 'Flame',
                'blurb' => 'Refined petroleum products and related supply chains.',
                'related' => [
                    'energy'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'mining'], [
            'title' => 'Mining',
            'data' => [
                'icon' => 'Pickaxe',
                'blurb' => 'Coal, minerals and quarry products for industrial buyers.',
                'related' => [
                    'energy',
                    'raw'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'construction'], [
            'title' => 'Construction',
            'data' => [
                'icon' => 'Building2',
                'blurb' => 'Cement, steel, marble and complete building material packages.',
                'related' => [
                    'construction'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'manufacturing'], [
            'title' => 'Manufacturing',
            'data' => [
                'icon' => 'Factory',
                'blurb' => 'Raw materials, machinery and equipment for production lines.',
                'related' => [
                    'industrial',
                    'machinery',
                    'raw'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'industrial-materials'], [
            'title' => 'Industrial Materials',
            'data' => [
                'icon' => 'Layers',
                'blurb' => 'Intermediate goods and industrial consumables.',
                'related' => [
                    'industrial',
                    'raw'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 7,
        ]);
        ContentItem::updateOrCreate(['type' => 'industry', 'slug' => 'consumer-goods'], [
            'title' => 'Consumer Goods',
            'data' => [
                'icon' => 'ShoppingBasket',
                'blurb' => 'FMCG and household products for distribution networks.',
                'related' => [
                    'consumer',
                    'food'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 8,
        ]);
        ContentItem::updateOrCreate(['type' => 'partner_type', 'slug' => 'suppliers-manufacturers'], [
            'title' => 'Suppliers & Manufacturers',
            'data' => [
                'icon' => 'Factory',
                'desc' => 'Producers and manufacturers we work with internationally.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'partner_type', 'slug' => 'buyers-distributors'], [
            'title' => 'Buyers & Distributors',
            'data' => [
                'icon' => 'Store',
                'desc' => 'Wholesale buyers and distribution partners across markets.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'partner_type', 'slug' => 'logistics-partners'], [
            'title' => 'Logistics Partners',
            'data' => [
                'icon' => 'Truck',
                'desc' => 'Freight forwarders, carriers and warehouse operators.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'partner_type', 'slug' => 'financial-trade-facilitators'], [
            'title' => 'Financial & Trade Facilitators',
            'data' => [
                'icon' => 'Landmark',
                'desc' => 'Banks, insurers and trade facilitation services.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'partner_type', 'slug' => 'strategic-partners'], [
            'title' => 'Strategic Partners',
            'data' => [
                'icon' => 'Handshake',
                'desc' => 'Long-term commercial alliances and joint initiatives.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'certificate', 'slug' => 'trade-license'], [
            'title' => 'Trade License',
            'data' => [
                'date' => '[Date]',
                'number' => '[Number]',
                'status' => 'pending'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'certificate', 'slug' => 'company-registration'], [
            'title' => 'Company Registration',
            'data' => [
                'date' => '[Date]',
                'number' => '[Number]',
                'status' => 'pending'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'certificate', 'slug' => 'chamber-of-commerce-membership'], [
            'title' => 'Chamber of Commerce Membership',
            'data' => [
                'date' => '[Date]',
                'number' => '[Number]',
                'status' => 'pending'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'certificate', 'slug' => 'quality-iso-certificate'], [
            'title' => 'Quality / ISO Certificate',
            'data' => [
                'date' => '[Date]',
                'number' => '[Number]',
                'status' => 'pending'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'certificate', 'slug' => 'product-certificates'], [
            'title' => 'Product Certificates',
            'data' => [
                'date' => '[Date]',
                'number' => '[Number]',
                'status' => 'pending'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'article', 'slug' => 'incoterms-2020-practical-guide'], [
            'title' => 'Understanding Incoterms 2020: A Practical Guide for Importers & Exporters',
            'data' => [
                'category' => 'Trade Guides',
                'date' => '2026-06-18',
                'read' => '6 min read',
                'image' => '/img/containers-2.jpg',
                'featured' => true,
                'excerpt' => 'Incoterms define who pays for what — and who carries the risk — at every stage of an international shipment. A practical walkthrough of the most common terms in regional trade.',
                'body' => [
                    'Incoterms (International Commercial Terms) are published by the International Chamber of Commerce and updated every ten years. The current edition — Incoterms 2020 — defines eleven terms that allocate costs, risks and responsibilities between buyer and seller in international transactions.',
                    'For most commodity and containerized trade in our region, four terms dominate. EXW (Ex Works) places maximum responsibility on the buyer, who collects the goods from the seller premises. FOB (Free On Board) means the seller delivers the goods on board the vessel at the named port — risk transfers at the ship rail. CIF (Cost, Insurance and Freight) adds freight and insurance to the destination port on the seller account, while CPT (Carriage Paid To) extends the seller responsibility to an inland destination.',
                    'Choosing the right term is a commercial decision, not a formality. It determines your insurance exposure, your documentation burden and your customs obligations. A common mistake is agreeing a term without naming the exact place — "FOB Karachi" is a complete term; "FOB" alone is not.',
                    'For buyers new to importing, CIF or CPT is often the safest starting point: the supplier organizes the main carriage. Experienced importers frequently prefer FOB to control freight costs themselves. In any case, the sales contract, the letter of credit (if used) and the shipping documents must all state the same Incoterm — mismatches are among the most frequent causes of payment delays.',
                    'As trade partners, we always confirm Incoterms, port and place names in writing before any commitment, and we are happy to advise customers on the structure that fits their risk profile.'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'article', 'slug' => 'afghanistan-trade-corridors-central-south-asia'], [
            'title' => 'Afghanistan at the Crossroads: Trade Corridors Across Central & South Asia',
            'data' => [
                'category' => 'Market Insights',
                'date' => '2026-05-04',
                'read' => '5 min read',
                'image' => '/img/trucks-1.jpg',
                'featured' => false,
                'excerpt' => 'Afghanistan sits at the intersection of some of the fastest-growing trade corridors in the region. What that means for importers, exporters and logistics planning.',
                'body' => [
                    'Geography has made Afghanistan a natural crossroads: to the north, the Central Asian republics; to the east and south, Pakistan and India; to the west, Iran and the Gulf markets. Each direction has its own infrastructure, its own documentary culture and its own seasonality.',
                    'The northern corridor connects to Uzbekistan, Tajikistan and Turkmenistan — important origins for grains, fertilizers, construction materials and energy products, and an emerging route for Afghan exports such as dried fruits, saffron and minerals.',
                    'To the south, ports such as Karachi offer the main gateway for containerized imports from Asia and beyond, with established road and rail links. Western routes connect through Iran to the Gulf, offering alternative access for petroleum products and re-export markets.',
                    'Corridor choice is rarely obvious. It depends on cargo type, volume, season, documentation and border conditions. Professional traders plan around these variables rather than defaulting to a single route — that flexibility is exactly what a trading partner should provide.',
                    'Our approach is corridor-neutral: we evaluate the options for each shipment and recommend the route that balances cost, speed and reliability for the specific cargo.'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'article', 'slug' => 'professional-sourcing-reduces-risk-b2b'], [
            'title' => 'How Professional Sourcing Reduces Risk for B2B Buyers',
            'data' => [
                'category' => 'Sourcing',
                'date' => '2026-03-22',
                'read' => '4 min read',
                'image' => '/img/warehouse-2.jpg',
                'featured' => false,
                'excerpt' => 'Every international purchase carries risk: wrong quality, unreliable suppliers, hidden costs. Structured sourcing turns those risks into managed, documented steps.',
                'body' => [
                    'The most expensive purchase is often the one that goes wrong. In international trade the costs of failure — substandard quality, late delivery, payment disputes — almost always exceed the savings that motivated the deal.',
                    'Professional sourcing reduces this risk through structure. It starts with a precise requirement: product, specification, quantity, packaging, destination and timeline. Vague requirements produce vague offers.',
                    'The second step is supplier verification. Documents, references, production capacity and trade history are checked before any commitment. Price negotiation follows only when the shortlist is credible — comparing prices between unverified suppliers is meaningless.',
                    'Quality review closes the loop before purchase: samples, specification sheets and inspection arrangements are agreed in writing. Finally, logistics and documentation are planned so that goods and papers arrive together.',
                    'None of these steps is complicated. What matters is that they are followed in order and in writing — which is the discipline a professional sourcing partner brings to every transaction.'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'article', 'slug' => 'multi-modal-logistics-afghanistan-importers'], [
            'title' => 'Road, Rail, Sea or Air? Choosing the Right Mode for Your Cargo',
            'data' => [
                'category' => 'Logistics',
                'date' => '2026-02-10',
                'read' => '4 min read',
                'image' => '/img/trucks-2.jpg',
                'featured' => false,
                'excerpt' => 'A practical comparison of freight modes for importers operating in Afghanistan and the wider region — and how multi-modal combinations often win.',
                'body' => [
                    'Sea freight offers the lowest cost per ton for containerized cargo, but the longest lead times and a dependency on gateway ports. For most commodity imports, sea remains the backbone.',
                    'Rail is growing in importance on the northern corridor, offering a middle ground between cost and speed for bulk goods such as grains, cement and fertilizers.',
                    'Road transport dominates regional trade — flexible, door-to-door and fast enough for many routes, though sensitive to border queues and seasonal road conditions.',
                    'Air freight is the exception, reserved for high-value, urgent or perishable cargo where speed outweighs cost by a large margin.',
                    'In practice, most sophisticated supply chains combine modes: sea to a gateway port, rail or road inland, and final-mile distribution by truck. A logistics partner that can coordinate the entire chain — including customs at each transfer — removes the friction points where delays usually happen.'
                ]
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-1'], [
            'title' => 'faq-1',
            'data' => [
                'cat' => 'General',
                'q' => 'What does Khan Boostan Limited do?',
                'a' => 'Khan Boostan Limited is an international trading company focused on import, export, sourcing, procurement and logistics, connecting suppliers and customers across Afghanistan, Central Asia, South Asia, the Middle East and other international markets.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-2'], [
            'title' => 'faq-2',
            'data' => [
                'cat' => 'General',
                'q' => 'Where is the company based?',
                'a' => 'The company is based in Mazar-e-Sharif, Balkh, Afghanistan, with trading relationships across regional and international markets. Full registered address and legal details are published on the About and Contact pages.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-3'], [
            'title' => 'faq-3',
            'data' => [
                'cat' => 'Products',
                'q' => 'What products do you trade?',
                'a' => 'Our catalog spans agricultural products, food products, construction materials, energy products, raw materials, machinery & equipment and consumer products. The catalog is indicative — if a product is not listed, contact us: sourcing is our core service.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-4'], [
            'title' => 'faq-4',
            'data' => [
                'cat' => 'Products',
                'q' => 'Can I request a product that is not in the catalog?',
                'a' => 'Yes. The catalog shows our core categories. Use the Request a Quote form or contact us directly with your specification, and our sourcing team will respond with options.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-5'], [
            'title' => 'faq-5',
            'data' => [
                'cat' => 'Sourcing',
                'q' => 'How do you verify suppliers?',
                'a' => 'We check supplier credentials, registration documents, references, production capacity and trade history before presenting any supplier to a customer. Verification results are documented for every sourcing assignment.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-6'], [
            'title' => 'faq-6',
            'data' => [
                'cat' => 'Sourcing',
                'q' => 'What is the minimum order quantity (MOQ)?',
                'a' => 'MOQs vary by product. Indicative MOQs are shown on each product page — typically one 20ft container for standard commodities. We can advise on mixed loads where suppliers allow them.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-7'], [
            'title' => 'faq-7',
            'data' => [
                'cat' => 'Import / Export',
                'q' => 'Which Incoterms do you work with?',
                'a' => 'We structure transactions under the Incoterms 2020 terms that fit the deal — commonly EXW, FOB, CIF, CPT or DAP. The applicable term is always confirmed in writing before commitment.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-8'], [
            'title' => 'faq-8',
            'data' => [
                'cat' => 'Import / Export',
                'q' => 'Do you handle customs and documentation?',
                'a' => 'Yes. Customs coordination, export/import documentation and compliance checks are part of our standard service on both import and export transactions.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 7,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-9'], [
            'title' => 'faq-9',
            'data' => [
                'cat' => 'Logistics',
                'q' => 'Which freight modes do you use?',
                'a' => 'Road, rail, sea and air — selected per cargo and route, often combined in multi-modal chains. We coordinate warehousing, cargo handling and cross-border procedures as needed.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 8,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-10'], [
            'title' => 'faq-10',
            'data' => [
                'cat' => 'Payment & Documentation',
                'q' => 'What payment terms are available?',
                'a' => 'Payment terms are agreed per transaction depending on the product, value and counterparties — typically advance payment, letter of credit or agreed trade terms. All terms are documented in the contract.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 9,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-11'], [
            'title' => 'faq-11',
            'data' => [
                'cat' => 'Quotations',
                'q' => 'How do I request a quotation?',
                'a' => 'Use the Request a Quote form on this website, or contact us by email, phone or WhatsApp. Provide the product, specification, quantity and destination, and our team will respond with a structured quotation.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 10,
        ]);
        ContentItem::updateOrCreate(['type' => 'faq', 'slug' => 'faq-12'], [
            'title' => 'faq-12',
            'data' => [
                'cat' => 'Quotations',
                'q' => 'How long does a quotation take?',
                'a' => 'Standard product inquiries are typically answered within 2–4 business days. Complex or custom sourcing requests may take longer depending on supplier response times — you will receive an acknowledgment immediately.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 11,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'integrity'], [
            'title' => 'Integrity',
            'data' => [
                'desc' => 'We do what we commit to — in writing, on time, at the agreed terms.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'reliability'], [
            'title' => 'Reliability',
            'data' => [
                'desc' => 'Consistent performance across every shipment, document and deadline.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'quality'], [
            'title' => 'Quality',
            'data' => [
                'desc' => 'Specifications verified, quality controlled and documented.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'transparency'], [
            'title' => 'Transparency',
            'data' => [
                'desc' => 'Clear pricing, clear status, no hidden conditions.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'professionalism'], [
            'title' => 'Professionalism',
            'data' => [
                'desc' => 'Structured processes and experienced trade practice.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'long-term-partnerships'], [
            'title' => 'Long-Term Partnerships',
            'data' => [
                'desc' => 'We build repeat business, not one-off deals.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
        ContentItem::updateOrCreate(['type' => 'value', 'slug' => 'customer-focus'], [
            'title' => 'Customer Focus',
            'data' => [
                'desc' => 'Your requirement is the specification — nothing else.'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 6,
        ]);
        ContentItem::updateOrCreate(['type' => 'company_info', 'slug' => 'legal-name'], [
            'title' => 'Legal Name',
            'data' => [
                'label' => 'Legal Name',
                'value' => 'Khan Boostan Limited'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 0,
        ]);
        ContentItem::updateOrCreate(['type' => 'company_info', 'slug' => 'business-type'], [
            'title' => 'Business Type',
            'data' => [
                'label' => 'Business Type',
                'value' => 'International Trading — Import & Export'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 1,
        ]);
        ContentItem::updateOrCreate(['type' => 'company_info', 'slug' => 'registration'], [
            'title' => 'Registration',
            'data' => [
                'label' => 'Registration'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 2,
        ]);
        ContentItem::updateOrCreate(['type' => 'company_info', 'slug' => 'trade-license'], [
            'title' => 'Trade License',
            'data' => [
                'label' => 'Trade License'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 3,
        ]);
        ContentItem::updateOrCreate(['type' => 'company_info', 'slug' => 'head-office'], [
            'title' => 'Head Office',
            'data' => [
                'label' => 'Head Office',
                'value' => 'Mazar-e-Sharif, Balkh, Afghanistan'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 4,
        ]);
        ContentItem::updateOrCreate(['type' => 'company_info', 'slug' => 'business-activities'], [
            'title' => 'Business Activities',
            'data' => [
                'label' => 'Business Activities',
                'value' => 'Import · Export · Trading · Sourcing · Procurement · Logistics'
            ],
            'translations' => null,
            'is_active' => true,
            'sort_order' => 5,
        ]);
    }
}
