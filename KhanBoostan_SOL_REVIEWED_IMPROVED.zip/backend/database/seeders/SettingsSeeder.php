<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingsSeeder extends Seeder
{
    public function run(): void
    {
        Setting::updateOrCreate(['group' => 'company', 'key' => 'name'], ['value' => 'Khan Boostan Limited']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'shortName'], ['value' => 'Khan Boostan']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'legalName'], ['value' => 'Khan Boostan Limited']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'tagline'], ['value' => 'Connecting Markets. Creating Opportunities.']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'supporting'], ['value' => 'Your Trusted Partner in International Trade, Import, Export and Supply.']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'intro'], ['value' => 'Khan Boostan Limited is an international trading and supply partner connecting suppliers, markets and customers across Afghanistan, Central Asia, South Asia, the Middle East and other international markets.']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'email'], ['value' => 'info@khanboostan.com']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'address'], ['value' => 'Mazar-e-Sharif, Balkh, Afghanistan']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'hours'], ['value' => 'Sat – Thu · 09:00 – 17:00']);
        Setting::updateOrCreate(['group' => 'company', 'key' => 'businessLines'], ['value' => [
            'Import',
            'Export',
            'International Trading',
            'Sourcing',
            'Procurement',
            'Logistics'
        ]]);
        Setting::updateOrCreate(['group' => 'brand', 'key' => 'domain'], ['value' => 'https://www.khanboostan.com']);
        Setting::updateOrCreate(['group' => 'brand', 'key' => 'copyright'], ['value' => '© 2026 Khan Boostan Limited. All Rights Reserved.']);
        Setting::updateOrCreate(['group' => 'site', 'key' => 'marketsNote'], ['value' => 'The regions and countries shown are target markets. Active country operations will be confirmed and published as they are established.']);
        Setting::updateOrCreate(['group' => 'site', 'key' => 'projectsNote'], ['value' => 'This portfolio is structured and ready. Real project entries — name, country, industry, scope, results — will be published here as soon as the company provides verified project information.']);
        Setting::updateOrCreate(['group' => 'site', 'key' => 'partnersNote'], ['value' => 'Partner and client logos are published only with official permission of each organization. Partner entries will appear here as they are confirmed.']);
        Setting::updateOrCreate(['group' => 'site', 'key' => 'certificatesNote'], ['value' => 'All documents on this page are published only after verification. Certificate previews and PDF downloads will be activated as soon as official documents are provided by the company.']);
        Setting::updateOrCreate(['group' => 'site', 'key' => 'faqCategories'], ['value' => [
            'General',
            'Products',
            'Sourcing',
            'Import / Export',
            'Logistics',
            'Payment & Documentation',
            'Quotations'
        ]]);
    }
}
