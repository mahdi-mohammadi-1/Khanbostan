# Khan Boostan API

Laravel 13 + MySQL + Sanctum bearer-token API.

## Windows / XAMPP quick start

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
php artisan serve
```

API health: `http://127.0.0.1:8000/up`
Site bootstrap: `http://127.0.0.1:8000/api/site/bootstrap`

Default seeded admin credentials come from `.env` (`ADMIN_EMAIL`, `ADMIN_PASSWORD`). Change them before production.
