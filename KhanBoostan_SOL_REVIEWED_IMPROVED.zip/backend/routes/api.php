<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\InquiryController;
use App\Http\Controllers\Api\ResourceController;
use App\Http\Controllers\Api\SettingController;
use App\Http\Controllers\Api\SiteBootstrapController;
use Illuminate\Support\Facades\Route;

Route::get('/site/bootstrap', SiteBootstrapController::class);
Route::post('/inquiries', [InquiryController::class, 'store'])->middleware('throttle:public-inquiries');
Route::post('/admin/login', [AuthController::class, 'login'])->middleware('throttle:admin-login');

Route::middleware(['auth:sanctum', 'throttle:admin-api'])->prefix('admin')->group(function (): void {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/settings', [SettingController::class, 'index']);
    Route::put('/settings', [SettingController::class, 'upsert']);
    Route::get('/inquiries', [InquiryController::class, 'index']);
    Route::patch('/inquiries/{inquiry}', [InquiryController::class, 'update']);

    Route::apiResources([
        'products' => ResourceController::class,
        'categories' => ResourceController::class,
        'services' => ResourceController::class,
        'markets' => ResourceController::class,
        'projects' => ResourceController::class,
        'partners' => ResourceController::class,
        'certificates' => ResourceController::class,
        'articles' => ResourceController::class,
        'faqs' => ResourceController::class,
        'trade-corridors' => ResourceController::class,
        'home-stories' => ResourceController::class,
    ]);
});
