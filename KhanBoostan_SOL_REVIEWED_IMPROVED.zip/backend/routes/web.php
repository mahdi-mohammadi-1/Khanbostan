<?php
use Illuminate\Support\Facades\Route;
Route::get('/', fn () => response()->json(['app' => 'Khan Boostan API', 'status' => 'ok']));
