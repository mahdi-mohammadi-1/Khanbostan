<?php
namespace App\Models; use Illuminate\Database\Eloquent\Model;
class Inquiry extends Model { protected $fillable=['kind','name','company','email','phone','country','subject','message','product','service','quantity','origin','destination','incoterm','status']; }
