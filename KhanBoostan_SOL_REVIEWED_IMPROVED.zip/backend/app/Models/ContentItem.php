<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ContentItem extends Model {
 protected $fillable=['type','slug','title','data','translations','is_active','sort_order'];
 protected function casts(): array { return ['data'=>'array','translations'=>'array','is_active'=>'boolean','sort_order'=>'integer']; }
}
