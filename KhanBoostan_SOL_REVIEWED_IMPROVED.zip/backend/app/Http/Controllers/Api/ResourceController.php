<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContentItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Validation\Rule;

class ResourceController extends Controller
{
    private const TYPES = [
        'categories' => 'category',
        'services' => 'service',
        'products' => 'product',
        'markets' => 'market',
        'projects' => 'project',
        'partners' => 'partner',
        'certificates' => 'certificate',
        'articles' => 'article',
        'faqs' => 'faq',
        'trade-corridors' => 'trade_corridor',
        'home-stories' => 'home_story',
    ];

    private function type(Request $request): string
    {
        $segment = $request->segment(3) ?? '';
        abort_unless(isset(self::TYPES[$segment]), 404);

        return self::TYPES[$segment];
    }

    public function index(Request $request): JsonResponse
    {
        $perPage = min(max((int) $request->integer('per_page', 50), 1), 100);

        return response()->json(
            ContentItem::query()
                ->where('type', $this->type($request))
                ->orderBy('sort_order')
                ->orderBy('id')
                ->paginate($perPage)
        );
    }

    public function store(Request $request): JsonResponse
    {
        $type = $this->type($request);
        $validated = $request->validate($this->rules($type));
        $validated['type'] = $type;
        $item = ContentItem::create($validated);
        Cache::forget('site.bootstrap.v1');

        return response()->json($item, 201);
    }

    public function show(Request $request, string $id): JsonResponse
    {
        return response()->json($this->find($request, $id));
    }

    public function update(Request $request, string $id): JsonResponse
    {
        $item = $this->find($request, $id);
        $validated = $request->validate($this->rules($item->type, $item->id, false));
        $item->update($validated);
        Cache::forget('site.bootstrap.v1');

        return response()->json($item->fresh());
    }

    public function destroy(Request $request, string $id): JsonResponse
    {
        $item = $this->find($request, $id);
        $item->delete();
        Cache::forget('site.bootstrap.v1');

        return response()->json(null, 204);
    }

    private function find(Request $request, string $id): ContentItem
    {
        return ContentItem::query()
            ->where('type', $this->type($request))
            ->findOrFail($id);
    }

    private function rules(string $type, ?int $ignoreId = null, bool $creating = true): array
    {
        $slugRule = Rule::unique('content_items', 'slug')
            ->where(fn ($query) => $query->where('type', $type));
        if ($ignoreId) {
            $slugRule->ignore($ignoreId);
        }

        return [
            'slug' => [$creating ? 'required' : 'sometimes', 'string', 'max:190', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slugRule],
            'title' => [$creating ? 'required' : 'sometimes', 'string', 'max:255'],
            'data' => ['nullable', 'array'],
            'translations' => ['nullable', 'array'],
            'is_active' => ['sometimes', 'boolean'],
            'sort_order' => ['sometimes', 'integer', 'min:0', 'max:100000'],
        ];
    }
}
