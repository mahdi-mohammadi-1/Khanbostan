<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class SettingController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(['data' => Setting::query()->orderBy('group')->orderBy('key')->get()->groupBy('group')]);
    }

    public function upsert(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'group' => ['required', 'string', 'max:80', 'regex:/^[a-zA-Z0-9_-]+$/'],
            'key' => ['required', 'string', 'max:120', 'regex:/^[a-zA-Z0-9_-]+$/'],
            'value' => ['nullable'],
        ]);

        $row = Setting::updateOrCreate(
            ['group' => $validated['group'], 'key' => $validated['key']],
            ['value' => $validated['value']]
        );
        Cache::forget('site.bootstrap.v1');

        return response()->json(['data' => $row]);
    }
}
