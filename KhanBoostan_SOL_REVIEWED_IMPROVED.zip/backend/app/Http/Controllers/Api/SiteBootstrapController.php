<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContentItem;
use App\Models\Setting;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;

class SiteBootstrapController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $data = Cache::remember('site.bootstrap.v1', now()->addMinutes(5), function (): array {
            $items = ContentItem::query()
                ->where('is_active', true)
                ->orderBy('sort_order')
                ->orderBy('id')
                ->get()
                ->groupBy('type');

            $settings = Setting::query()
                ->get()
                ->groupBy('group')
                ->map(fn ($rows) => $rows->pluck('value', 'key'));

            $map = [
                'product' => 'products', 'category' => 'categories', 'service' => 'services',
                'market' => 'markets', 'industry' => 'industries', 'project' => 'projects',
                'partner_type' => 'partnerTypes', 'certificate' => 'certificates', 'article' => 'articles',
                'faq' => 'faqs', 'nav' => 'nav', 'why_us' => 'whyUs', 'trade_process' => 'tradeProcess',
                'trade_corridor' => 'tradeCorridors', 'home_story' => 'homeStories', 'value' => 'values',
                'company_info' => 'companyInfo',
            ];

            $payload = [];
            foreach ($map as $type => $key) {
                $payload[$key] = ($items[$type] ?? collect())
                    ->map(fn ($item) => array_merge($item->data ?? [], [
                        'id' => $item->id,
                        'slug' => $item->slug,
                        'name' => $item->title,
                        'translations' => $item->translations,
                    ]))
                    ->values();
            }

            $payload['company'] = $settings->get('company', collect());
            $payload['brand'] = $settings->get('brand', collect());
            $site = $settings->get('site', collect());
            foreach (['marketsNote', 'projectsNote', 'partnersNote', 'certificatesNote', 'faqCategories'] as $key) {
                $payload[$key] = $site->get($key, '');
            }

            return $payload;
        });

        return response()->json(['data' => $data]);
    }
}
