# Khan Boostan Full-Stack Architecture

## Structure
- `frontend/` React + Vite + Redux Toolkit + Context + Tailwind, JavaScript only.
- `backend/` Laravel 13 REST API + MySQL CMS foundation.
- `AGENTS.md` project engineering rules aligned with ECC.

## Frontend
1. Copy `frontend/.env.example` to `.env`.
2. `npm install`
3. `npm run dev`
4. Quality gate: `npm run check`

The frontend requests `/api/site/bootstrap`. There is no content fallback in the frontend: Laravel/MySQL is the single source of truth. Initial production-like content is inserted by Laravel seeders and can then be edited through the CMS.

## Backend
1. Install Composer on your machine.
2. In `backend/`: `composer install`
3. Copy `.env.example` to `.env`, create MySQL database `khanboostan`.
4. `php artisan key:generate`
5. `php artisan migrate:fresh --seed` (first local setup)
6. `php artisan serve`

## CMS model
`content_items` stores products, categories, services, markets, industries, projects, partners, certificates, articles, FAQs, navigation, trade process and Why Us items. `settings` stores company/brand/global settings. JSON translation fields support EN/FA/RU without schema duplication.

## Admin CMS
Admin routes are `/admin/login` and `/admin`. Backend write APIs are protected with Sanctum. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before `php artisan migrate --seed`; never keep the example password in production.

Public API only exposes bootstrap content and inquiry submission. CRUD endpoints require an authenticated admin token.
