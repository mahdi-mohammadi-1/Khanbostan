$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Backend = Join-Path $Root 'backend'
$Frontend = Join-Path $Root 'frontend'

Write-Host '== Khan Boostan full-stack setup ==' -ForegroundColor Cyan

if (-not (Get-Command php -ErrorAction SilentlyContinue)) { throw 'PHP is not installed or not available in PATH.' }
if (-not (Get-Command composer -ErrorAction SilentlyContinue)) { throw 'Composer is not installed or not available in PATH.' }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw 'Node.js/npm is not installed or not available in PATH.' }

if (-not (Test-Path (Join-Path $Backend '.env'))) { Copy-Item (Join-Path $Backend '.env.example') (Join-Path $Backend '.env') }
if (-not (Test-Path (Join-Path $Frontend '.env'))) { Copy-Item (Join-Path $Frontend '.env.example') (Join-Path $Frontend '.env') }

$requiredDirectories = @(
  'bootstrap/cache', 'storage/app', 'storage/app/public', 'storage/framework/cache',
  'storage/framework/cache/data', 'storage/framework/sessions', 'storage/framework/testing',
  'storage/framework/views', 'storage/logs'
)
foreach ($relative in $requiredDirectories) {
  $path = Join-Path $Backend $relative
  if (-not (Test-Path $path)) { New-Item -ItemType Directory -Path $path -Force | Out-Null }
}

& (Join-Path $Root 'configure-local.ps1')

Push-Location $Backend
try {
  composer install
  if ($LASTEXITCODE -ne 0) { throw 'composer install failed.' }
  php artisan key:generate --force
  if ($LASTEXITCODE -ne 0) { throw 'Laravel key generation failed.' }
  php artisan optimize:clear
  if ($LASTEXITCODE -ne 0) { throw 'Laravel cache clear failed.' }

  Write-Host 'Checking MySQL connection...' -ForegroundColor Cyan
  php artisan migrate:fresh --seed --force
  if ($LASTEXITCODE -ne 0) {
    Write-Host 'Migration failed. Check that MySQL is running and the credentials in backend/.env are correct.' -ForegroundColor Red
    throw 'Database setup failed.'
  }
} finally { Pop-Location }

Push-Location $Frontend
try {
  npm install
  if ($LASTEXITCODE -ne 0) { throw 'npm install failed.' }
} finally { Pop-Location }

Write-Host ''
Write-Host 'Setup completed successfully.' -ForegroundColor Green
Write-Host 'Run .\run-dev.ps1 to start frontend and backend.' -ForegroundColor Green
