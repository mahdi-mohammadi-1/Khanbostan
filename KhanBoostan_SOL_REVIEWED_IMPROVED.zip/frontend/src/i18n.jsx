import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { useSelector } from 'react-redux'
import { company as sourceCompany, hydrateSiteData, products as sourceProducts, services as sourceServices, tradeCorridors as sourceTradeCorridors, homeStories as sourceHomeStories } from './lib/data.jsx'

export const languages = [
  { code: 'en', short: 'EN', label: 'English', native: 'English', dir: 'ltr' },
  { code: 'fa', short: 'FA', label: 'Persian', native: 'فارسی', dir: 'rtl' },
  { code: 'ru', short: 'RU', label: 'Russian', native: 'Русский', dir: 'ltr' },
]

const messages = {
  en: {
    nav: { home: 'Home', about: 'About', products: 'Products', import: 'Import', export: 'Export', services: 'Services', markets: 'Markets', contact: 'Contact' },
    common: {
      requestQuote: 'Request a Quote', exploreProducts: 'Explore Products', learnMore: 'Learn More', viewDetails: 'View Details', quote: 'Quote',
      viewAll: 'View all', home: 'Home', product: 'Product', products: 'Products', services: 'Services', search: 'Search products or HS code…',
      clearSearch: 'Clear search', noProducts: 'No products match your search', tryAnother: 'Try another product name or HS code.',
      showing: 'Showing', of: 'of', items: 'products', startConversation: 'Start a conversation', whatsapp: 'WhatsApp Us',
      address: 'Address', phone: 'Phone', email: 'Email', company: 'Company', trade: 'Trade', support: 'Support',
      privacy: 'Privacy Policy', terms: 'Terms & Conditions', openMenu: 'Open menu', closeMenu: 'Close menu', selectLanguage: 'Select language',
      loading: 'Loading', backCatalog: 'Back to Products', specifications: 'Specifications', productOverview: 'Product overview', relatedProducts: 'More products',
      pricingTitle: 'Pricing & availability:', pricingText: 'Pricing depends on grade, volume, origin and current market conditions and is confirmed for every inquiry.',
      interested: 'Interested in this product?', sendQuantity: 'Send us your quantity and destination — we will respond with a structured quotation.',
    },
    home: {
      eyebrow: 'International trade · Import · Export', hero1: 'Connecting Markets.', hero2: 'Creating Opportunities.',
      intro: 'A reliable trade partner for import, export, sourcing, procurement and logistics across regional and international markets.',
      productsFact: 'Trade products', marketsFact: 'Priority markets', serviceFact: 'Integrated services', focusFact: 'B2B focus',
      aboutKicker: 'Khan Boostan Limited', aboutTitle: 'One accountable partner across the trade cycle',
      aboutText: 'From supplier verification and commercial negotiation to documentation, customs and delivery, we coordinate every stage with clarity and control.',
      importTitle: 'Import with confidence', importText: 'Verified sourcing, purchasing, freight and customs coordination for goods entering Afghanistan and the region.',
      exportTitle: 'Export with reach', exportText: 'Quality preparation, documentation and delivery of Afghan and regional products to international buyers.',
      servicesKicker: 'What we do', servicesTitle: 'Modern trade services', servicesIntro: 'Use one service or combine them into a complete supply-chain solution.',
      productsKicker: 'What we trade', productsTitle: 'Products without unnecessary categories', productsIntro: 'A direct, searchable list of products. Tell us what you need if it is not shown.',
      whyKicker: 'Why Khan Boostan', whyTitle: 'Trade built on documentation and trust',
      reasons: [
        { title: 'Verified counterparties', text: 'Suppliers and commercial documents are reviewed before commitments are made.' },
        { title: 'Clear commercial terms', text: 'Price, specification, Incoterms, payment and timing are agreed in writing.' },
        { title: 'Cross-border coordination', text: 'Freight, customs, border procedures and delivery are followed through one team.' },
        { title: 'Responsive communication', text: 'Buyers and suppliers receive practical updates throughout the transaction.' },
      ],
      marketsKicker: 'Trade corridors', marketsTitle: 'Balkh connected to regional markets', marketsIntro: 'Commercial routes toward Uzbekistan, China, Russia and wider Central Asian and international markets.',
      finalTitle: 'Ready to discuss your next shipment?', finalText: 'Share the product, quantity, origin and destination. Our team will propose a clear trade structure.',
    },
    productsPage: {
      kicker: 'Product portfolio', title: 'Products & commodities',
      intro: 'Browse all products in one clear list — without category filters. Specifications, origin and terms are confirmed for every inquiry.',
      countNote: 'products available for direct inquiry', catalogTitle: 'Catalog scope:', catalogText: 'This list can grow with your business. If a product is not listed, send the required specification and our sourcing team will find verified options.',
      ctaTitle: "Need a product that is not listed?", ctaText: 'Tell us the specification, quantity and destination — we will source it.',
    },
    servicesPage: {
      kicker: 'Our services', title: 'Trading & supply-chain services', intro: 'One accountable partner from supplier to destination.',
      portfolio: 'Service portfolio', whatWeDo: 'What we do', portfolioIntro: 'Integrated services that can be used individually or combined into one complete solution.',
      method: 'Methodology', methodTitle: 'A structured way of working', methodText: 'Every engagement follows a clear sequence: inquiry, verification, terms, documentation, logistics and delivery.',
      extended: 'Extended capabilities', extendedTitle: 'Beyond the core', discuss: 'Discuss your requirement', finalTitle: 'Which service fits your business?', finalText: 'Tell us what you need and we will propose the right structure, terms and timeline.',
      extendedItems: [['Distribution', 'Regional distribution and channel coordination.'], ['Supply chain', 'Monitoring and coordination from origin to delivery.'], ['Market research', 'Market-entry, pricing and demand review.'], ['Commercial representation', 'Structured regional representation for international principals.']],
    },
    serviceDetail: {
      capabilities: 'Capabilities', includes: 'What this service includes', body: 'The service is delivered through documented steps and adapts to single shipments or long-term supply programs.',
      workflow: 'Workflow', process: 'Service process', processIntro: 'A clear sequence from requirement to delivery.', other: 'Explore other services', support: 'Need support with this service?', supportText: 'Tell us your requirement — our team will propose the right structure.',
    },
    about: {
      kicker: 'About Khan Boostan', title: 'A trade partner built in Balkh', intro: 'Khan Boostan Limited connects producers, buyers and markets through structured import, export and logistics services.',
      storyKicker: 'Who we are', storyTitle: 'Local knowledge. International standards.', storyText: 'Based in Balkh, Afghanistan, we understand regional trade routes and the practical realities of sourcing, customs and cross-border delivery. We combine that knowledge with documented commercial processes for international buyers and suppliers.',
      missionTitle: 'Our mission', missionText: 'To create dependable market access for Afghan and regional products while helping businesses source and import the goods they need.',
      visionTitle: 'Our vision', visionText: 'To become a trusted trade bridge between Afghanistan, neighboring countries and wider international markets.',
      valuesTitle: 'How we work', values: ['Transparency', 'Documented quality', 'Commercial discipline', 'Long-term partnership'],
    },
    marketsPage: {
      kicker: 'Markets', title: 'Regional reach from Balkh', intro: 'Trade corridors linking Afghanistan with Uzbekistan, China, Russia and wider markets.',
      routesTitle: 'Priority trade directions', note: 'Routes, border points and delivery terms are confirmed for every shipment.',
      countries: [
        { name: 'Uzbekistan', text: 'Hiratan gateway and Central Asian road and rail links.' },
        { name: 'China', text: 'Regional transit corridors for industrial and consumer trade.' },
        { name: 'Russia', text: 'Multi-country road and rail solutions for selected commodities.' },
        { name: 'Afghanistan', text: 'Sourcing, consolidation and distribution from Balkh.' },
      ],
    },
    contactPage: {
      kicker: 'Contact', title: 'Talk to our trade team', intro: 'Start with the product, quantity, origin and destination. We will help structure the next step.',
      formTitle: 'Send a message', detailsTitle: 'Company contact', hours: 'Business hours', hoursValue: 'Saturday–Thursday · 09:00–17:00',
    },
    quotePage: {
      kicker: 'Request a quote', title: 'Tell us what you need', intro: 'A focused inquiry form for import, export, products and logistics.',
      sideTitle: 'What happens next?', steps: ['We review your specification.', 'We confirm missing commercial details.', 'We return with a structured quotation or sourcing plan.'],
    },
    form: {
      name: 'Full name', company: 'Company', email: 'Business email', phone: 'Phone / WhatsApp', country: 'Country', subject: 'Subject', message: 'Message',
      product: 'Product / commodity', service: 'Required service', quantity: 'Quantity', origin: 'Preferred origin', destination: 'Destination', incoterm: 'Preferred Incoterm',
      placeholderName: 'Your name', placeholderCompany: 'Company name', placeholderEmail: 'name@company.com', placeholderPhone: '+93…', placeholderCountry: 'Country',
      placeholderSubject: 'How can we help?', placeholderMessage: 'Please describe your requirement…', selectProduct: 'Select a product', selectService: 'Select a service',
      submit: 'Send inquiry', success: 'Thank you. Your inquiry has been recorded for submission.', note: 'Connect this form to your email or CRM before launch.',
    },
    spec: { origin: 'Origin', grade: 'Grade / quality', packaging: 'Packaging', moq: 'Minimum order', hs: 'HS code', terms: 'Trade terms', lead: 'Lead time', certifications: 'Certifications' },
    footer: { intro: 'International trading, import, export and supply-chain coordination from Balkh, Afghanistan.', rights: '© 2026 Khan Boostan Limited. All rights reserved.' },
    legal: {
      kicker: 'Legal', lastUpdated: 'Last updated: August 2026 · Khan Boostan Limited, Mazar-e-Sharif, Afghanistan',
      privacy: { title: 'Privacy Policy', intro: 'How Khan Boostan Limited handles the information you share with us.', sections: [
        ['1. Scope', 'This policy applies to information collected through this website, our communication channels and our business operations.'],
        ['2. Information we collect', 'We collect the contact and commercial information needed to answer inquiries and conduct business, including product, quantity, destination and attached-document details.'],
        ['3. How we use information', 'Information is used to answer inquiries, prepare quotations, execute transactions and meet legal obligations. We do not sell or rent personal data.'],
        ['4. Sharing', 'Information is shared only when needed for a transaction, such as with logistics providers, customs agents or financial institutions.'],
        ['5. Retention and security', 'Business records are kept for legally required periods and protected with reasonable technical and organizational measures.'],
        ['6. Your rights', 'You may request access to, correction of or deletion of your personal information through the Contact page.'],
        ['7. Changes', 'This policy may be updated. The current version is always published on this page.'],
      ] },
      terms: { title: 'Terms & Conditions', intro: 'The terms governing this website and our business communications.', sections: [
        ['1. Website content', 'Website content is general information. Product specifications, prices and availability are indicative and do not constitute a binding offer.'],
        ['2. Quotations and contracts', 'Binding terms are established only through written quotations and signed agreements, including specifications, quantities, prices, Incoterms and delivery terms.'],
        ['3. Intellectual property', 'The brand, logo, text, images and design belong to Khan Boostan Limited or its licensors and may not be reproduced without written permission.'],
        ['4. Liability', 'We work to keep information accurate, but the website is provided without warranty. Transaction liability is governed by the applicable written agreement.'],
        ['5. External links', 'Third-party links are provided for convenience; we are not responsible for external content or practices.'],
        ['6. Governing law', 'These terms and business relationships are governed by applicable Afghan law unless a written agreement states otherwise.'],
        ['7. Contact', 'Questions about these terms may be sent to our management through the Contact page.'],
      ] },
    },
    notFound: { title: 'Page not found', text: 'The page you are looking for has moved or does not exist.', back: 'Back to Home', contact: 'Contact Us' },
  },
  fa: {
    nav: { home: 'خانه', about: 'درباره ما', products: 'محصولات', import: 'واردات', export: 'صادرات', services: 'خدمات', markets: 'بازارها', contact: 'تماس' },
    common: {
      requestQuote: 'درخواست نرخ', exploreProducts: 'مشاهده محصولات', learnMore: 'جزئیات بیشتر', viewDetails: 'مشاهده جزئیات', quote: 'درخواست نرخ',
      viewAll: 'مشاهده همه', home: 'خانه', product: 'محصول', products: 'محصولات', services: 'خدمات', search: 'جستجوی محصول یا کود HS…',
      clearSearch: 'پاک‌کردن جستجو', noProducts: 'محصولی مطابق جستجو پیدا نشد', tryAnother: 'نام محصول یا کود HS دیگری را امتحان کنید.',
      showing: 'نمایش', of: 'از', items: 'محصول', startConversation: 'گفت‌وگو را آغاز کنید', whatsapp: 'واتساپ',
      address: 'آدرس', phone: 'تلفن', email: 'ایمیل', company: 'شرکت', trade: 'تجارت', support: 'پشتیبانی',
      privacy: 'حریم خصوصی', terms: 'شرایط و مقررات', openMenu: 'بازکردن منو', closeMenu: 'بستن منو', selectLanguage: 'انتخاب زبان',
      loading: 'در حال بارگذاری', backCatalog: 'بازگشت به محصولات', specifications: 'مشخصات', productOverview: 'معرفی محصول', relatedProducts: 'محصولات بیشتر',
      pricingTitle: 'قیمت و موجودی:', pricingText: 'قیمت بر اساس گرید، مقدار، مبدأ و شرایط روز بازار تعیین و برای هر درخواست جداگانه تأیید می‌شود.',
      interested: 'به این محصول نیاز دارید؟', sendQuantity: 'مقدار و مقصد را بفرستید تا نرخ و شرایط منظم برایتان آماده کنیم.',
    },
    home: {
      eyebrow: 'تجارت بین‌المللی · واردات · صادرات', hero1: 'بازارها را وصل می‌کنیم.', hero2: 'فرصت‌ها را می‌سازیم.',
      intro: 'شریک مطمئن برای واردات، صادرات، سورسینگ، تدارکات و انتقال کالا در بازارهای منطقه‌ای و بین‌المللی.',
      productsFact: 'محصول تجارتی', marketsFact: 'بازار اولویت‌دار', serviceFact: 'خدمات یک‌پارچه', focusFact: 'تمرکز B2B',
      aboutKicker: 'شرکت خان بوستان', aboutTitle: 'یک مسئول پاسخ‌گو در تمام چرخه تجارت',
      aboutText: 'از بررسی تأمین‌کننده و مذاکره تجارتی تا اسناد، گمرک و تحویل، هر مرحله را با شفافیت و کنترول هماهنگ می‌کنیم.',
      importTitle: 'واردات با اطمینان', importText: 'سورسینگ معتبر، خرید، حمل‌ونقل و هماهنگی گمرکی برای ورود کالا به افغانستان و منطقه.',
      exportTitle: 'صادرات به بازارهای بیشتر', exportText: 'آماده‌سازی کیفیت، اسناد و تحویل محصولات افغانستان و منطقه به خریداران بین‌المللی.',
      servicesKicker: 'خدمات ما', servicesTitle: 'خدمات مدرن تجارتی', servicesIntro: 'هر خدمت را جداگانه یا به‌صورت راه‌حل کامل زنجیره تأمین استفاده کنید.',
      productsKicker: 'محصولات ما', productsTitle: 'محصولات بدون کتگوری‌بندی اضافی', productsIntro: 'فهرست مستقیم و قابل جستجو؛ اگر محصول شما موجود نبود، نیازتان را بفرستید.',
      whyKicker: 'چرا خان بوستان', whyTitle: 'تجارت بر بنیاد اسناد و اعتماد',
      reasons: [
        { title: 'طرف‌های بررسی‌شده', text: 'تأمین‌کنندگان و اسناد تجارتی پیش از تعهد بررسی می‌شوند.' },
        { title: 'شرایط روشن معامله', text: 'قیمت، مشخصات، اینکوترمز، پرداخت و زمان‌بندی به‌صورت کتبی تعیین می‌شود.' },
        { title: 'هماهنگی عبور مرزی', text: 'حمل، گمرک، مراحل مرزی و تحویل توسط یک تیم پیگیری می‌شود.' },
        { title: 'ارتباط پاسخ‌گو', text: 'خریدار و تأمین‌کننده در جریان معامله معلومات عملی دریافت می‌کنند.' },
      ],
      marketsKicker: 'دهلیزهای تجارتی', marketsTitle: 'اتصال بلخ با بازارهای منطقه', marketsIntro: 'مسیرهای تجارتی به ازبکستان، چین، روسیه، آسیای میانه و سایر بازارهای بین‌المللی.',
      finalTitle: 'برای محموله بعدی آماده‌اید؟', finalText: 'محصول، مقدار، مبدأ و مقصد را بفرستید؛ تیم ما ساختار روشن معامله را پیشنهاد می‌کند.',
    },
    productsPage: {
      kicker: 'فهرست محصولات', title: 'محصولات و کالاهای تجارتی', intro: 'تمام محصولات را در یک فهرست روشن و بدون فیلتر کتگوری ببینید. مشخصات، مبدأ و شرایط هر معامله جداگانه تأیید می‌شود.',
      countNote: 'محصول آماده دریافت درخواست', catalogTitle: 'دامنه فهرست:', catalogText: 'این فهرست همراه کاروبار شما توسعه می‌یابد. اگر محصول مورد نظر موجود نیست، مشخصات را بفرستید تا گزینه‌های معتبر پیدا کنیم.',
      ctaTitle: 'محصول مورد نظر در فهرست نیست؟', ctaText: 'مشخصات، مقدار و مقصد را بفرستید تا برایتان تهیه کنیم.',
    },
    servicesPage: {
      kicker: 'خدمات ما', title: 'خدمات تجارت و زنجیره تأمین', intro: 'یک شریک پاسخ‌گو از تأمین‌کننده تا مقصد.',
      portfolio: 'مجموعه خدمات', whatWeDo: 'چه کاری انجام می‌دهیم', portfolioIntro: 'خدمات یک‌پارچه‌ای که جداگانه یا به‌صورت راه‌حل کامل قابل استفاده است.',
      method: 'روش کار', methodTitle: 'کار منظم و مرحله‌وار', methodText: 'هر همکاری مسیر روشنی دارد: درخواست، بررسی، شرایط، اسناد، انتقال و تحویل.',
      extended: 'توانایی‌های بیشتر', extendedTitle: 'فراتر از خدمات اصلی', discuss: 'در مورد نیازتان صحبت کنید', finalTitle: 'کدام خدمت برای شما مناسب است؟', finalText: 'نیازتان را بفرستید تا ساختار، شرایط و زمان‌بندی مناسب را پیشنهاد کنیم.',
      extendedItems: [['توزیع', 'توزیع منطقه‌ای و هماهنگی کانال‌های فروش.'], ['زنجیره تأمین', 'نظارت و هماهنگی از مبدأ تا تحویل.'], ['تحقیق بازار', 'بررسی ورود به بازار، قیمت و تقاضا.'], ['نمایندگی تجارتی', 'نمایندگی منظم شرکت‌های بین‌المللی در بازار منطقه.']],
    },
    serviceDetail: {
      capabilities: 'توانایی‌ها', includes: 'این خدمت شامل چیست', body: 'خدمت با مراحل مستند ارائه می‌شود و برای یک محموله یا برنامه‌های درازمدت قابل تنظیم است.',
      workflow: 'مراحل کار', process: 'روند اجرای خدمت', processIntro: 'مسیر روشن از درخواست تا تحویل.', other: 'سایر خدمات', support: 'برای این خدمت کمک می‌خواهید؟', supportText: 'نیازتان را بفرستید تا ساختار مناسب پیشنهاد شود.',
    },
    about: {
      kicker: 'درباره خان بوستان', title: 'شریک تجارتی مستقر در بلخ', intro: 'شرکت خان بوستان تولیدکنندگان، خریداران و بازارها را از طریق واردات، صادرات و خدمات لجستیکی منظم وصل می‌کند.',
      storyKicker: 'معرفی شرکت', storyTitle: 'شناخت محلی، معیارهای بین‌المللی', storyText: 'با فعالیت در بلخ، مسیرهای تجارتی منطقه و واقعیت‌های سورسینگ، گمرک و عبور مرزی را می‌شناسیم. این تجربه را با روندهای مستند تجارتی برای خریداران و تأمین‌کنندگان بین‌المللی ترکیب می‌کنیم.',
      missionTitle: 'مأموریت ما', missionText: 'ایجاد دسترسی مطمئن به بازار برای محصولات افغانستان و منطقه و کمک به شرکت‌ها برای تهیه و واردات کالاهای مورد نیاز.',
      visionTitle: 'چشم‌انداز ما', visionText: 'تبدیل‌شدن به پل قابل اعتماد تجارت میان افغانستان، کشورهای همسایه و بازارهای بین‌المللی.',
      valuesTitle: 'روش کار ما', values: ['شفافیت', 'کیفیت مستند', 'نظم تجارتی', 'همکاری درازمدت'],
    },
    marketsPage: {
      kicker: 'بازارها', title: 'دسترسی منطقه‌ای از بلخ', intro: 'دهلیزهای تجارتی افغانستان با ازبکستان، چین، روسیه و سایر بازارها.',
      routesTitle: 'مسیرهای اولویت‌دار تجارت', note: 'مسیر، نقطه مرزی و شرایط تحویل برای هر محموله جداگانه تأیید می‌شود.',
      countries: [
        { name: 'ازبکستان', text: 'دروازه حیرتان و اتصال جاده‌ای و ریل آسیای میانه.' },
        { name: 'چین', text: 'دهلیزهای ترانزیتی منطقه برای تجارت صنعتی و مصرفی.' },
        { name: 'روسیه', text: 'راه‌حل‌های چندکشوری جاده و ریل برای کالاهای انتخابی.' },
        { name: 'افغانستان', text: 'سورسینگ، تجمیع و توزیع از بلخ.' },
      ],
    },
    contactPage: {
      kicker: 'تماس', title: 'با تیم تجارت ما صحبت کنید', intro: 'محصول، مقدار، مبدأ و مقصد را شریک کنید تا مرحله بعدی را تنظیم کنیم.',
      formTitle: 'ارسال پیام', detailsTitle: 'راه‌های تماس شرکت', hours: 'ساعات کاری', hoursValue: 'شنبه تا پنج‌شنبه · 09:00 تا 17:00',
    },
    quotePage: {
      kicker: 'درخواست نرخ', title: 'نیازتان را برای ما بنویسید', intro: 'فورم منظم برای واردات، صادرات، محصولات و لجستیک.',
      sideTitle: 'بعد از ارسال چه می‌شود؟', steps: ['مشخصات شما بررسی می‌شود.', 'جزئیات تجارتی تکمیل می‌گردد.', 'نرخ یا برنامه سورسینگ منظم ارائه می‌شود.'],
    },
    form: {
      name: 'نام کامل', company: 'شرکت', email: 'ایمیل کاری', phone: 'تلفن / واتساپ', country: 'کشور', subject: 'موضوع', message: 'پیام',
      product: 'محصول / کالا', service: 'خدمت مورد نیاز', quantity: 'مقدار', origin: 'مبدأ ترجیحی', destination: 'مقصد', incoterm: 'اینکوترمز ترجیحی',
      placeholderName: 'نام شما', placeholderCompany: 'نام شرکت', placeholderEmail: 'name@company.com', placeholderPhone: '+93…', placeholderCountry: 'کشور',
      placeholderSubject: 'چگونه کمک کنیم؟', placeholderMessage: 'نیازتان را با جزئیات بنویسید…', selectProduct: 'انتخاب محصول', selectService: 'انتخاب خدمت',
      submit: 'ارسال درخواست', success: 'سپاس. درخواست شما برای ارسال ثبت شد.', note: 'پیش از نشر وب‌سایت، فورم را به ایمیل یا CRM وصل کنید.',
    },
    spec: { origin: 'مبدأ', grade: 'گرید / کیفیت', packaging: 'بسته‌بندی', moq: 'حداقل سفارش', hs: 'کود HS', terms: 'شرایط تجارت', lead: 'زمان آماده‌سازی', certifications: 'تصدیق‌نامه‌ها' },
    footer: { intro: 'تجارت بین‌المللی، واردات، صادرات و هماهنگی زنجیره تأمین از بلخ، افغانستان.', rights: '© 2026 شرکت خان بوستان. تمام حقوق محفوظ است.' },
    legal: {
      kicker: 'حقوقی', lastUpdated: 'آخرین به‌روزرسانی: آگست ۲۰۲۶ · شرکت خان بوستان، مزارشریف، افغانستان',
      privacy: { title: 'سیاست حفظ حریم خصوصی', intro: 'چگونگی نگهداری و استفاده از معلوماتی که با شرکت خان بوستان شریک می‌سازید.', sections: [
        ['۱. دامنه تطبیق', 'این سیاست شامل معلومات جمع‌آوری‌شده از طریق وب‌سایت، راه‌های ارتباطی و فعالیت‌های تجارتی ما می‌شود.'],
        ['۲. معلوماتی که جمع‌آوری می‌کنیم', 'تنها معلومات تماس و تجارتی لازم برای پاسخ‌گویی و انجام معامله، مانند محصول، مقدار، مقصد و اسناد ضمیمه، جمع‌آوری می‌شود.'],
        ['۳. شیوه استفاده', 'معلومات برای پاسخ به درخواست، تهیه نرخ، اجرای معامله و رعایت الزامات قانونی استفاده می‌شود. معلومات شخصی فروخته یا کرایه داده نمی‌شود.'],
        ['۴. شریک‌سازی معلومات', 'معلومات فقط در حد نیاز معامله، مانند همکاری با شرکت‌های ترانسپورتی، کارگزاران گمرک یا نهادهای مالی، شریک می‌شود.'],
        ['۵. نگهداری و امنیت', 'اسناد تجارتی برای مدت لازم قانونی نگهداری و با تدابیر معقول فنی و اداری محافظت می‌شود.'],
        ['۶. حقوق شما', 'می‌توانید از طریق صفحه تماس، دسترسی، اصلاح یا حذف معلومات شخصی خود را درخواست کنید.'],
        ['۷. تغییرات', 'این سیاست ممکن است به‌روزرسانی شود و نسخه جاری همیشه در همین صفحه نشر می‌گردد.'],
      ] },
      terms: { title: 'شرایط و مقررات', intro: 'شرایط استفاده از این وب‌سایت و ارتباطات تجارتی شرکت.', sections: [
        ['۱. محتوای وب‌سایت', 'محتوای وب‌سایت معلومات عمومی است. مشخصات، قیمت و موجودی محصولات تقریبی بوده و پیشنهاد الزام‌آور محسوب نمی‌شود.'],
        ['۲. نرخ و قرارداد', 'شرایط الزام‌آور فقط در نرخ‌نامه کتبی و قرارداد امضاشده، شامل مشخصات، مقدار، قیمت، اینکوترمز و تحویل، تعیین می‌شود.'],
        ['۳. مالکیت فکری', 'برند، لوگو، متن، تصاویر و دیزاین متعلق به شرکت خان بوستان یا دارندگان مجوز آن است و بدون اجازه کتبی قابل استفاده مجدد نیست.'],
        ['۴. مسئولیت', 'برای دقت معلومات تلاش می‌کنیم، اما مسئولیت هر معامله مطابق قرارداد کتبی مربوط تعیین می‌شود.'],
        ['۵. لینک‌های بیرونی', 'لینک‌های بیرونی برای سهولت ارائه شده و شرکت مسئول محتوا یا روش کاری وب‌سایت‌های دیگر نیست.'],
        ['۶. قانون حاکم', 'این شرایط و روابط تجارتی تابع قوانین نافذه افغانستان است، مگر در قرارداد کتبی طور دیگری توافق شده باشد.'],
        ['۷. تماس', 'پرسش‌های مربوط به این شرایط را از طریق صفحه تماس با مدیریت شریک سازید.'],
      ] },
    },
    notFound: { title: 'صفحه پیدا نشد', text: 'صفحه مورد نظر انتقال یافته یا وجود ندارد.', back: 'بازگشت به خانه', contact: 'تماس با ما' },
  },
  ru: {
    nav: { home: 'Главная', about: 'О компании', products: 'Продукция', import: 'Импорт', export: 'Экспорт', services: 'Услуги', markets: 'Рынки', contact: 'Контакты' },
    common: {
      requestQuote: 'Запросить цену', exploreProducts: 'Смотреть продукцию', learnMore: 'Подробнее', viewDetails: 'Подробнее', quote: 'Запрос цены',
      viewAll: 'Смотреть все', home: 'Главная', product: 'Продукт', products: 'Продукция', services: 'Услуги', search: 'Поиск продукта или кода HS…',
      clearSearch: 'Очистить поиск', noProducts: 'По вашему запросу ничего не найдено', tryAnother: 'Попробуйте другое название или код HS.',
      showing: 'Показано', of: 'из', items: 'товаров', startConversation: 'Начните диалог', whatsapp: 'Написать в WhatsApp',
      address: 'Адрес', phone: 'Телефон', email: 'Эл. почта', company: 'Компания', trade: 'Торговля', support: 'Поддержка',
      privacy: 'Конфиденциальность', terms: 'Условия', openMenu: 'Открыть меню', closeMenu: 'Закрыть меню', selectLanguage: 'Выбрать язык',
      loading: 'Загрузка', backCatalog: 'Назад к продукции', specifications: 'Характеристики', productOverview: 'О продукте', relatedProducts: 'Другие продукты',
      pricingTitle: 'Цена и наличие:', pricingText: 'Цена зависит от сорта, объёма, происхождения и текущих условий рынка и подтверждается по каждому запросу.',
      interested: 'Интересует этот продукт?', sendQuantity: 'Сообщите количество и пункт назначения — мы подготовим структурированное предложение.',
    },
    home: {
      eyebrow: 'Международная торговля · Импорт · Экспорт', hero1: 'Соединяем рынки.', hero2: 'Создаём возможности.',
      intro: 'Надёжный партнёр по импорту, экспорту, поиску поставщиков, закупкам и логистике на региональных и международных рынках.',
      productsFact: 'Торговых продуктов', marketsFact: 'Приоритетных рынка', serviceFact: 'Комплексных услуг', focusFact: 'Фокус B2B',
      aboutKicker: 'Khan Boostan Limited', aboutTitle: 'Единая ответственность на всём торговом цикле',
      aboutText: 'От проверки поставщика и переговоров до документов, таможни и доставки — мы координируем каждый этап прозрачно и управляемо.',
      importTitle: 'Уверенный импорт', importText: 'Проверенный поиск, закупка, перевозка и таможенная координация для поставок в Афганистан и регион.',
      exportTitle: 'Экспорт на новые рынки', exportText: 'Подготовка качества, документов и доставка афганской и региональной продукции международным покупателям.',
      servicesKicker: 'Наши услуги', servicesTitle: 'Современные торговые услуги', servicesIntro: 'Используйте отдельную услугу или объедините их в комплексное решение цепочки поставок.',
      productsKicker: 'Что мы поставляем', productsTitle: 'Продукция без лишних категорий', productsIntro: 'Прямой список с поиском. Если нужного товара нет, отправьте нам спецификацию.',
      whyKicker: 'Почему Khan Boostan', whyTitle: 'Торговля на основе документов и доверия',
      reasons: [
        { title: 'Проверенные контрагенты', text: 'Поставщики и коммерческие документы проверяются до принятия обязательств.' },
        { title: 'Чёткие условия', text: 'Цена, спецификация, Инкотермс, оплата и сроки фиксируются письменно.' },
        { title: 'Трансграничная координация', text: 'Перевозка, таможня, граница и доставка контролируются одной командой.' },
        { title: 'Оперативная связь', text: 'Покупатели и поставщики получают практические обновления на всех этапах.' },
      ],
      marketsKicker: 'Торговые коридоры', marketsTitle: 'Балх связан с региональными рынками', marketsIntro: 'Маршруты в Узбекистан, Китай, Россию, Центральную Азию и другие международные рынки.',
      finalTitle: 'Обсудим следующую поставку?', finalText: 'Сообщите продукт, объём, происхождение и назначение — мы предложим понятную структуру сделки.',
    },
    productsPage: {
      kicker: 'Портфель продукции', title: 'Продукция и товары', intro: 'Все продукты в одном понятном списке без фильтров по категориям. Спецификация, происхождение и условия подтверждаются по запросу.',
      countNote: 'продуктов доступны для запроса', catalogTitle: 'Возможности каталога:', catalogText: 'Список развивается вместе с вашим бизнесом. Если нужного товара нет, отправьте спецификацию — мы найдём проверенные варианты.',
      ctaTitle: 'Нужного продукта нет в списке?', ctaText: 'Сообщите спецификацию, количество и пункт назначения — мы найдём поставщика.',
    },
    servicesPage: {
      kicker: 'Наши услуги', title: 'Торговля и цепочка поставок', intro: 'Единый ответственный партнёр от поставщика до пункта назначения.',
      portfolio: 'Портфель услуг', whatWeDo: 'Что мы делаем', portfolioIntro: 'Комплексные услуги по отдельности или как единое решение.',
      method: 'Методология', methodTitle: 'Структурированный подход', methodText: 'Каждый проект проходит понятные этапы: запрос, проверка, условия, документы, логистика и доставка.',
      extended: 'Дополнительные возможности', extendedTitle: 'Больше основных услуг', discuss: 'Обсудить задачу', finalTitle: 'Какая услуга подходит вашему бизнесу?', finalText: 'Расскажите о задаче — мы предложим структуру, условия и сроки.',
      extendedItems: [['Дистрибуция', 'Региональное распределение и координация каналов.'], ['Цепочка поставок', 'Мониторинг и координация от происхождения до доставки.'], ['Исследование рынка', 'Анализ выхода на рынок, цен и спроса.'], ['Коммерческое представительство', 'Структурированное представительство международных компаний в регионе.']],
    },
    serviceDetail: {
      capabilities: 'Возможности', includes: 'Что входит в услугу', body: 'Услуга предоставляется по документированным этапам и адаптируется к разовым поставкам или долгосрочным программам.',
      workflow: 'Процесс', process: 'Этапы услуги', processIntro: 'Понятная последовательность от запроса до доставки.', other: 'Другие услуги', support: 'Нужна помощь с этой услугой?', supportText: 'Расскажите о задаче — наша команда предложит подходящую структуру.',
    },
    about: {
      kicker: 'О Khan Boostan', title: 'Торговый партнёр из Балха', intro: 'Khan Boostan Limited соединяет производителей, покупателей и рынки через структурированный импорт, экспорт и логистику.',
      storyKicker: 'О компании', storyTitle: 'Местная экспертиза. Международные стандарты.', storyText: 'Работая в Балхе, мы понимаем региональные торговые маршруты и практику поиска поставщиков, таможни и трансграничной доставки. Эти знания сочетаются с документированными коммерческими процессами.',
      missionTitle: 'Наша миссия', missionText: 'Создавать надёжный доступ к рынкам для афганской и региональной продукции и помогать бизнесу закупать и импортировать необходимые товары.',
      visionTitle: 'Наше видение', visionText: 'Стать надёжным торговым мостом между Афганистаном, соседними странами и международными рынками.',
      valuesTitle: 'Как мы работаем', values: ['Прозрачность', 'Документированное качество', 'Коммерческая дисциплина', 'Долгосрочное партнёрство'],
    },
    marketsPage: {
      kicker: 'Рынки', title: 'Региональный охват из Балха', intro: 'Торговые коридоры Афганистана с Узбекистаном, Китаем, Россией и другими рынками.',
      routesTitle: 'Приоритетные направления', note: 'Маршрут, пограничный пункт и условия доставки подтверждаются для каждой поставки.',
      countries: [
        { name: 'Узбекистан', text: 'Ворота Хайратон и автодорожные и железнодорожные связи Центральной Азии.' },
        { name: 'Китай', text: 'Региональные транзитные коридоры для промышленной и потребительской торговли.' },
        { name: 'Россия', text: 'Мультимодальные автомобильные и железнодорожные решения для отдельных товаров.' },
        { name: 'Афганистан', text: 'Поиск, консолидация и распределение из Балха.' },
      ],
    },
    contactPage: {
      kicker: 'Контакты', title: 'Свяжитесь с торговой командой', intro: 'Укажите продукт, объём, происхождение и назначение — мы поможем определить следующий шаг.',
      formTitle: 'Отправить сообщение', detailsTitle: 'Контакты компании', hours: 'Рабочие часы', hoursValue: 'Суббота–четверг · 09:00–17:00',
    },
    quotePage: {
      kicker: 'Запрос цены', title: 'Расскажите, что вам нужно', intro: 'Краткая форма для импорта, экспорта, продукции и логистики.',
      sideTitle: 'Что будет дальше?', steps: ['Мы изучим спецификацию.', 'Уточним недостающие коммерческие детали.', 'Подготовим предложение или план поиска поставщика.'],
    },
    form: {
      name: 'Имя и фамилия', company: 'Компания', email: 'Рабочая эл. почта', phone: 'Телефон / WhatsApp', country: 'Страна', subject: 'Тема', message: 'Сообщение',
      product: 'Продукт / товар', service: 'Необходимая услуга', quantity: 'Количество', origin: 'Предпочтительное происхождение', destination: 'Назначение', incoterm: 'Предпочтительный Инкотермс',
      placeholderName: 'Ваше имя', placeholderCompany: 'Название компании', placeholderEmail: 'name@company.com', placeholderPhone: '+7…', placeholderCountry: 'Страна',
      placeholderSubject: 'Чем мы можем помочь?', placeholderMessage: 'Опишите вашу задачу…', selectProduct: 'Выберите продукт', selectService: 'Выберите услугу',
      submit: 'Отправить запрос', success: 'Спасибо. Ваш запрос подготовлен к отправке.', note: 'Перед публикацией подключите форму к электронной почте или CRM.',
    },
    spec: { origin: 'Происхождение', grade: 'Сорт / качество', packaging: 'Упаковка', moq: 'Минимальный заказ', hs: 'Код HS', terms: 'Условия торговли', lead: 'Срок поставки', certifications: 'Сертификаты' },
    footer: { intro: 'Международная торговля, импорт, экспорт и координация цепочки поставок из Балха, Афганистан.', rights: '© 2026 Khan Boostan Limited. Все права защищены.' },
    legal: {
      kicker: 'Правовая информация', lastUpdated: 'Обновлено: август 2026 г. · Khan Boostan Limited, Мазари-Шариф, Афганистан',
      privacy: { title: 'Политика конфиденциальности', intro: 'Как Khan Boostan Limited обрабатывает предоставленную вами информацию.', sections: [
        ['1. Область действия', 'Политика применяется к данным, полученным через сайт, каналы связи и деловые операции компании.'],
        ['2. Какие данные мы собираем', 'Мы собираем только контактные и коммерческие данные, необходимые для ответа и проведения сделки: продукт, объём, назначение и приложенные документы.'],
        ['3. Использование данных', 'Данные используются для ответов, подготовки предложений, проведения сделок и выполнения требований закона. Мы не продаём и не сдаём персональные данные.'],
        ['4. Передача данных', 'Данные передаются только по необходимости для сделки, например перевозчикам, таможенным представителям или финансовым учреждениям.'],
        ['5. Хранение и безопасность', 'Деловые записи хранятся в установленные законом сроки и защищаются разумными техническими и организационными мерами.'],
        ['6. Ваши права', 'Через страницу контактов можно запросить доступ, исправление или удаление персональных данных.'],
        ['7. Изменения', 'Политика может обновляться; актуальная версия всегда публикуется на этой странице.'],
      ] },
      terms: { title: 'Условия использования', intro: 'Условия использования сайта и деловой переписки компании.', sections: [
        ['1. Содержание сайта', 'Информация на сайте носит общий характер. Характеристики, цены и наличие являются ориентировочными и не образуют обязательного предложения.'],
        ['2. Предложения и договоры', 'Обязательные условия устанавливаются только письменным предложением и подписанным договором, включая спецификации, объёмы, цены, Инкотермс и доставку.'],
        ['3. Интеллектуальная собственность', 'Бренд, логотип, тексты, изображения и дизайн принадлежат Khan Boostan Limited или лицензиарам и не могут воспроизводиться без письменного разрешения.'],
        ['4. Ответственность', 'Мы стремимся поддерживать точность информации, но ответственность по сделке определяется соответствующим письменным договором.'],
        ['5. Внешние ссылки', 'Ссылки на сторонние сайты приводятся для удобства; мы не отвечаем за их содержание или практики.'],
        ['6. Применимое право', 'Условия и деловые отношения регулируются применимым законодательством Афганистана, если письменный договор не предусматривает иное.'],
        ['7. Контакты', 'Вопросы об условиях можно направить руководству через страницу контактов.'],
      ] },
    },
    notFound: { title: 'Страница не найдена', text: 'Нужная страница была перемещена или не существует.', back: 'На главную', contact: 'Связаться с нами' },
  },
}

const productCopy = {
  fa: {
    'milling-wheat': ['گندم آسیابانی', 'گندم باکیفیت برای تولید آرد با کنترول رطوبت و پروتین از تأمین‌کنندگان منطقه‌ای.'],
    'cotton-fiber': ['الیاف پنبه', 'پنبه خام برای کارخانه‌های ریسندگی، در گریدهای معیاری و با مشخصات مستند کیفیت.'],
    'long-grain-rice': ['برنج دانه‌بلند', 'برنج دانه‌بلند ممتاز برای عمده‌فروشی و توزیع با بسته‌بندی‌های مختلف.'],
    'dried-fruits-nuts': ['میوه خشک و مغزیات', 'کشمش، بادام، پسته، زردآلو و محصولات میوه خشک افغانستان برای صادرات.'],
    saffron: ['زعفران', 'رشته‌های زعفران ممتاز برای خریداران بین‌المللی با اسناد قابلیت ردیابی.'],
    'portland-cement': ['سمنت پورتلند', 'سمنت OPC و مرکب برای پروژه‌های ساختمانی به‌صورت بالک و بوجی.'],
    'steel-rebar': ['سیخ گول ساختمانی', 'فولاد تقویتی آج‌دار در قطرهای معیاری برای پروژه‌های ساختمانی و زیربنایی.'],
    'marble-blocks': ['مرمر و سنگ طبیعی', 'بلوک و اسلب مرمر افغانستان و منطقه برای بازارهای بین‌المللی سنگ.'],
    'petroleum-products': ['محصولات نفتی', 'دیزل، پترول، نفت کوره و سایر فرآورده‌های تصفیه‌شده مطابق مشخصات تأییدشده.'],
    coal: ['زغال‌سنگ حرارتی و کک‌شو', 'زغال‌سنگ حرارتی و متالورژیکی برای انرژی و صنعت با گزارش ارزش حرارتی.'],
    'white-sugar': ['شکر سفید', 'شکر سفید تصفیه‌شده برای صنایع و بسته‌بندی خرده‌فروشی مطابق مشخصات ICUMSA.'],
    fertilizers: ['کود کیمیاوی یوریا و DAP', 'یوریا، DAP و کودهای مرکب برای بخش زراعت از تولیدکنندگان معتبر.'],
    'industrial-machinery': ['ماشین‌آلات و تجهیزات صنعتی', 'ماشین‌آلات، خطوط تولید، تجهیزات و پرزه‌جات مطابق نیاز خریدار.'],
  },
  ru: {
    'milling-wheat': ['Мукомольная пшеница', 'Высококачественная пшеница для производства муки с контролем влажности и белка.'],
    'cotton-fiber': ['Хлопковое волокно', 'Сырой хлопок для прядильных фабрик, стандартные сорта и документированные параметры качества.'],
    'long-grain-rice': ['Длиннозёрный рис', 'Премиальный длиннозёрный рис для оптовой и розничной дистрибуции в разных форматах упаковки.'],
    'dried-fruits-nuts': ['Сухофрукты и орехи', 'Изюм, миндаль, фисташки, абрикосы и смеси афганских сухофруктов на экспорт.'],
    saffron: ['Шафран', 'Премиальные нити шафрана для международных покупателей с полной прослеживаемостью.'],
    'portland-cement': ['Портландцемент', 'Цемент OPC и композитный цемент для строительных проектов навалом и в мешках.'],
    'steel-rebar': ['Стальная арматура', 'Рифлёная арматура стандартных диаметров для инфраструктуры и строительства.'],
    'marble-blocks': ['Мрамор и натуральный камень', 'Мраморные блоки и слэбы афганских и региональных сортов для экспорта.'],
    'petroleum-products': ['Нефтепродукты', 'Дизель, бензин, мазут и другие продукты нефтепереработки по подтверждённой спецификации.'],
    coal: ['Энергетический и коксующийся уголь', 'Тепловой и металлургический уголь с отчётностью по теплотворной способности.'],
    'white-sugar': ['Белый сахар', 'Рафинированный белый сахар для промышленной и розничной фасовки по ICUMSA.'],
    fertilizers: ['Удобрения: карбамид и DAP', 'Карбамид, DAP и комплексные удобрения от проверенных производителей.'],
    'industrial-machinery': ['Промышленное оборудование', 'Оборудование, производственные линии и запасные части по спецификации покупателя.'],
  },
}

const valueCopy = {
  fa: {
    'Afghanistan / Central Asia': 'افغانستان / آسیای میانه', Afghanistan: 'افغانستان', 'Regional origins': 'مبدأهای منطقه‌ای', 'Regional refineries': 'تصفیه‌خانه‌های منطقه', 'International origins': 'مبدأهای بین‌المللی',
    'Bulk / 50 kg bags': 'بالک / بوجی ۵۰ کیلویی', 'High-density bales': 'عدل‌های فشرده', '10 / 25 / 50 kg bags': 'بوجی‌های ۱۰ / ۲۵ / ۵۰ کیلویی',
    'Cartons / bulk vacuum packs': 'کارتن / بسته وکیوم عمده', '1g – 1kg sealed packs': 'بسته‌های مهرشده ۱ گرام تا ۱ کیلو', Bundles: 'بندل',
    'Bulk / tanker lots': 'بالک / محموله تانکری', 'Bulk / rail / truck lots': 'بالک / ریل / موتر', '50 kg bags / bulk': 'بوجی ۵۰ کیلویی / بالک', 'Export crating': 'صندوق‌بندی صادراتی',
    '2 – 6 weeks from confirmation': '۲ تا ۶ هفته پس از تأیید', '3 – 6 weeks from confirmation': '۳ تا ۶ هفته پس از تأیید', '2 – 5 weeks from confirmation': '۲ تا ۵ هفته پس از تأیید',
    '2 – 4 weeks from confirmation': '۲ تا ۴ هفته پس از تأیید', '1 – 3 weeks from confirmation': '۱ تا ۳ هفته پس از تأیید', '3 – 8 weeks from confirmation': '۳ تا ۸ هفته پس از تأیید', '4 – 8 weeks from confirmation': '۴ تا ۸ هفته پس از تأیید', '6 – 12 weeks from confirmation': '۶ تا ۱۲ هفته پس از تأیید',
    '[To be confirmed with supplier]': '[با تأمین‌کننده تأیید می‌شود]',
  },
  ru: {
    'Afghanistan / Central Asia': 'Афганистан / Центральная Азия', Afghanistan: 'Афганистан', 'Regional origins': 'Региональное происхождение', 'Regional refineries': 'Региональные НПЗ', 'International origins': 'Международное происхождение',
    'Bulk / 50 kg bags': 'Навалом / мешки 50 кг', 'High-density bales': 'Тюки высокой плотности', '10 / 25 / 50 kg bags': 'Мешки 10 / 25 / 50 кг',
    'Cartons / bulk vacuum packs': 'Коробки / вакуумная оптовая упаковка', '1g – 1kg sealed packs': 'Герметичные упаковки 1 г–1 кг', Bundles: 'Связки',
    'Bulk / tanker lots': 'Навалом / автоцистерны', 'Bulk / rail / truck lots': 'Навалом / ж/д / авто', '50 kg bags / bulk': 'Мешки 50 кг / навалом', 'Export crating': 'Экспортная обрешётка',
    '2 – 6 weeks from confirmation': '2–6 недель после подтверждения', '3 – 6 weeks from confirmation': '3–6 недель после подтверждения', '2 – 5 weeks from confirmation': '2–5 недель после подтверждения',
    '2 – 4 weeks from confirmation': '2–4 недели после подтверждения', '1 – 3 weeks from confirmation': '1–3 недели после подтверждения', '3 – 8 weeks from confirmation': '3–8 недель после подтверждения', '4 – 8 weeks from confirmation': '4–8 недель после подтверждения', '6 – 12 weeks from confirmation': '6–12 недель после подтверждения',
    '[To be confirmed with supplier]': '[Подтверждается поставщиком]',
  },
}

const serviceCopy = {
  fa: {
    import: { title: 'واردات', oneLiner: 'ورود کالا به بازار با سورسینگ، بررسی و تحویل منظم.', blurb: 'تمام چرخه واردات را مدیریت می‌کنیم: یافتن تأمین‌کننده، بررسی، خرید، حمل، گمرک، گدام و توزیع.', features: ['سورسینگ بین‌المللی', 'بررسی تأمین‌کننده', 'مذاکره قیمت و خرید', 'هماهنگی حمل', 'گمرک و ترخیص', 'گدام و توزیع'], steps: [['تعیین نیاز', 'محصول، مشخصات، مقدار و مقصد تعیین می‌شود.'], ['انتخاب تأمین‌کننده', 'تأمین‌کنندگان مناسب شناسایی می‌شوند.'], ['بررسی و اعتبارسنجی', 'اسناد، ظرفیت و اعتبار بررسی می‌شود.'], ['مذاکره و خرید', 'شرایط تجارتی توافق و خرید اجرا می‌شود.'], ['حمل و گمرک', 'انتقال، اسناد و ترخیص هماهنگ می‌شود.'], ['گدام و توزیع', 'کالا دریافت و به مقصد نهایی تحویل می‌شود.']] },
    export: { title: 'صادرات', oneLiner: 'انتقال محصولات افغانستان و منطقه به بازارهای بین‌المللی.', blurb: 'از تهیه محصول و کنترول کیفیت تا بسته‌بندی، اسناد صادرات، گمرک و تحویل بین‌المللی را هماهنگ می‌کنیم.', features: ['تهیه و تجمیع محصول', 'کنترول و بازرسی کیفیت', 'بسته‌بندی صادراتی', 'اسناد صادرات', 'مراحل گمرک', 'انتقال و تحویل بین‌المللی'], steps: [['تهیه محصول', 'کیفیت و مقدار مناسب تهیه و تجمیع می‌شود.'], ['کنترول کیفیت', 'محصول مطابق مشخصات خریدار بررسی می‌شود.'], ['بسته‌بندی', 'بسته‌بندی و لیبل صادراتی آماده می‌شود.'], ['اسناد صادرات', 'اسناد تجارتی، گمرکی و حمل تهیه می‌گردد.'], ['گمرک و ترخیص', 'تصفیه صادرات در مبدأ انجام می‌شود.'], ['انتقال و تحویل', 'محموله تا خریدار بین‌المللی پیگیری می‌شود.']] },
    trading: { title: 'تجارت بین‌المللی', oneLiner: 'معاملات منظم خرید و فروش میان بازارها.', blurb: 'به‌عنوان طرف اصلی معامله، اسناد، پرداخت و جریان تجارتی میان خریدار و تأمین‌کننده را تنظیم می‌کنیم.', features: ['تجارت کالا', 'ساختار معامله', 'اسناد تجارتی', 'هماهنگی پرداخت', 'تحقیق بازار و قیمت', 'نمایندگی تجارتی'] },
    sourcing: { title: 'سورسینگ', oneLiner: 'تأمین‌کننده مناسب را پیدا، بررسی و تثبیت می‌کنیم.', blurb: 'برای خریدارانی که به تأمین‌کننده مطمئن نیاز دارند، تحقیق، بررسی، مذاکره و کنترول کیفیت را انجام می‌دهیم.', features: ['تحلیل نیاز مشتری', 'تحقیق بازار', 'شناسایی تأمین‌کننده', 'بررسی تأمین‌کننده', 'مذاکره قیمت', 'بررسی کیفیت', 'مدیریت خرید', 'انتقال تا مقصد'] },
    procurement: { title: 'تدارکات', oneLiner: 'خرید منظم برای شرکت‌ها و مؤسسات.', blurb: 'چرخه حرفه‌ای تدارکات، از مشخصات و ارزیابی پیشنهادها تا مدیریت سفارش و تحویل.', features: ['برنامه‌ریزی مشخصات', 'ارزیابی تأمین‌کننده', 'مقایسه پیشنهادها', 'مدیریت سفارش', 'کنترول کیفیت', 'تحویل و اسناد'] },
    logistics: { title: 'لجستیک و زنجیره تأمین', oneLiner: 'انتقال کالا از مرزها با جاده، ریل، بحر و هوا.', blurb: 'هماهنگی چندنوعی حمل در افغانستان و منطقه شامل جاده، ریل، بحر، هوا، گدام، گمرک و مدیریت محموله مرزی.', features: ['انتقال جاده‌ای', 'انتقال ریلی', 'حمل بحری', 'حمل هوایی', 'گدام', 'هماهنگی گمرک', 'مدیریت بار', 'لجستیک مرزی'] },
  },
  ru: {
    import: { title: 'Импорт', oneLiner: 'Поставка товаров на рынок: поиск, проверка и доставка.', blurb: 'Мы управляем полным циклом импорта: поиск поставщика, проверка, закупка, перевозка, таможня, склад и распределение.', features: ['Международный поиск', 'Проверка поставщика', 'Переговоры и закупка', 'Координация перевозки', 'Таможня и оформление', 'Склад и распределение'], steps: [['Определение потребности', 'Определяем продукт, спецификацию, объём и назначение.'], ['Выбор поставщика', 'Формируем список подходящих поставщиков.'], ['Проверка', 'Проверяем документы, возможности и репутацию.'], ['Переговоры и закупка', 'Согласуем условия и оформляем заказ.'], ['Перевозка и таможня', 'Координируем фрахт, документы и оформление.'], ['Склад и распределение', 'Принимаем и доставляем товар до конечной точки.']] },
    export: { title: 'Экспорт', oneLiner: 'Вывод афганской и региональной продукции на международные рынки.', blurb: 'От поиска продукции и контроля качества до упаковки, экспортных документов, таможни и международной доставки.', features: ['Поиск и консолидация', 'Контроль качества', 'Экспортная упаковка', 'Экспортные документы', 'Таможенные процедуры', 'Международная доставка'], steps: [['Поиск продукции', 'Формируем нужное качество и объём.'], ['Контроль качества', 'Проверяем по спецификации покупателя.'], ['Упаковка', 'Готовим экспортную упаковку и маркировку.'], ['Документы', 'Оформляем коммерческие, таможенные и транспортные документы.'], ['Таможня', 'Проходим экспортное оформление в стране происхождения.'], ['Доставка', 'Организуем международную перевозку покупателю.']] },
    trading: { title: 'Международная торговля', oneLiner: 'Структурированные сделки купли-продажи между рынками.', blurb: 'Мы выступаем торговым контрагентом и структурируем документы, расчёты и движение товара.', features: ['Торговля товарами', 'Структурирование сделок', 'Торговые документы', 'Координация оплаты', 'Анализ рынка и цен', 'Коммерческое представительство'] },
    sourcing: { title: 'Поиск поставщиков', oneLiner: 'Находим, проверяем и закрепляем подходящих поставщиков.', blurb: 'Исследование, проверка, переговоры и контроль качества для покупателей, которым нужен надёжный поставщик.', features: ['Анализ потребности', 'Исследование рынка', 'Поиск поставщика', 'Проверка поставщика', 'Переговоры', 'Контроль качества', 'Управление закупкой', 'Логистика до назначения'] },
    procurement: { title: 'Закупки', oneLiner: 'Структурированные закупки для бизнеса и учреждений.', blurb: 'Профессиональный цикл закупок: спецификация, сравнение предложений, управление заказом и доставка.', features: ['Планирование требований', 'Оценка поставщиков', 'Сравнение предложений', 'Управление заказом', 'Контроль соответствия', 'Доставка и документы'] },
    logistics: { title: 'Логистика и цепочка поставок', oneLiner: 'Перемещение грузов через границы автотранспортом, ж/д, морем и авиацией.', blurb: 'Мультимодальная логистика по Афганистану и региону: автотранспорт, ж/д, море, авиация, склады, таможня и трансграничные грузы.', features: ['Автоперевозки', 'Железнодорожные перевозки', 'Морской фрахт', 'Авиаперевозки', 'Складирование', 'Таможенная координация', 'Обработка грузов', 'Трансграничная логистика'] },
  },
}

const literalCopy = {
  fa: {
    'News & Insights': 'اخبار و تحلیل‌ها', 'Trade intelligence': 'دانش و تحلیل تجارت', 'FAQ': 'پرسش‌های متداول', 'Questions & answers': 'پرسش و پاسخ',
    Industries: 'صنایع', 'Industries we serve': 'صنایعی که خدمت می‌کنیم', Projects: 'پروژه‌ها', 'Projects & activities': 'پروژه‌ها و فعالیت‌ها',
    Partnership: 'همکاری', 'Partners & network': 'همکاران و شبکه', Compliance: 'اسناد و تطبیق', 'Certificates & documents': 'تصدیق‌نامه‌ها و اسناد',
    'Request a Quote': 'درخواست نرخ', 'Tell us what you need': 'نیازتان را برای ما بنویسید', Contact: 'تماس', 'Talk to our team': 'با تیم ما صحبت کنید',
  },
  ru: {
    'News & Insights': 'Новости и аналитика', 'Trade intelligence': 'Торговая аналитика', FAQ: 'Частые вопросы', 'Questions & answers': 'Вопросы и ответы',
    Industries: 'Отрасли', 'Industries we serve': 'Отрасли, которые мы обслуживаем', Projects: 'Проекты', 'Projects & activities': 'Проекты и деятельность',
    Partnership: 'Партнёрство', 'Partners & network': 'Партнёры и сеть', Compliance: 'Документы', 'Certificates & documents': 'Сертификаты и документы',
    'Request a Quote': 'Запрос цены', 'Tell us what you need': 'Расскажите, что вам нужно', Contact: 'Контакты', 'Talk to our team': 'Свяжитесь с нашей командой',
  },
}

function readPath(obj, path) {
  return path.split('.').reduce((value, key) => value?.[key], obj)
}

function localizeProducts(language) {
  return sourceProducts.map((product) => {
    const pair = productCopy[language]?.[product.slug]
    const values = valueCopy[language] || {}
    return {
      ...product,
      name: pair?.[0] || product.name,
      blurb: pair?.[1] || product.blurb,
      origin: values[product.origin] || product.origin,
      packaging: values[product.packaging] || product.packaging,
      leadTime: values[product.leadTime] || product.leadTime,
      certifications: values[product.certifications] || product.certifications,
    }
  })
}

function localizeServices(language) {
  return sourceServices.map((service) => {
    const copy = serviceCopy[language]?.[service.slug]
    if (!copy) return service
    return {
      ...service,
      ...copy,
      steps: copy.steps ? copy.steps.map(([t, d]) => ({ t, d })) : service.steps,
    }
  })
}

function localizeCompany(language) {
  if (language === 'fa') return { ...sourceCompany, tagline: 'بازارها را وصل می‌کنیم. فرصت‌ها را می‌سازیم.', intro: messages.fa.about.intro, address: 'مزارشریف، بلخ، افغانستان', businessLines: ['واردات', 'صادرات', 'تجارت بین‌المللی', 'سورسینگ', 'تدارکات', 'لجستیک'] }
  if (language === 'ru') return { ...sourceCompany, tagline: 'Соединяем рынки. Создаём возможности.', intro: messages.ru.about.intro, address: 'Мазари-Шариф, Балх, Афганистан', businessLines: ['Импорт', 'Экспорт', 'Международная торговля', 'Поиск поставщиков', 'Закупки', 'Логистика'] }
  return sourceCompany
}


function localizeCmsItems(items, language) {
  return items.map((item) => ({ ...item, ...(item.translations?.[language] || {}) }))
}

function createValue(language, setLanguage = () => {}) {
  const meta = languages.find((item) => item.code === language) || languages[0]
  return {
    language,
    dir: meta.dir,
    setLanguage,
    languages,
    t: (key, fallback) => readPath(messages[language], key) ?? readPath(messages.en, key) ?? fallback ?? key,
    tx: (text) => literalCopy[language]?.[text] || text,
    products: localizeProducts(language),
    services: localizeServices(language),
    tradeCorridors: localizeCmsItems(sourceTradeCorridors, language),
    homeStories: localizeCmsItems(sourceHomeStories, language),
    company: localizeCompany(language),
  }
}

const LanguageContext = createContext(createValue('en'))

export function LanguageProvider({ children, initialLanguage }) {
  const cmsData = useSelector((state) => state.content.data)
  const [language, setLanguage] = useState(() => {
    if (languages.some((item) => item.code === initialLanguage)) return initialLanguage
    if (typeof window === 'undefined') return 'en'
    const saved = window.localStorage.getItem('khanboostan-language')
    return languages.some((item) => item.code === saved) ? saved : 'en'
  })

  useEffect(() => {
    const meta = languages.find((item) => item.code === language) || languages[0]
    document.documentElement.lang = language
    document.documentElement.dir = meta.dir
    document.body.dir = meta.dir
    window.localStorage.setItem('khanboostan-language', language)
  }, [language])

  const value = useMemo(() => {
    if (cmsData) hydrateSiteData(cmsData)
    return createValue(language, setLanguage)
  }, [language, cmsData])
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useI18n() {
  return useContext(LanguageContext)
}
