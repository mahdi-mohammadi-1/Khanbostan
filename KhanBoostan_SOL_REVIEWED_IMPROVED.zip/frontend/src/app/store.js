import { configureStore } from '@reduxjs/toolkit'
import contentReducer from '../features/content/contentSlice.js'
import authReducer from '../features/auth/authSlice.js'

export const store = configureStore({ reducer: { content: contentReducer, auth: authReducer }, devTools: import.meta.env.DEV })
