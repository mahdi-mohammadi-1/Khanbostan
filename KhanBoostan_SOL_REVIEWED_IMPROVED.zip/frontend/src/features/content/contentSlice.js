import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import http from '../../services/http.js'

export const fetchSiteBootstrap = createAsyncThunk(
  'content/fetchSiteBootstrap',
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await http.get('/site/bootstrap')
      return data.data || data
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message)
    }
  },
  {
    condition: (_, { getState }) => !['loading', 'succeeded'].includes(getState().content.status),
  },
)

const slice = createSlice({
  name: 'content',
  initialState: { data: null, status: 'idle', error: null },
  reducers: { retryBootstrap: (state) => { state.status = 'idle'; state.error = null } },
  extraReducers: (builder) => builder
    .addCase(fetchSiteBootstrap.pending, (state) => { state.status = 'loading'; state.error = null })
    .addCase(fetchSiteBootstrap.fulfilled, (state, action) => { state.status = 'succeeded'; state.data = action.payload })
    .addCase(fetchSiteBootstrap.rejected, (state, action) => { state.status = 'failed'; state.error = action.payload }),
})

export const { retryBootstrap } = slice.actions
export default slice.reducer
