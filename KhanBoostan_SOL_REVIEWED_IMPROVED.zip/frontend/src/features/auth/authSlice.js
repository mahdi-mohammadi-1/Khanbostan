import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import http, { TOKEN_KEY } from '../../services/http.js'

export const loginAdmin = createAsyncThunk('auth/login', async (credentials, { rejectWithValue }) => {
  try {
    const { data } = await http.post('/admin/login', credentials)
    window.localStorage.setItem(TOKEN_KEY, data.token)
    return data
  } catch (error) {
    return rejectWithValue(error.response?.data?.message || 'Login failed')
  }
})

export const logoutAdmin = createAsyncThunk('auth/logout', async () => {
  try {
    await http.post('/admin/logout')
  } finally {
    window.localStorage.removeItem(TOKEN_KEY)
  }
})

const slice = createSlice({
  name: 'auth',
  initialState: { token: window.localStorage.getItem(TOKEN_KEY), user: null, status: 'idle', error: null },
  reducers: {
    logoutLocal: (state) => {
      state.token = null
      state.user = null
      window.localStorage.removeItem(TOKEN_KEY)
    },
  },
  extraReducers: (builder) => builder
    .addCase(loginAdmin.pending, (state) => { state.status = 'loading'; state.error = null })
    .addCase(loginAdmin.fulfilled, (state, action) => { state.status = 'succeeded'; state.token = action.payload.token; state.user = action.payload.user })
    .addCase(loginAdmin.rejected, (state, action) => { state.status = 'failed'; state.error = action.payload })
    .addCase(logoutAdmin.fulfilled, (state) => { state.token = null; state.user = null; state.status = 'idle' }),
})

export const { logoutLocal } = slice.actions
export default slice.reducer
