import { Suspense, lazy, useEffect } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useDispatch, useSelector } from 'react-redux'
import Header from './components/Header.jsx'
import Footer from './components/Footer.jsx'
import { useI18n } from './i18n.jsx'
import { fetchSiteBootstrap, retryBootstrap } from './features/content/contentSlice.js'

const Home = lazy(() => import('./pages/Home.jsx'))
const About = lazy(() => import('./pages/About.jsx'))
const Products = lazy(() => import('./pages/Products.jsx'))
const ProductDetail = lazy(() => import('./pages/ProductDetail.jsx'))
const Services = lazy(() => import('./pages/Services.jsx'))
const ServiceImport = lazy(() => import('./pages/ServiceImport.jsx'))
const ServiceExport = lazy(() => import('./pages/ServiceExport.jsx'))
const ServiceSourcing = lazy(() => import('./pages/ServiceSourcing.jsx'))
const ServiceLogistics = lazy(() => import('./pages/ServiceLogistics.jsx'))
const Markets = lazy(() => import('./pages/Markets.jsx'))
const Industries = lazy(() => import('./pages/Industries.jsx'))
const Projects = lazy(() => import('./pages/Projects.jsx'))
const Partners = lazy(() => import('./pages/Partners.jsx'))
const Certificates = lazy(() => import('./pages/Certificates.jsx'))
const News = lazy(() => import('./pages/News.jsx'))
const Article = lazy(() => import('./pages/Article.jsx'))
const Faq = lazy(() => import('./pages/Faq.jsx'))
const RequestQuote = lazy(() => import('./pages/RequestQuote.jsx'))
const Contact = lazy(() => import('./pages/Contact.jsx'))
const Legal = lazy(() => import('./pages/Legal.jsx'))
const NotFound = lazy(() => import('./pages/NotFound.jsx'))
const AdminLogin = lazy(() => import('./pages/admin/AdminLogin.jsx'))
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard.jsx'))

function PageLoader() {
  const { t } = useI18n()
  return <div className="flex min-h-[60vh] items-center justify-center bg-ink-950"><div className="h-10 w-10 animate-spin rounded-full border-2 border-gold-500/20 border-t-gold-500" aria-label={t('common.loading')} /></div>
}

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'auto' }) }, [pathname])
  return null
}

function ApiStatusBanner() {
  const dispatch = useDispatch()
  const { status, error } = useSelector((state) => state.content)
  if (status !== 'failed') return null
  return (
    <div className="fixed inset-x-0 top-0 z-[100] flex items-center justify-center gap-3 bg-red-950 px-4 py-2 text-center text-xs text-red-100 shadow-lg">
      <span>Backend API is unavailable: {error}</span>
      <button type="button" className="rounded-full border border-red-200/30 px-3 py-1 font-semibold" onClick={() => { dispatch(retryBootstrap()); dispatch(fetchSiteBootstrap()) }}>Retry</button>
    </div>
  )
}

export default function App() {
  const location = useLocation()
  const isAdmin = location.pathname.startsWith('/admin')

  return (
    <div className="min-h-screen bg-ink-950">
      <ScrollToTop />
      <ApiStatusBanner />
      {!isAdmin && <Header />}
      <AnimatePresence mode="wait">
        <motion.main key={location.pathname} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.22 }}>
          <Suspense fallback={<PageLoader />}>
            <Routes location={location}>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/products" element={<Products />} />
              <Route path="/products/:slug" element={<ProductDetail />} />
              <Route path="/services" element={<Services />} />
              <Route path="/services/import" element={<ServiceImport />} />
              <Route path="/services/export" element={<ServiceExport />} />
              <Route path="/services/sourcing" element={<ServiceSourcing />} />
              <Route path="/services/logistics" element={<ServiceLogistics />} />
              <Route path="/markets" element={<Markets />} />
              <Route path="/industries" element={<Industries />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/partners" element={<Partners />} />
              <Route path="/certificates" element={<Certificates />} />
              <Route path="/news" element={<News />} />
              <Route path="/news/:slug" element={<Article />} />
              <Route path="/faq" element={<Faq />} />
              <Route path="/request-quote" element={<RequestQuote />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/privacy" element={<Legal page="privacy" />} />
              <Route path="/terms" element={<Legal page="terms" />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </motion.main>
      </AnimatePresence>
      {!isAdmin && <Footer />}
    </div>
  )
}
