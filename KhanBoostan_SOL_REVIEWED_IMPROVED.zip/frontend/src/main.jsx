import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { Provider } from 'react-redux'
import { store } from './app/store.js'
import { AppProvider } from './context/AppContext.jsx'
import SiteBootstrap from './components/system/SiteBootstrap.jsx'
import App from './App.jsx'
import './index.css'
import { LanguageProvider } from './i18n.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      <AppProvider>
        <LanguageProvider>
          <SiteBootstrap />
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </LanguageProvider>
      </AppProvider>
    </Provider>
  </React.StrictMode>,
)
