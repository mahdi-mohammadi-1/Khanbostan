import { motion } from 'framer-motion'
import { Breadcrumb } from './UI.jsx'
import { useI18n } from '../i18n.jsx'

const EASE = [0.22, 1, 0.36, 1]

/** Dark hero banner used on every inner page */
export default function PageHeader({ kicker, title, intro, image, crumbs, children }) {
  const { tx } = useI18n()
  const localizedCrumbs = crumbs?.map((item) => ({ ...item, label: tx(item.label) }))
  return (
    <section className="relative overflow-hidden bg-ink-950 pt-[76px]">
      {/* background */}
      <div className="absolute inset-0">
        {image && (
          <motion.img
            src={image}
            alt=""
            initial={{ scale: 1.08 }}
            animate={{ scale: 1 }}
            transition={{ duration: 8, ease: 'easeOut' }}
            className="h-full w-full object-cover opacity-40"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/85 via-ink-950/60 to-ink-950" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/90 via-transparent to-ink-950/40" />
        <div className="grain-overlay absolute inset-0" />
      </div>

      <div className="container-x relative py-20 sm:py-28">
        {localizedCrumbs && <Breadcrumb items={localizedCrumbs} />}
        <div className="max-w-3xl">
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05, ease: EASE }}
            className="overline mb-5 flex items-center gap-4"
          >
            <span className="h-px w-10 bg-gold-500" />
            {tx(kicker)}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.12, ease: EASE }}
            className="display text-5xl text-white sm:text-6xl lg:text-7xl"
          >
            {tx(title)}
          </motion.h1>
          {intro && (
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.22, ease: EASE }}
              className="mt-6 max-w-2xl text-[16.5px] leading-relaxed text-white/60"
            >
              {tx(intro)}
            </motion.p>
          )}
          {children && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3, ease: EASE }}
              className="mt-8 flex flex-wrap gap-4"
            >
              {children}
            </motion.div>
          )}
        </div>
      </div>
    </section>
  )
}
