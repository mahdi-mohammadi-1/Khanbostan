import { Link } from 'react-router-dom'
import { ArrowUpRight, Mail, MapPin, MessageCircle, Phone } from 'lucide-react'
import { useI18n } from '../i18n.jsx'

export default function Footer() {
  const { t, company } = useI18n()
  const columns = [
    { title: t('common.company'), links: [[t('nav.about'), '/about'], [t('nav.markets'), '/markets'], [t('nav.contact'), '/contact']] },
    { title: t('common.trade'), links: [[t('nav.products'), '/products'], [t('nav.import'), '/services/import'], [t('nav.export'), '/services/export'], [t('nav.services'), '/services']] },
    { title: t('common.support'), links: [[t('common.requestQuote'), '/request-quote'], [t('nav.contact'), '/contact']] },
  ]

  return (
    <footer className="relative overflow-hidden border-t border-white/[0.07] bg-ink-950">
      <div className="grain-overlay pointer-events-none absolute inset-0 opacity-60" />
      <div className="container-x relative">
        <div className="grid grid-cols-1 gap-12 py-16 md:grid-cols-2 lg:grid-cols-[1.45fr_0.8fr_0.8fr_0.8fr_1.2fr] lg:gap-8">
          <div>
            <Link to="/" className="flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-white ring-1 ring-white/20">
                <img src="/img/logo.png" alt="Khan Boostan Limited" className="h-full w-full object-cover" width={48} height={48} />
              </span>
              <span className="leading-none">
                <span className="display block text-[22px] tracking-[0.04em] text-white">Khan <span className="text-gold-400">Boostan</span></span>
                <span className="block font-display text-[11px] font-medium uppercase tracking-[0.42em] text-white/50">Limited</span>
              </span>
            </Link>
            <p className="mt-5 max-w-sm text-[14px] leading-relaxed text-white/50">{t('footer.intro')}</p>
          </div>

          {columns.map((column) => (
            <nav key={column.title} aria-label={column.title}>
              <p className="mb-5 font-display text-[13px] font-semibold uppercase tracking-[0.26em] text-gold-500">{column.title}</p>
              <ul className="space-y-3">
                {column.links.map(([label, to]) => (
                  <li key={to}>
                    <Link to={to} className="group inline-flex items-center gap-1.5 text-[14px] text-white/55 transition hover:text-white">
                      {label}<ArrowUpRight className="h-3 w-3 opacity-0 transition group-hover:opacity-100" />
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}

          <div>
            <p className="mb-5 font-display text-[13px] font-semibold uppercase tracking-[0.26em] text-gold-500">{t('nav.contact')}</p>
            <ul className="space-y-4 text-[14px] text-white/55">
              {company.address && <li className="flex gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" /><span>{company.address}</span></li>}
              {company.phone && <li className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" /><a href={`tel:${company.phone.replace(/[^+\d]/g, '')}`} className="hover:text-white">{company.phone}</a></li>}
              {company.email && <li className="flex gap-3"><Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" /><a href={`mailto:${company.email}`} className="hover:text-white">{company.email}</a></li>}
              {company.whatsapp && <li className="flex gap-3"><MessageCircle className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" /><a href={`https://wa.me/${company.whatsapp.replace(/[^\d]/g, '')}`} target="_blank" rel="noreferrer" className="hover:text-white">{t('common.whatsapp')}</a></li>}
            </ul>
          </div>
        </div>

        <div className="pointer-events-none select-none overflow-hidden border-t border-white/[0.06] py-5" aria-hidden="true">
          <p className="display whitespace-nowrap text-center text-[10vw] leading-none text-white/[0.035]">Khan Boostan</p>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] py-6 sm:flex-row">
          <p className="text-[13px] text-white/40">{t('footer.rights')}</p>
          <div className="flex items-center gap-6 text-[13px] text-white/40">
            <Link to="/privacy" className="hover:text-gold-300">{t('common.privacy')}</Link>
            <Link to="/terms" className="hover:text-gold-300">{t('common.terms')}</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
