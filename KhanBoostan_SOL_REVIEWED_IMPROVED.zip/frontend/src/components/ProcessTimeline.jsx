import { motion } from 'framer-motion'
import { Container, FileCheck2, Handshake, MapPinCheck, MessageSquareText, SearchCheck } from 'lucide-react'
import { Reveal, Stagger, StaggerItem } from './Reveal.jsx'

const ICONS = { MessageSquareText, SearchCheck, Handshake, FileCheck2, Container, MapPinCheck }

const COLS = {
  3: 'lg:grid-cols-3',
  4: 'lg:grid-cols-4',
  5: 'lg:grid-cols-5',
  6: 'lg:grid-cols-6',
}

/** Horizontal animated process timeline (desktop) / vertical (mobile) */
export default function ProcessTimeline({ steps, dark = false, cols = 6 }) {
  return (
    <div>
      {/* Desktop */}
      <div className={`relative hidden lg:block`}>
        {/* track line */}
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
          className={`absolute left-[4%] right-[4%] top-[26px] h-px origin-left ${dark ? 'bg-gradient-to-r from-gold-500/60 via-gold-500/25 to-gold-500/60' : 'bg-gradient-to-r from-gold-500/50 via-ink-950/15 to-gold-500/50'}`}
        />
        <Stagger className={`grid gap-6 ${COLS[cols] || 'lg:grid-cols-6'}`} gap={0.09}>
          {steps.map((s, i) => {
            const Icon = ICONS[s.icon] || SearchCheck
            return (
              <StaggerItem key={i} className="relative">
                <div className="group">
                  <span
                    className={`relative z-10 mb-5 flex h-[52px] w-[52px] items-center justify-center rounded-full border transition-all duration-500 ${
                      dark
                        ? 'border-gold-500/40 bg-ink-900 text-gold-400 group-hover:bg-gold-500 group-hover:text-ink-950'
                        : 'border-ink-950/15 bg-white text-ink-800 shadow-card group-hover:border-gold-500 group-hover:bg-gold-500 group-hover:text-ink-950'
                    }`}
                  >
                    <Icon className="h-[22px] w-[22px]" />
                  </span>
                  <span className={`display block text-[13px] tracking-[0.2em] ${dark ? 'text-white/35' : 'text-neutral-300'}`}>
                    STEP {String(i + 1).padStart(2, '0')}
                  </span>
                  <h3 className={`display mt-1 text-xl ${dark ? 'text-white' : 'text-ink-900'}`}>{s.t}</h3>
                  <p className={`mt-2 text-[13px] leading-relaxed ${dark ? 'text-white/50' : 'text-neutral-500'}`}>{s.d}</p>
                </div>
              </StaggerItem>
            )
          })}
        </Stagger>
      </div>

      {/* Mobile / tablet */}
      <div className="relative lg:hidden">
        <div className={`absolute bottom-6 left-[25px] top-6 w-px ${dark ? 'bg-gold-500/25' : 'bg-ink-950/10'}`} />
        <Stagger className="space-y-8" gap={0.07}>
          {steps.map((s, i) => {
            const Icon = ICONS[s.icon] || SearchCheck
            return (
              <StaggerItem key={i} className="relative flex gap-5">
                <span
                  className={`relative z-10 flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-full border ${
                    dark ? 'border-gold-500/40 bg-ink-900 text-gold-400' : 'border-ink-950/15 bg-white text-ink-800 shadow-card'
                  }`}
                >
                  <Icon className="h-[22px] w-[22px]" />
                </span>
                <div className="pt-1.5">
                  <span className={`display block text-[12px] tracking-[0.2em] ${dark ? 'text-white/35' : 'text-neutral-300'}`}>
                    STEP {String(i + 1).padStart(2, '0')}
                  </span>
                  <h3 className={`display mt-0.5 text-xl ${dark ? 'text-white' : 'text-ink-900'}`}>{s.t}</h3>
                  <p className={`mt-1.5 text-[13.5px] leading-relaxed ${dark ? 'text-white/50' : 'text-neutral-500'}`}>{s.d}</p>
                </div>
              </StaggerItem>
            )
          })}
        </Stagger>
      </div>
    </div>
  )
}
