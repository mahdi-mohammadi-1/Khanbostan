import { useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, useMotionValueEvent, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, Box, FileCheck2, Globe2, MapPin, PackageCheck, Route, Search, Truck } from 'lucide-react'
import { useI18n } from '../../i18n.jsx'

const NODES = {
  afghanistan: { x: 49, y: 54, label: 'Afghanistan' },
  uzbekistan: { x: 48, y: 27, label: 'Uzbekistan' },
  turkmenistan: { x: 29, y: 38, label: 'Turkmenistan' },
  tajikistan: { x: 65, y: 31, label: 'Tajikistan' },
  iran: { x: 20, y: 63, label: 'Iran' },
  pakistan: { x: 67, y: 68, label: 'Pakistan' },
  china: { x: 84, y: 42, label: 'China' },
}

function buildRoute(corridors = []) {
  const destinations = corridors.map((item) => item.slug).filter((slug) => slug && NODES[slug])
  if (!destinations.length) return ['afghanistan', 'afghanistan']
  return destinations.reduce((route, destination) => [...route, destination, 'afghanistan'], ['afghanistan'])
}

const stageMeta = [
  { key: 'origin', icon: Globe2, kicker: 'Regional trade hub' },
  { key: 'source', icon: Search, kicker: 'Source & verify' },
  { key: 'procure', icon: PackageCheck, kicker: 'Procure & consolidate' },
  { key: 'move', icon: Truck, kicker: 'Move across borders' },
  { key: 'documents', icon: FileCheck2, kicker: 'Documents & customs' },
  { key: 'deliver', icon: Box, kicker: 'Deliver in Afghanistan' },
]

function pointAt(progress, route) {
  const totalSegments = route.length - 1
  const scaled = Math.min(0.999999, Math.max(0, progress)) * totalSegments
  const segment = Math.min(totalSegments - 1, Math.floor(scaled))
  const local = scaled - segment
  const a = NODES[route[segment]]
  const b = NODES[route[segment + 1]]
  return {
    x: a.x + (b.x - a.x) * local,
    y: a.y + (b.y - a.y) * local,
    angle: Math.atan2(b.y - a.y, b.x - a.x) * (180 / Math.PI),
    destination: route[segment + 1],
  }
}

function TruckMarker({ progress, route }) {
  const x = useTransform(progress, (value) => `${pointAt(value, route).x}%`)
  const y = useTransform(progress, (value) => `${pointAt(value, route).y}%`)
  const rotate = useTransform(progress, (value) => pointAt(value, route).angle)

  return (
    <motion.div className="journey-truck" style={{ left: x, top: y, rotate }} aria-hidden="true">
      <div className="journey-truck-shadow" />
      <div className="journey-truck-body">
        <span className="journey-truck-brand">KHAN BOOSTAN</span>
      </div>
      <div className="journey-truck-cab" />
      <span className="journey-wheel journey-wheel-a" />
      <span className="journey-wheel journey-wheel-b" />
      <span className="journey-headlight" />
    </motion.div>
  )
}

function RegionalMap({ progress, activeCountry, route }) {
  const visibleCountries = new Set(route)
  const path = route.map((key) => `${NODES[key].x},${NODES[key].y}`).join(' ')

  return (
    <div className="journey-map-shell" aria-label="Regional trade route visualization">
      <div className="journey-map-horizon" />
      <svg className="journey-map" viewBox="0 0 100 100" role="img" aria-label="Khan Boostan regional trade corridors">
        <defs>
          <radialGradient id="mapGlow">
            <stop offset="0" stopColor="rgba(220,178,73,.16)" />
            <stop offset="1" stopColor="rgba(220,178,73,0)" />
          </radialGradient>
          <linearGradient id="routeGold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#8e6a20" />
            <stop offset=".45" stopColor="#e4c66e" />
            <stop offset="1" stopColor="#8e6a20" />
          </linearGradient>
          <filter id="routeGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="1.2" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        <ellipse cx="50" cy="52" rx="46" ry="40" fill="url(#mapGlow)" />
        <path className="journey-land journey-land-west" d="M5 61 13 44 29 29 43 28 48 43 38 55 30 71 14 77Z" />
        <path className="journey-land journey-land-core" d="M38 44 48 37 61 39 73 52 64 72 48 75 35 63Z" />
        <path className="journey-land journey-land-east" d="M60 31 75 24 95 31 96 56 77 61 68 49Z" />
        <polyline points={path} className="journey-route-shadow" />
        <polyline points={path} className="journey-route" filter="url(#routeGlow)" />
        {Object.entries(NODES).filter(([key]) => visibleCountries.has(key)).map(([key, node]) => {
          const active = key === activeCountry
          return (
            <g key={key} className={active ? 'journey-node active' : 'journey-node'} transform={`translate(${node.x} ${node.y})`}>
              <circle r={active ? 3.2 : 2.35} className="journey-node-ring" />
              <circle r=".8" className="journey-node-core" />
            </g>
          )
        })}
      </svg>
      {Object.entries(NODES).filter(([key]) => visibleCountries.has(key)).map(([key, node]) => (
        <div key={key} className={`journey-country ${key === activeCountry ? 'active' : ''}`} style={{ left: `${node.x}%`, top: `${node.y}%` }}>
          <span>{node.label}</span>
        </div>
      ))}
      <TruckMarker progress={progress} route={route} />
      <div className="journey-map-badge"><Route className="h-4 w-4" /> Cross-border trade corridors</div>
    </div>
  )
}

function StoryPanel({ stage, stories, products, services, activeCountry, dir }) {
  const Icon = stageMeta[stage]?.icon || Globe2
  const service = services[stage % Math.max(services.length, 1)]
  const product = products[stage % Math.max(products.length, 1)]
  const country = NODES[activeCountry]?.label || 'Afghanistan'
  const story = stories[stage]

  if (!story) {
    return (
      <div className="journey-story-card" aria-live="polite">
        <span className="journey-stage-icon"><Icon className="h-5 w-5" /></span>
        <p className="mt-6 text-sm leading-relaxed text-white/45">Journey content is loaded from the Khan Boostan CMS.</p>
      </div>
    )
  }

  const destination = story.link || (stage < 2 ? '/markets' : stage < 4 ? '/services' : '/request-quote')
  return (
    <motion.div key={`${stage}-${activeCountry}-${story.slug}`} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="journey-story-card">
      <div className="flex items-center justify-between gap-5">
        <span className="journey-stage-icon"><Icon className="h-5 w-5" /></span>
        <span className="journey-stage-number">0{stage + 1}</span>
      </div>
      <p className="mt-8 font-display text-[12px] font-semibold uppercase tracking-[0.22em] text-gold-400">{story.kicker || stageMeta[stage]?.kicker}</p>
      <h2 className="display mt-3 text-4xl leading-[.98] text-white sm:text-5xl">{story.name}</h2>
      <p className="mt-5 max-w-lg text-[15px] leading-[1.8] text-white/58">{story.description}</p>
      <div className="mt-7 flex flex-wrap gap-2">
        <span className="journey-chip"><MapPin className="h-3.5 w-3.5" />{country}</span>
        {product?.name && <span className="journey-chip">{product.name}</span>}
        {service?.name && stage === 5 && <span className="journey-chip">{service.name}</span>}
      </div>
      <Link to={destination} className="link-arrow mt-8 text-[13px]">
        {story.linkLabel || 'Explore this capability'}
        <ArrowRight className={`h-4 w-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
      </Link>
    </motion.div>
  )
}

export default function RegionalTradeJourney({ products = [], services = [], corridors = [], stories = [] }) {
  const sectionRef = useRef(null)
  const [stage, setStage] = useState(0)
  const [activeCountry, setActiveCountry] = useState('afghanistan')
  const { dir } = useI18n()
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end end'] })
  const easedProgress = useTransform(scrollYProgress, [0, 1], [0.015, 0.985])
  const stageStops = useMemo(() => stageMeta.map((_, index) => index / stageMeta.length), [])
  const route = useMemo(() => buildRoute(corridors), [corridors])

  useMotionValueEvent(scrollYProgress, 'change', (value) => {
    const nextStage = Math.min(stageMeta.length - 1, Math.floor(value * stageMeta.length))
    setStage((current) => (current === nextStage ? current : nextStage))
    const destination = pointAt(Math.min(0.985, Math.max(0.015, value)), route).destination
    setActiveCountry((current) => (current === destination ? current : destination))
  })

  return (
    <section ref={sectionRef} className="journey-section">
      <div className="journey-sticky">
        <div className="journey-orb journey-orb-a" />
        <div className="journey-orb journey-orb-b" />
        <div className="container-x relative z-10 grid h-full items-center gap-8 py-24 lg:grid-cols-[1.4fr_.8fr] lg:gap-12">
          <RegionalMap progress={easedProgress} activeCountry={activeCountry} route={route} />
          <div className="relative z-20">
            <StoryPanel stage={stage} stories={stories} products={products} services={services} activeCountry={activeCountry} dir={dir} />
            <div className="mt-6 flex items-center gap-2" aria-label="Journey progress">
              {stageStops.map((stop, index) => (
                <div key={stop} className={`h-1 rounded-full transition-all duration-500 ${index === stage ? 'w-10 bg-gold-400' : 'w-4 bg-white/15'}`} />
              ))}
            </div>
          </div>
        </div>
        <div className="journey-progress-track"><motion.span style={{ scaleX: scrollYProgress }} /></div>
      </div>
    </section>
  )
}
