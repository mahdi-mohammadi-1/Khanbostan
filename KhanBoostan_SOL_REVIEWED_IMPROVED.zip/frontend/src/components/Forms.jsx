import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { CheckCircle2, Send } from 'lucide-react'
import { useI18n } from '../i18n.jsx'

function Field({ label, children, wide = false }) {
  return <label className={`block ${wide ? 'sm:col-span-2' : ''}`}><span className="mb-2 block font-display text-[12px] font-semibold uppercase tracking-[0.12em] text-neutral-500">{label}</span>{children}</label>
}

function Success({ text, note }) {
  return <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-8 text-center"><CheckCircle2 className="mx-auto h-10 w-10 text-emerald-600" /><p className="mt-4 text-[16px] font-semibold text-emerald-900">{text}</p><p className="mt-2 text-[13px] text-emerald-700">{note}</p></div>
}

export function QuoteForm() {
  const { t, products, services } = useI18n()
  const [params] = useSearchParams()
  const initialProduct = params.get('product') || ''
  const [sent, setSent] = useState(false)
  if (sent) return <Success text={t('form.success')} note={t('form.note')} />

  return (
    <form onSubmit={(event) => { event.preventDefault(); setSent(true) }} className="grid grid-cols-1 gap-5 sm:grid-cols-2">
      <Field label={t('form.name')}><input required name="name" className="input" placeholder={t('form.placeholderName')} /></Field>
      <Field label={t('form.company')}><input required name="company" className="input" placeholder={t('form.placeholderCompany')} /></Field>
      <Field label={t('form.email')}><input required type="email" name="email" className="input" placeholder={t('form.placeholderEmail')} /></Field>
      <Field label={t('form.phone')}><input name="phone" className="input" placeholder={t('form.placeholderPhone')} /></Field>
      <Field label={t('form.product')}><select name="product" className="input" defaultValue={initialProduct}><option value="">{t('form.selectProduct')}</option>{products.map((product) => <option key={product.slug} value={product.name}>{product.name}</option>)}</select></Field>
      <Field label={t('form.service')}><select name="service" className="input" defaultValue=""><option value="">{t('form.selectService')}</option>{services.map((service) => <option key={service.slug} value={service.slug}>{service.title}</option>)}</select></Field>
      <Field label={t('form.quantity')}><input name="quantity" className="input" placeholder="25 MT" /></Field>
      <Field label={t('form.destination')}><input required name="destination" className="input" placeholder={t('form.placeholderCountry')} /></Field>
      <Field label={t('form.origin')}><input name="origin" className="input" placeholder={t('form.placeholderCountry')} /></Field>
      <Field label={t('form.incoterm')}><select name="incoterm" className="input" defaultValue=""><option value="">—</option>{['EXW','FCA','FOB','CFR','CIF','CPT','CIP','DAP','DDP'].map((term) => <option key={term}>{term}</option>)}</select></Field>
      <Field label={t('form.message')} wide><textarea required name="message" rows="6" className="input resize-y" placeholder={t('form.placeholderMessage')} /></Field>
      <div className="sm:col-span-2"><button type="submit" className="btn-gold w-full py-4 text-[15px] sm:w-auto sm:px-10"><Send className="h-4 w-4" />{t('form.submit')}</button></div>
    </form>
  )
}

export function ContactForm() {
  const { t } = useI18n()
  const [sent, setSent] = useState(false)
  if (sent) return <Success text={t('form.success')} note={t('form.note')} />

  return (
    <form onSubmit={(event) => { event.preventDefault(); setSent(true) }} className="grid grid-cols-1 gap-5 sm:grid-cols-2">
      <Field label={t('form.name')}><input required name="name" className="input" placeholder={t('form.placeholderName')} /></Field>
      <Field label={t('form.company')}><input name="company" className="input" placeholder={t('form.placeholderCompany')} /></Field>
      <Field label={t('form.email')}><input required type="email" name="email" className="input" placeholder={t('form.placeholderEmail')} /></Field>
      <Field label={t('form.phone')}><input name="phone" className="input" placeholder={t('form.placeholderPhone')} /></Field>
      <Field label={t('form.subject')} wide><input required name="subject" className="input" placeholder={t('form.placeholderSubject')} /></Field>
      <Field label={t('form.message')} wide><textarea required name="message" rows="6" className="input resize-y" placeholder={t('form.placeholderMessage')} /></Field>
      <div className="sm:col-span-2"><button type="submit" className="btn-gold w-full py-4 text-[15px] sm:w-auto sm:px-10"><Send className="h-4 w-4" />{t('form.submit')}</button></div>
    </form>
  )
}
