import { motion, useInView, useMotionValue, useSpring } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'

const EASE = [0.22, 1, 0.36, 1]

/** Fade-up reveal on scroll */
export function Reveal({ children, delay = 0, y = 28, className = '', once = true }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: '-60px' }}
      transition={{ duration: 0.7, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  )
}

/** Staggered children container */
export function Stagger({ children, className = '', delay = 0, gap = 0.08 }) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: '-60px' }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: gap, delayChildren: delay } } }}
    >
      {children}
    </motion.div>
  )
}

export function StaggerItem({ children, className = '', y = 26 }) {
  return (
    <motion.div
      className={className}
      variants={{ hidden: { opacity: 0, y }, show: { opacity: 1, y: 0, transition: { duration: 0.65, ease: EASE } } }}
    >
      {children}
    </motion.div>
  )
}

/** Animated counter (used only for real, verifiable numbers) */
export function Counter({ to, suffix = '', prefix = '', className = '' }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-40px' })
  const mv = useMotionValue(0)
  const spring = useSpring(mv, { duration: 1.8, bounce: 0 })
  const [val, setVal] = useState(0)

  useEffect(() => {
    if (inView) mv.set(to)
  }, [inView, mv, to])

  useEffect(() => spring.on('change', (v) => setVal(Math.round(v))), [spring])

  return (
    <span ref={ref} className={className}>
      {prefix}
      {val.toLocaleString('en-US')}
      {suffix}
    </span>
  )
}

/** Infinite marquee band */
export function Marquee({ items, className = '', separator = '✦' }) {
  const row = [...items, ...items]
  return (
    <div className={`relative overflow-hidden ${className}`} aria-hidden="true">
      <div className="marquee-track">
        {row.map((it, i) => (
          <span key={i} className="display flex items-center gap-8 whitespace-nowrap pr-8 text-2xl text-white/85 sm:text-3xl">
            {it}
            <span className="text-gold-500">{separator}</span>
          </span>
        ))}
      </div>
    </div>
  )
}

/** Word-by-word hero line reveal */
export function WordsReveal({ text, className = '', delay = 0 }) {
  const words = text.split(' ')
  return (
    <span className={`inline-block ${className}`} aria-label={text}>
      {words.map((w, i) => (
        <span key={i} className="inline-block overflow-hidden pb-[0.08em] align-bottom">
          <motion.span
            className="inline-block"
            initial={{ y: '110%' }}
            animate={{ y: 0 }}
            transition={{ duration: 0.7, delay: delay + i * 0.06, ease: EASE }}
          >
            {w}
            {i < words.length - 1 ? '\u00A0' : ''}
          </motion.span>
        </span>
      ))}
    </span>
  )
}
