import { markets } from '../lib/data.jsx'

const FLAGS = {
  Uzbekistan: '🇺🇿',
  Tajikistan: '🇹🇯',
  Turkmenistan: '🇹🇲',
  Kazakhstan: '🇰🇿',
  Kyrgyzstan: '🇰🇬',
  Pakistan: '🇵🇰',
  India: '🇮🇳',
  UAE: '🇦🇪',
  Iran: '🇮🇷',
  'Saudi Arabia': '🇸🇦',
  Qatar: '🇶🇦',
  China: '🇨🇳',
  Russia: '🇷🇺',
  Türkiye: '🇹🇷',
  'Europe & other markets': '🌍',
}

const NODES = [
  { label: 'Central Asia', x: 300, y: 120, cx: 460, cy: 300 },
  { label: 'South Asia', x: 745, y: 100, cx: 560, cy: 300 },
  { label: 'Middle East', x: 140, y: 230, cx: 440, cy: 305 },
  { label: 'International', x: 840, y: 235, cx: 560, cy: 300 },
]

const HUB = { x: 500, y: 372 }

/** Animated hub & spoke network map — Afghanistan at the center */
export default function HubSpoke({ dark = true }) {
  const stroke = dark ? 'rgba(194,154,95,0.45)' : 'rgba(6,11,20,0.25)'
  const dot = dark ? '#C29A5F' : '#A87F43'
  const labelFill = dark ? 'rgba(255,255,255,0.75)' : 'rgba(6,11,20,0.65)'
  return (
    <div className="relative">
      <svg viewBox="0 0 1000 470" className="w-full" role="img" aria-label="Trade network map: Afghanistan as hub connecting Central Asia, South Asia, Middle East and international markets">
        {/* faint grid */}
        <defs>
          <pattern id="grid" width="34" height="34" patternUnits="userSpaceOnUse">
            <circle cx="1.5" cy="1.5" r="1" fill={dark ? 'rgba(255,255,255,0.07)' : 'rgba(6,11,20,0.06)'} />
          </pattern>
          <radialGradient id="hubGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={dark ? 'rgba(194,154,95,0.35)' : 'rgba(194,154,95,0.4)'} />
            <stop offset="100%" stopColor="rgba(194,154,95,0)" />
          </radialGradient>
        </defs>
        <rect width="1000" height="470" fill="url(#grid)" />

        {/* connection arcs */}
        {NODES.map((n, i) => (
          <path
            key={i}
            d={`M ${HUB.x} ${HUB.y} Q ${n.cx} ${n.cy} ${n.x} ${n.y + 6}`}
            fill="none"
            stroke={stroke}
            strokeWidth="1.4"
            strokeDasharray="5 7"
            className="animate-dashflow"
          />
        ))}

        {/* moving shipment dots */}
        {NODES.map((n, i) => (
          <circle key={`m${i}`} r="3.2" fill="#166BB2">
            <animateMotion dur={`${4 + i * 0.9}s`} repeatCount="indefinite" path={`M ${HUB.x} ${HUB.y} Q ${n.cx} ${n.cy} ${n.x} ${n.y + 6}`} />
          </circle>
        ))}

        {/* region nodes */}
        {NODES.map((n, i) => (
          <g key={`n${i}`}>
            <circle cx={n.x} cy={n.y} r="26" fill={dark ? 'rgba(10,18,32,0.9)' : 'rgba(255,255,255,0.9)'} stroke={stroke} strokeWidth="1.2" />
            <circle cx={n.x} cy={n.y} r="7" fill={dot} />
            <circle cx={n.x} cy={n.y} r="7" fill={dot} style={{ transformBox: 'fill-box', transformOrigin: 'center' }} className="animate-pulse-dot" />
            <text x={n.x} y={n.y + 52} textAnchor="middle" fill={labelFill} className="font-display" style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 19, fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              {n.label}
            </text>
          </g>
        ))}

        {/* hub */}
        <circle cx={HUB.x} cy={HUB.y} r="86" fill="url(#hubGlow)" />
        <circle cx={HUB.x} cy={HUB.y} r="34" fill={dark ? '#0A1220' : '#0A1220'} stroke={dot} strokeWidth="1.6" />
        <circle cx={HUB.x} cy={HUB.y} r="10" fill={dot} />
        <circle cx={HUB.x} cy={HUB.y} r="10" fill={dot} style={{ transformBox: 'fill-box', transformOrigin: 'center' }} className="animate-pulse-dot" />
        <text x={HUB.x} y={HUB.y - 52} textAnchor="middle" fill={dark ? '#fff' : '#0A1220'} style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 24, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase' }}>
          Afghanistan
        </text>
        <text x={HUB.x} y={HUB.y - 28} textAnchor="middle" fill={dot} style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 14, fontWeight: 600, letterSpacing: '0.22em', textTransform: 'uppercase' }}>
          Trading Hub
        </text>
        <text x={HUB.x} y={HUB.y + 62} textAnchor="middle" fill={dark ? 'rgba(255,255,255,0.45)' : 'rgba(6,11,20,0.5)'} style={{ fontFamily: 'Inter, sans-serif', fontSize: 12.5 }}>
          Mazar-e-Sharif · Balkh
        </text>
      </svg>

      {/* region legend */}
      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {markets.map((m) => (
          <div key={m.region} className={`rounded-xl border p-5 ${dark ? 'border-white/[0.07] bg-white/[0.03]' : 'card'}`}>
            <p className={`mb-3 font-display text-[13px] font-semibold uppercase tracking-[0.22em] ${dark ? 'text-gold-400' : 'text-gold-600'}`}>
              {m.region}
            </p>
            <ul className={`flex flex-wrap gap-2 ${dark ? '' : ''}`}>
              {m.countries.map((c) => (
                <li
                  key={c}
                  className={`rounded-full px-3 py-1 text-[12.5px] ${
                    dark ? 'border border-white/10 bg-white/[0.04] text-white/70' : 'border border-ink-950/10 bg-paper text-neutral-600'
                  }`}
                >
                  <span className="mr-1.5">{FLAGS[c] || '📍'}</span>
                  {c}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  )
}
