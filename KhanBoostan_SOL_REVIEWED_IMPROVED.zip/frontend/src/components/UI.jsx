import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { Reveal } from './Reveal.jsx'
import { useI18n } from '../i18n.jsx'

/** Section heading block with number + title + optional intro */
export function SectionHeading({ no, kicker, title, intro, align = 'left', dark = false, className = '' }) {
  const { tx } = useI18n()
  const alignCls = align === 'center' ? 'mx-auto max-w-3xl text-center' : 'max-w-3xl'
  return (
    <Reveal className={`mb-12 sm:mb-16 ${alignCls} ${className}`}>
      <p className="overline mb-4 flex items-center gap-4">
        {no && (
          <>
            <span>{no}</span>
            <span className={`h-px w-10 ${dark ? 'bg-white/25' : 'bg-ink-950/20'}`} />
          </>
        )}
        {no ? <span>{tx(kicker)}</span> : tx(kicker)}
      </p>
      <h2 className={`display text-4xl sm:text-5xl lg:text-[56px] ${dark ? 'text-white' : 'text-ink-900'}`}>{tx(title)}</h2>
      {intro && <p className={`mt-5 text-[16px] leading-relaxed ${dark ? 'text-white/60' : 'text-neutral-500'}`}>{tx(intro)}</p>}
    </Reveal>
  )
}

/** CTA button — renders Link or <a> or <button> */
export function CTA({ to, href, onClick, variant = 'gold', children, icon = true, className = '', type, ariaLabel }) {
  const { dir } = useI18n()
  const cls = `${variant === 'gold' ? 'btn-gold' : variant === 'outline' ? 'btn-outline' : variant === 'dark' ? 'btn-dark' : 'btn-ghost'} ${className}`
  const inner = (
    <>
      {children}
      {icon && <ArrowRight className={`h-[18px] w-[18px] transition-transform duration-300 group-hover:translate-x-1 ${dir === 'rtl' ? 'rotate-180' : ''}`} />}
    </>
  )
  if (to)
    return (
      <Link to={to} className={`group ${cls}`} aria-label={ariaLabel}>
        {inner}
      </Link>
    )
  if (href)
    return (
      <a href={href} className={`group ${cls}`} target={href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" aria-label={ariaLabel}>
        {inner}
      </a>
    )
  return (
    <button type={type || 'button'} onClick={onClick} className={`group ${cls}`} aria-label={ariaLabel}>
      {inner}
    </button>
  )
}

/** Small breadcrumb */
export function Breadcrumb({ items }) {
  const { t, dir } = useI18n()
  return (
    <nav aria-label="Breadcrumb" className="mb-6">
      <ol className="flex flex-wrap items-center gap-2 font-display text-[13px] font-medium uppercase tracking-[0.14em] text-white/50">
        <li>
          <Link to="/" className="transition-colors hover:text-gold-400">
            {t('common.home')}
          </Link>
        </li>
        {items.map((it, i) => (
          <li key={i} className="flex items-center gap-2">
            <span className="text-gold-500/70">{dir === 'rtl' ? '\\' : '/'}</span>
            {it.to ? (
              <Link to={it.to} className="transition-colors hover:text-gold-400">
                {it.label}
              </Link>
            ) : (
              <span className="text-white/85" aria-current="page">
                {it.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  )
}
