import { MessageCircle, Phone } from 'lucide-react'
import { CTA } from './UI.jsx'
import { Reveal } from './Reveal.jsx'
import { company } from '../lib/data.jsx'
import { useI18n } from '../i18n.jsx'

/** Final call-to-action band used across pages */
export default function CTASection({ title, text }) {
  const { t, tx } = useI18n()
  const displayTitle = title ? tx(title) : t('home.finalTitle')
  const displayText = text ? tx(text) : t('home.finalText')
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0">
        <img src="/img/cta-containers.jpg" alt="" loading="lazy" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/97 via-ink-950/88 to-ink-950/70" />
        <div className="grain-overlay absolute inset-0" />
      </div>
      <div className="container-x relative py-24 sm:py-32">
        <div className="max-w-2xl">
          <Reveal>
            <p className="overline mb-5 flex items-center gap-4">
              <span className="h-px w-10 bg-gold-500" /> {t('common.startConversation')}
            </p>
            <h2 className="display text-4xl text-white sm:text-5xl lg:text-6xl">{displayTitle}</h2>
            <p className="mt-5 text-[16px] leading-relaxed text-white/60">{displayText}</p>
          </Reveal>
          <Reveal delay={0.12} className="mt-9 flex flex-wrap gap-4">
            <CTA to="/request-quote" variant="gold">
              {t('common.requestQuote')}
            </CTA>
            <a
              href="https://wa.me/93000000000"
              target="_blank"
              rel="noreferrer"
              className="btn-outline group"
              aria-label="Chat with us on WhatsApp"
            >
              <MessageCircle className="h-[18px] w-[18px] text-gold-400" /> {t('common.whatsapp')}
            </a>
            <a href={`tel:${company.phone.replace(/[^+\d]/g, '')}`} className="btn-ghost group !text-white/70 hover:!text-gold-300">
              <Phone className="h-[18px] w-[18px]" /> {company.phone}
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
