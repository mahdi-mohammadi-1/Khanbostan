import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, ChevronDown, Globe2, Menu, X } from 'lucide-react'
import { useI18n } from '../i18n.jsx'

const navItems = [
  { key: 'home', to: '/' },
  { key: 'about', to: '/about' },
  { key: 'products', to: '/products' },
  { key: 'import', to: '/services/import', trade: true },
  { key: 'export', to: '/services/export', trade: true },
  { key: 'services', to: '/services' },
  { key: 'markets', to: '/markets' },
  { key: 'contact', to: '/contact' },
]

function Logo({ onClick }) {
  return (
    <Link to="/" onClick={onClick} className="group flex items-center gap-3" aria-label="Khan Boostan Limited">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white ring-1 ring-white/30 transition group-hover:ring-gold-400">
        <img src="/img/logo.png" alt="Khan Boostan Limited" className="h-full w-full object-cover" width={44} height={44} />
      </span>
      <span className="leading-none">
        <span className="display block text-[20px] tracking-[0.04em] text-white">Khan <span className="text-gold-400">Boostan</span></span>
        <span className="block font-display text-[10px] font-medium uppercase tracking-[0.38em] text-white/50">Limited</span>
      </span>
    </Link>
  )
}

function LanguageMenu({ compact = false }) {
  const { language, setLanguage, languages, t } = useI18n()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  const active = languages.find((item) => item.code === language)

  useEffect(() => {
    const close = (event) => {
      if (!ref.current?.contains(event.target)) setOpen(false)
    }
    window.addEventListener('pointerdown', close)
    return () => window.removeEventListener('pointerdown', close)
  }, [])

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className={`flex items-center justify-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] text-white transition hover:border-gold-400/60 hover:bg-white/[0.08] ${compact ? 'h-11 min-w-11 px-3' : 'h-11 px-3.5'}`}
        aria-label={t('common.selectLanguage')}
        aria-expanded={open}
      >
        <Globe2 className="h-[17px] w-[17px] text-gold-400" />
        {!compact && <span className="font-display text-[13px] font-semibold tracking-[0.08em]">{active?.short}</span>}
        <ChevronDown className={`h-3.5 w-3.5 text-white/45 transition ${open ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            className="absolute end-0 top-[calc(100%+10px)] z-[80] w-48 overflow-hidden rounded-xl border border-white/10 bg-ink-900 p-2 shadow-panel"
          >
            {languages.map((item) => (
              <button
                type="button"
                key={item.code}
                onClick={() => { setLanguage(item.code); setOpen(false) }}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-start text-[14px] transition ${language === item.code ? 'bg-gold-500 text-ink-950' : 'text-white/70 hover:bg-white/[0.06] hover:text-white'}`}
              >
                <span>{item.native}</span>
                <span className="flex items-center gap-2 font-display text-[11px] font-semibold tracking-[0.1em] opacity-70">
                  {item.short}{language === item.code && <Check className="h-3.5 w-3.5" />}
                </span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function Header() {
  const { t, dir } = useI18n()
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => setMobileOpen(false), [location.pathname, location.search])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [mobileOpen])

  return (
    <>
      <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || mobileOpen ? 'border-b border-white/[0.08] bg-ink-950/95 shadow-panel backdrop-blur-xl' : 'border-b border-transparent bg-gradient-to-b from-ink-950/90 to-ink-950/15'}`}>
        <div className="container-x flex h-[76px] items-center justify-between gap-5">
          <Logo onClick={() => setMobileOpen(false)} />
          <nav className="hidden items-center gap-0.5 2xl:flex" aria-label="Main navigation">
            {navItems.map((item) => (
              <NavLink
                key={item.key}
                to={item.to}
                className={({ isActive }) => `relative rounded-md px-3 py-2.5 font-display text-[13px] font-semibold uppercase tracking-[0.075em] transition ${isActive ? 'text-gold-400' : item.trade ? 'text-white hover:bg-gold-500/10 hover:text-gold-300' : 'text-white/70 hover:text-white'}`}
              >
                {t(`nav.${item.key}`)}
                {item.trade && <span className="absolute inset-x-3 -bottom-0.5 h-px bg-gold-500/45" />}
              </NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2.5">
            <LanguageMenu compact />
            <Link to="/request-quote" className="btn-gold hidden !px-5 !py-3 text-[13px] sm:inline-flex">{t('common.requestQuote')}</Link>
            <button type="button" onClick={() => setMobileOpen(true)} className="flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 text-white transition hover:border-gold-400 hover:text-gold-300 2xl:hidden" aria-label={t('common.openMenu')}>
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] bg-ink-950 2xl:hidden" role="dialog" aria-modal="true" dir={dir}>
            <div className="container-x flex h-[76px] items-center justify-between border-b border-white/[0.08]">
              <Logo onClick={() => setMobileOpen(false)} />
              <button type="button" onClick={() => setMobileOpen(false)} className="flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 text-white" aria-label={t('common.closeMenu')}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="container-x h-[calc(100vh-76px)] overflow-y-auto py-7">
              <motion.nav initial="hidden" animate="show" variants={{ hidden: {}, show: { transition: { staggerChildren: 0.045 } } }} className="grid grid-cols-1 gap-1 sm:grid-cols-2">
                {navItems.map((item) => (
                  <motion.div key={item.key} variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}>
                    <NavLink to={item.to} className={({ isActive }) => `flex items-center justify-between rounded-xl border px-5 py-4 transition ${isActive ? 'border-gold-500/50 bg-gold-500/10 text-gold-300' : 'border-white/[0.07] bg-white/[0.025] text-white hover:bg-white/[0.06]'}`}>
                      <span className="display text-2xl">{t(`nav.${item.key}`)}</span>
                      {item.trade && <span className="rounded-full bg-gold-500 px-2 py-1 font-display text-[10px] font-semibold uppercase tracking-wider text-ink-950">Trade</span>}
                    </NavLink>
                  </motion.div>
                ))}
              </motion.nav>
              <div className="mt-7 flex flex-col gap-4 border-t border-white/[0.08] pt-7 sm:flex-row sm:items-center">
                <LanguageMenu />
                <Link to="/request-quote" className="btn-gold flex-1 py-4 text-[15px]">{t('common.requestQuote')}</Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
