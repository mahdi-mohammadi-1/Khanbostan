import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { fetchSiteBootstrap } from '../../features/content/contentSlice.js'

export default function SiteBootstrap() {
  const dispatch = useDispatch()
  useEffect(() => { dispatch(fetchSiteBootstrap()) }, [dispatch])
  return null
}
