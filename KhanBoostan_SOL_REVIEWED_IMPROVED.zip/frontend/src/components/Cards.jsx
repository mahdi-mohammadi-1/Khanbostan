import { Link } from 'react-router-dom'
import { ArrowRight, ArrowUpRight, Calendar, Clock, Download, FileText, Layers, MapPin } from 'lucide-react'
import { useI18n } from '../i18n.jsx'

/* ---------------- Product card ---------------- */
export function ProductCard({ p, index = 0 }) {
  const { t, dir } = useI18n()
  return (
    <article className="group card flex flex-col overflow-hidden transition-all duration-500 hover:-translate-y-1.5 hover:shadow-panel">
      <Link to={`/products/${p.slug}`} className="img-zoom relative block aspect-[4/3]" aria-label={p.name}>
        <img src={p.image} alt={p.name} loading={index > 3 ? 'lazy' : 'eager'} width={800} height={600} />
        <span className="absolute left-4 top-4 rounded-md bg-ink-950/85 px-3 py-1.5 font-display text-[11px] font-semibold uppercase tracking-[0.18em] text-gold-300 backdrop-blur">
          HS {p.hsCode}
        </span>
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <h3 className="display text-[22px] text-ink-900">
          <Link to={`/products/${p.slug}`} className="transition-colors hover:text-gold-600">
            {p.name}
          </Link>
        </h3>
        <p className="mt-2.5 line-clamp-2 text-[14px] leading-relaxed text-neutral-500">{p.blurb}</p>
        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1.5 text-[12.5px] text-neutral-400">
          <span className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5 text-gold-500" /> {p.origin}
          </span>
          <span className="flex items-center gap-1.5">
            <Layers className="h-3.5 w-3.5 text-gold-500" /> {p.moq.split('(')[0]}
          </span>
        </div>
        <div className="mt-5 flex items-center justify-between border-t border-ink-950/[0.07] pt-5">
          <Link to={`/products/${p.slug}`} className="link-arrow text-[13px]">
            {t('common.viewDetails')} <ArrowRight className={`h-3.5 w-3.5 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
          </Link>
          <Link
            to={`/request-quote?product=${encodeURIComponent(p.name)}`}
            className="rounded-md bg-ink-950 px-4 py-2 font-display text-[12.5px] font-semibold uppercase tracking-[0.12em] text-white transition-colors hover:bg-gold-500 hover:text-ink-950"
          >
            {t('common.quote')}
          </Link>
        </div>
      </div>
    </article>
  )
}

/* ---------------- Service card ---------------- */
export function ServiceCard({ s, Icon, dark = false, index = 0 }) {
  const { t, dir } = useI18n()
  return (
    <article
      className={`group relative overflow-hidden rounded-xl border p-7 transition-all duration-500 hover:-translate-y-1.5 ${
        dark
          ? 'border-white/[0.07] bg-white/[0.03] hover:border-gold-500/40'
          : 'border-ink-950/[0.07] bg-white shadow-card hover:border-gold-500/50 hover:shadow-panel'
      }`}
    >
      <div
        className={`pointer-events-none absolute -right-10 -top-10 h-36 w-36 rounded-full blur-3xl transition-opacity duration-500 ${
          dark ? 'bg-gold-500/[0.07] opacity-0 group-hover:opacity-100' : 'bg-gold-100 opacity-0 group-hover:opacity-100'
        }`}
      />
      <div className="relative">
        <span className="mb-5 flex h-12 w-12 items-center justify-center rounded-lg border border-gold-500/25 bg-gold-500/10 text-gold-500 transition-all duration-500 group-hover:bg-gold-500 group-hover:text-ink-950">
          <Icon className="h-6 w-6" />
        </span>
        <h3 className={`display text-2xl ${dark ? 'text-white' : 'text-ink-900'}`}>{s.title}</h3>
        <p className={`mt-3 text-[14px] leading-relaxed ${dark ? 'text-white/55' : 'text-neutral-500'}`}>{s.blurb}</p>
        {s.route && (
          <Link to={s.route} className="link-arrow mt-6 text-[13px]">
            {t('common.learnMore')} <ArrowRight className={`h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
          </Link>
        )}
      </div>
    </article>
  )
}

/* ---------------- Industry card ---------------- */
export function IndustryCard({ ind, index = 0 }) {
  return (
    <Link
      to="/industries"
      className="group card relative flex items-center gap-4 overflow-hidden p-5 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/50 hover:shadow-panel"
    >
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-ink-950 text-gold-400 transition-colors duration-500 group-hover:bg-gold-500 group-hover:text-ink-950">
        <ind.icon className="h-5 w-5" />
      </span>
      <span>
        <span className="display block text-[19px] text-ink-900">{ind.title}</span>
        <span className="mt-0.5 block text-[12.5px] leading-snug text-neutral-400">{ind.blurb}</span>
      </span>
      <ArrowUpRight className="ml-auto h-4 w-4 shrink-0 text-neutral-300 transition-all duration-300 group-hover:text-gold-500" />
    </Link>
  )
}

/* ---------------- Article card ---------------- */
export function ArticleCard({ a, index = 0 }) {
  return (
    <article className="group card flex flex-col overflow-hidden transition-all duration-500 hover:-translate-y-1.5 hover:shadow-panel">
      <Link to={`/news/${a.slug}`} className="img-zoom relative block aspect-[16/10]" aria-label={a.title}>
        <img src={a.image} alt="" loading="lazy" width={800} height={500} />
        <span className="absolute left-4 top-4 rounded-md bg-gold-500 px-3 py-1.5 font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-950">
          {a.category}
        </span>
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <div className="mb-3 flex items-center gap-4 text-[12.5px] text-neutral-400">
          <span className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5 text-gold-500" />
            {new Date(a.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-gold-500" />
            {a.read}
          </span>
        </div>
        <h3 className="display text-[21px] leading-tight text-ink-900">
          <Link to={`/news/${a.slug}`} className="transition-colors group-hover:text-gold-600">
            {a.title}
          </Link>
        </h3>
        <p className="mt-2.5 line-clamp-2 text-[14px] leading-relaxed text-neutral-500">{a.excerpt}</p>
        <Link to={`/news/${a.slug}`} className="link-arrow mt-auto pt-5 text-[13px]">
          Read More <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
        </Link>
      </div>
    </article>
  )
}

/* ---------------- Certificate card (pending state) ---------------- */
export function CertificateCard({ c, index = 0 }) {
  return (
    <article className="card group flex flex-col p-7 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/50 hover:shadow-panel">
      <div className="mb-5 flex items-start justify-between">
        <span className="flex h-12 w-12 items-center justify-center rounded-lg border border-ink-950/10 bg-paper text-ink-700 transition-colors duration-500 group-hover:border-gold-500/40 group-hover:text-gold-600">
          <FileText className="h-6 w-6" />
        </span>
        <span className="rounded-md bg-amber-50 px-3 py-1.5 font-display text-[10.5px] font-semibold uppercase tracking-[0.16em] text-amber-700 ring-1 ring-amber-200">
          Awaiting document
        </span>
      </div>
      <h3 className="display text-[21px] text-ink-900">{c.title}</h3>
      <dl className="mt-4 space-y-1.5 text-[13px] text-neutral-400">
        <div className="flex justify-between gap-4">
          <dt>Issuing organization</dt>
          <dd className="text-right text-neutral-600">{c.issuer}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt>Date</dt>
          <dd className="text-neutral-600">{c.date}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt>Document number</dt>
          <dd className="text-neutral-600">{c.number}</dd>
        </div>
      </dl>
      <div className="mt-5 flex gap-3 border-t border-ink-950/[0.07] pt-5">
        <button
          disabled
          className="flex flex-1 cursor-not-allowed items-center justify-center gap-2 rounded-md bg-ink-950/[0.05] px-4 py-2.5 font-display text-[12.5px] font-semibold uppercase tracking-[0.12em] text-neutral-400"
        >
          <Download className="h-4 w-4" /> PDF — pending
        </button>
      </div>
    </article>
  )
}
