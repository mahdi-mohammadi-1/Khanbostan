import { createContext, useContext, useMemo, useState } from 'react'

const AppContext = createContext(null)
export function AppProvider({ children }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const value = useMemo(() => ({ mobileMenuOpen, setMobileMenuOpen }), [mobileMenuOpen])
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
export function useAppContext() {
  const value = useContext(AppContext)
  if (!value) throw new Error('useAppContext must be used inside AppProvider')
  return value
}
