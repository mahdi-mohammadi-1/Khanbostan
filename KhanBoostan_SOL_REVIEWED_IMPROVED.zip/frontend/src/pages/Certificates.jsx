import { ShieldAlert } from 'lucide-react'
import { certificates, certificatesNote } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { CertificateCard } from '../components/Cards.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function Certificates() {
  usePageMeta({
    title: 'Certificates & Compliance',
    description: 'Official documents of Khan Boostan Limited — trade license, company registration, chamber membership and quality certificates. Published only after verification.',
    path: '/certificates',
  })

  return (
    <>
      <PageHeader
        kicker="Compliance"
        title="Certificates & documents"
        intro="Official company documents — licenses, registrations, memberships and quality certificates."
        image="/img/warehouse-1.jpg"
        crumbs={[{ label: 'Certificates' }]}
      />

      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <Reveal className="mb-12 flex items-start gap-4 rounded-2xl border border-amber-300/50 bg-amber-50 p-6">
            <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
            <p className="text-[14.5px] leading-relaxed text-neutral-600">
              <strong className="font-semibold text-ink-900">Verification policy:</strong> {certificatesNote} No document on this website is ever
              recreated, estimated or simulated.
            </p>
          </Reveal>

          <Stagger className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3" gap={0.07}>
            {certificates.map((c) => (
              <StaggerItem key={c.title}>
                <CertificateCard c={c} />
              </StaggerItem>
            ))}
          </Stagger>

          <Reveal delay={0.15} className="mt-16">
            <SectionHeading kicker="Document Standards" title="What we publish — and how" className="mb-8" />
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { t: 'Title & issuer', d: 'Document name and the official issuing organization.' },
                { t: 'Date & number', d: 'Issue date and document number where applicable.' },
                { t: 'Preview', d: 'An official preview, never a re-creation or mock-up.' },
                { t: 'PDF download', d: 'The original document, downloadable where permitted.' },
              ].map((x, i) => (
                <Reveal key={x.t} delay={i * 0.06}>
                  <div className="card h-full p-6">
                    <span className="display block text-3xl text-gold-500/40">{String(i + 1).padStart(2, '0')}</span>
                    <h4 className="display mt-2 text-lg text-ink-900">{x.t}</h4>
                    <p className="mt-1.5 text-[13px] leading-relaxed text-neutral-500">{x.d}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <CTASection title="Need verified documentation for a transaction?" text="Our team provides the required trade and compliance documents for every deal — before you commit." />
    </>
  )
}
