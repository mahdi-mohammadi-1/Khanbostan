import ServiceDetail from './service-detail.jsx'

export default function ServiceImport() {
  return <ServiceDetail slug="import" kicker="Services · Import" />
}
