import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronDown, Search, X } from 'lucide-react'
import { faqs, faqCategories } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { Reveal } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

const EASE = [0.22, 1, 0.36, 1]

export default function Faq() {
  usePageMeta({
    title: 'FAQ',
    description: 'Frequently asked questions about Khan Boostan Limited — products, sourcing, import, export, logistics, payment, documentation and quotations.',
    path: '/faq',
  })

  const [cat, setCat] = useState('General')
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(null)

  const filtered = useMemo(() => {
    return faqs.filter((f) => {
      const okCat = cat === 'All' || f.cat === cat
      const okQ = !q || (f.q + ' ' + f.a).toLowerCase().includes(q.toLowerCase())
      return okCat && okQ
    })
  }, [cat, q])

  return (
    <>
      <PageHeader
        kicker="FAQ"
        title="Questions & answers"
        intro="The questions we hear most — answered directly. If yours is not here, ask us."
        image="/img/warehouse-2.jpg"
        crumbs={[{ label: 'FAQ' }]}
      />

      <section className="bg-paper py-16 sm:py-24">
        <div className="container-x grid grid-cols-1 gap-12 lg:grid-cols-[300px_1fr]">
          {/* controls */}
          <div className="space-y-8 lg:sticky lg:top-28 lg:self-start">
            <Reveal>
              <p className="overline mb-4">Categories</p>
              <div className="flex flex-wrap gap-2 lg:flex-col lg:items-start">
                {['All', ...faqCategories].map((c) => (
                  <button
                    key={c}
                    onClick={() => setCat(c)}
                    className={`rounded-lg px-4 py-2.5 text-left font-display text-[13.5px] font-semibold uppercase tracking-[0.1em] transition-all ${
                      cat === c ? 'bg-ink-950 text-gold-400 shadow-panel' : 'bg-white text-neutral-500 shadow-sm hover:text-ink-900'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </Reveal>
            <Reveal delay={0.08}>
              <div className="relative">
                <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
                <input value={q} onChange={(e) => setQ(e.target.value)} className="input !pl-11" placeholder="Search questions…" aria-label="Search questions" />
                {q && (
                  <button onClick={() => setQ('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-ink-900" aria-label="Clear search">
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            </Reveal>
          </div>

          {/* accordion */}
          <div className="space-y-4">
            {filtered.length === 0 && (
              <div className="rounded-2xl border border-dashed border-ink-950/15 bg-white p-12 text-center">
                <p className="display text-2xl text-ink-900">No matching questions</p>
                <p className="mt-2 text-[14px] text-neutral-500">Try another search — or ask us directly.</p>
              </div>
            )}
            {filtered.map((f, i) => {
              const isOpen = open === f.q
              return (
                <Reveal key={f.q} delay={Math.min(i * 0.04, 0.3)}>
                  <div className={`overflow-hidden rounded-xl border bg-white shadow-card transition-colors ${isOpen ? 'border-gold-500/60' : 'border-ink-950/10'}`}>
                    <button
                      onClick={() => setOpen(isOpen ? null : f.q)}
                      className="flex w-full items-center justify-between gap-5 px-6 py-5 text-left"
                      aria-expanded={isOpen}
                    >
                      <span className="flex items-center gap-4">
                        <span className="hidden font-display text-[12px] font-semibold text-gold-600 sm:block">{String(i + 1).padStart(2, '0')}</span>
                        <span className={`text-[15.5px] font-semibold ${isOpen ? 'text-gold-700' : 'text-ink-900'}`}>{f.q}</span>
                      </span>
                      <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all duration-300 ${isOpen ? 'rotate-180 border-gold-500 bg-gold-500 text-ink-950' : 'border-ink-950/15 text-neutral-400'}`}>
                        <ChevronDown className="h-4 w-4" />
                      </span>
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.32, ease: EASE }}
                          className="overflow-hidden"
                        >
                          <div className="border-t border-ink-950/[0.06] px-6 py-5 pl-6 sm:pl-[76px]">
                            <p className="text-[14.5px] leading-[1.8] text-neutral-600">{f.a}</p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </Reveal>
              )
            })}
          </div>
        </div>
      </section>

      <CTASection title="Question not answered?" text="Contact our trade desk — real people, real answers, usually within one working day." />
    </>
  )
}
