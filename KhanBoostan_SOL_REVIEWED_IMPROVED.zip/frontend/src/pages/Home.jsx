import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowDown, ArrowRight, BadgeCheck, Boxes, FileCheck2, Globe2, ShieldCheck, Sparkles, Truck } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import { CTA, SectionHeading } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import { ProductCard } from '../components/Cards.jsx'
import CTASection from '../components/CTASection.jsx'
import RegionalTradeJourney from '../components/journey/RegionalTradeJourney.jsx'

const reasonIcons = [BadgeCheck, FileCheck2, Truck, Globe2, ShieldCheck, Boxes]
const ease = [0.22, 1, 0.36, 1]

export default function Home() {
  const { t, products, services, tradeCorridors, homeStories, company, dir } = useI18n()
  const reasons = t('home.reasons')

  usePageMeta({
    title: `${company.name || 'Khan Boostan'} — ${t('home.eyebrow')}`,
    description: t('home.intro'),
    path: '/',
  })

  return (
    <>
      <section className="cinematic-hero">
        <div className="cinematic-grid" />
        <div className="cinematic-glow cinematic-glow-a" />
        <div className="cinematic-glow cinematic-glow-b" />
        <div className="cinematic-lines" />
        <div className="container-x relative z-10 flex min-h-[100svh] items-center pb-24 pt-32 sm:pt-36">
          <div className="max-w-6xl">
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease }} className="mb-7 flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-full border border-gold-400/25 bg-gold-400/[0.08] px-4 py-2 font-display text-[11px] font-semibold uppercase tracking-[0.2em] text-gold-300"><Sparkles className="h-3.5 w-3.5" /> Regional trade intelligence</span>
              <span className="text-[12px] text-white/38">Balkh · Afghanistan · Regional Markets</span>
            </motion.div>
            <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.85, delay: 0.1, ease }} className="display max-w-[1120px] text-[clamp(3.4rem,9vw,8.6rem)] leading-[.82] tracking-[-.035em] text-white">
              Trade moves.<br /><span className="text-gradient-gold">We move with it.</span>
            </motion.h1>
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.75, delay: 0.28, ease }} className="mt-9 grid max-w-4xl gap-7 lg:grid-cols-[1.2fr_.8fr] lg:items-end">
              <p className="max-w-2xl text-[16px] leading-[1.85] text-white/58 sm:text-[18px]">{t('home.intro')}</p>
              <div className="flex flex-wrap gap-3 lg:justify-end">
                <CTA to="/request-quote" variant="gold">{t('common.requestQuote')}</CTA>
                <CTA to="/products" variant="outline">{t('common.exploreProducts')}</CTA>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="absolute inset-x-0 bottom-0 z-20">
          <div className="container-x flex items-end justify-between gap-6 border-t border-white/[0.08] py-5">
            <div className="grid flex-1 grid-cols-2 gap-4 sm:grid-cols-4">
              {[[products.length, t('home.productsFact')], [services.length, t('home.serviceFact')], ['B2B', t('home.focusFact')], ['24/7', 'Trade visibility']].map(([value, label]) => (
                <div key={label} className="min-w-0"><span className="display block text-2xl text-white">{value}</span><span className="mt-1 block truncate text-[10px] uppercase tracking-[.16em] text-white/35">{label}</span></div>
              ))}
            </div>
            <a href="#trade-journey" className="hidden items-center gap-2 text-[11px] font-semibold uppercase tracking-[.2em] text-white/48 transition hover:text-gold-300 sm:flex">Scroll the route <ArrowDown className="h-4 w-4 animate-bounce" /></a>
          </div>
        </div>
      </section>

      <div id="trade-journey">
        <RegionalTradeJourney products={products} services={services} corridors={tradeCorridors} stories={homeStories} />
      </div>

      <section className="relative overflow-hidden bg-[#f3efe5] py-24 sm:py-32">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-ink-950/15 to-transparent" />
        <div className="container-x">
          <div className="grid gap-10 lg:grid-cols-[.8fr_1.2fr] lg:items-end">
            <SectionHeading kicker="Trade portfolio" title="Products moving through real corridors" intro="Our portfolio is managed from the CMS. Every inquiry can also start with a product that is not yet in the catalog." className="mb-0" />
            <Reveal className="lg:justify-self-end"><Link to="/products" className="link-arrow text-[13px]">{t('common.viewAll')}<ArrowRight className={`h-4 w-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} /></Link></Reveal>
          </div>
          <Stagger className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3" gap={0.04}>
            {products.slice(0, 6).map((product, index) => <StaggerItem key={product.slug}><ProductCard p={product} index={index} /></StaggerItem>)}
          </Stagger>
          {!products.length && <div className="mt-14 rounded-2xl border border-ink-950/10 bg-white/55 p-8 text-center text-sm text-neutral-500">Product content will appear here after the Laravel API is connected and seeded.</div>}
        </div>
      </section>

      <section className="relative overflow-hidden bg-ink-950 py-24 sm:py-32">
        <div className="cinematic-grid opacity-30" />
        <div className="container-x relative z-10">
          <div className="grid gap-12 lg:grid-cols-[.78fr_1.22fr] lg:items-start">
            <div className="lg:sticky lg:top-28">
              <p className="overline">Custom trade desk</p>
              <h2 className="display mt-4 text-5xl leading-[.9] text-white sm:text-6xl">Need something outside the catalog?</h2>
              <p className="mt-6 max-w-xl text-[15px] leading-[1.8] text-white/52">For dedicated customers, Khan Boostan can structure a custom import or export around specification, origin, quantity, commercial terms and destination.</p>
              <div className="mt-8"><CTA to="/request-quote" variant="gold">Start custom sourcing</CTA></div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                ['01', 'Tell us what you need', 'Product, specification, target quantity and destination.'],
                ['02', 'We search the corridor', 'Supplier discovery and commercial comparison across relevant markets.'],
                ['03', 'We structure the deal', 'Terms, documentation, transport and border requirements are aligned.'],
                ['04', 'Cargo moves with visibility', 'One accountable trade partner follows the shipment to delivery.'],
              ].map(([number, title, text]) => (
                <Reveal key={number} className="trade-step-card">
                  <span className="display text-5xl text-gold-400/35">{number}</span>
                  <h3 className="display mt-10 text-2xl text-white">{title}</h3>
                  <p className="mt-3 text-[13.5px] leading-[1.75] text-white/48">{text}</p>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-24 sm:py-32">
        <div className="container-x grid gap-14 lg:grid-cols-[.82fr_1.18fr]">
          <SectionHeading kicker={t('home.whyKicker')} title={t('home.whyTitle')} intro="The visual experience is new. The operating principle stays serious: documented trade, controlled execution and clear accountability." className="mb-0" />
          <Stagger className="grid grid-cols-1 gap-4 sm:grid-cols-2" gap={0.04}>
            {reasons.slice(0, 6).map((reason, index) => {
              const Icon = reasonIcons[index] || ShieldCheck
              return <StaggerItem key={reason.title}><div className="group h-full rounded-2xl border border-ink-950/[0.07] bg-[#faf9f5] p-6 transition duration-500 hover:-translate-y-1 hover:border-gold-500/30 hover:shadow-panel"><span className="mb-5 flex h-11 w-11 items-center justify-center rounded-xl border border-gold-500/20 bg-gold-500/10 text-gold-700 transition group-hover:bg-ink-950 group-hover:text-gold-300"><Icon className="h-5 w-5" /></span><h3 className="display text-xl text-ink-900">{reason.title}</h3><p className="mt-2 text-[13.5px] leading-relaxed text-neutral-500">{reason.text}</p></div></StaggerItem>
            })}
          </Stagger>
        </div>
      </section>

      <CTASection title={t('home.finalTitle')} text={t('home.finalText')} />
    </>
  )
}
