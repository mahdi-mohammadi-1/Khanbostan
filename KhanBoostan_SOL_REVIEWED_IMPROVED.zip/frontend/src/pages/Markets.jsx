import { ArrowUpRight, MapPin, Route, TrainFront, Truck } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

const icons = [TrainFront, Route, Truck, MapPin]

export default function Markets() {
  const { t } = useI18n()
  const countries = t('marketsPage.countries')
  usePageMeta({ title: t('marketsPage.title'), description: t('marketsPage.intro'), path: '/markets' })

  return (
    <>
      <PageHeader kicker={t('marketsPage.kicker')} title={t('marketsPage.title')} intro={t('marketsPage.intro')} image="/img/trucks-2.jpg" crumbs={[{ label: t('nav.markets') }]} />
      <section className="relative overflow-hidden bg-ink-950 py-20 sm:py-28">
        <div className="grain-overlay absolute inset-0" />
        <div className="container-x relative">
          <SectionHeading kicker={t('home.marketsKicker')} title={t('marketsPage.routesTitle')} dark align="center" />
          <Stagger className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4" gap={0.06}>
            {countries.map((country, index) => {
              const Icon = icons[index]
              return <StaggerItem key={country.name}><article className="card-dark group h-full p-7"><span className="mb-5 flex h-12 w-12 items-center justify-center rounded-lg border border-gold-500/25 bg-gold-500/10 text-gold-400"><Icon className="h-6 w-6" /></span><div className="flex items-center justify-between gap-3"><h2 className="display text-2xl text-white">{country.name}</h2><ArrowUpRight className="h-4 w-4 text-gold-500/60" /></div><p className="mt-3 text-[13.5px] leading-relaxed text-white/50">{country.text}</p></article></StaggerItem>
            })}
          </Stagger>
          <Reveal className="mx-auto mt-10 max-w-2xl rounded-xl border border-white/[0.08] bg-white/[0.03] p-5 text-center"><p className="text-[13.5px] leading-relaxed text-white/50">{t('marketsPage.note')}</p></Reveal>
        </div>
      </section>
      <CTASection />
    </>
  )
}
