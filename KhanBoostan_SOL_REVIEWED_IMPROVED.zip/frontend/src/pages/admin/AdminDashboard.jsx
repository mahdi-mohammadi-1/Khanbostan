import { useCallback, useEffect, useMemo, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import http from '../../services/http.js'
import { logoutAdmin } from '../../features/auth/authSlice.js'

const TYPES = ['products', 'categories', 'services', 'markets', 'trade-corridors', 'home-stories', 'projects', 'partners', 'certificates', 'articles', 'faqs']
const emptyForm = { id: null, slug: '', title: '', data: '{}', translations: '{}', is_active: true, sort_order: 0 }

function json(value) {
  return JSON.stringify(value || {}, null, 2)
}

export default function AdminDashboard() {
  const dispatch = useDispatch()
  const token = useSelector((state) => state.auth.token)
  const [type, setType] = useState('products')
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState(emptyForm)
  const editing = useMemo(() => Boolean(form.id), [form.id])

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const { data } = await http.get(`/admin/${type}`)
      setItems(data.data || [])
    } catch (requestError) {
      setError(requestError.response?.data?.message || requestError.message)
    } finally {
      setLoading(false)
    }
  }, [type])

  useEffect(() => {
    if (token) load()
  }, [load, token])

  if (!token) return <Navigate to="/admin/login" replace />

  const reset = () => setForm({ ...emptyForm, sort_order: items.length })
  const edit = (item) => setForm({
    id: item.id,
    slug: item.slug,
    title: item.title,
    data: json(item.data),
    translations: json(item.translations),
    is_active: item.is_active ?? true,
    sort_order: item.sort_order ?? 0,
  })

  const submit = async (event) => {
    event.preventDefault()
    setError('')
    try {
      const payload = {
        slug: form.slug,
        title: form.title,
        data: JSON.parse(form.data || '{}'),
        translations: JSON.parse(form.translations || '{}'),
        is_active: form.is_active,
        sort_order: Number(form.sort_order) || 0,
      }
      if (editing) await http.put(`/admin/${type}/${form.id}`, payload)
      else await http.post(`/admin/${type}`, payload)
      reset()
      await load()
    } catch (requestError) {
      setError(requestError.response?.data?.message || requestError.message || 'Invalid JSON or request failed.')
    }
  }

  const remove = async (id) => {
    if (!window.confirm('Delete this content item? This cannot be undone.')) return
    setError('')
    try {
      await http.delete(`/admin/${type}/${id}`)
      if (form.id === id) reset()
      await load()
    } catch (requestError) {
      setError(requestError.response?.data?.message || requestError.message)
    }
  }

  return (
    <main className="min-h-screen bg-ink-950 px-4 pb-12 pt-28 text-white">
      <div className="mx-auto max-w-6xl">
        <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
          <div><p className="overline">Authenticated CMS</p><h1 className="display mt-2 text-4xl">Khan Boostan CMS</h1></div>
          <div className="flex max-w-xl flex-col items-end gap-3"><p className="text-sm leading-relaxed text-white/45">Cinematic Home routes and story stages are database-driven. Edit them here instead of changing React code.</p><button type="button" onClick={() => dispatch(logoutAdmin())} className="rounded-full border border-white/15 px-4 py-2 text-xs font-semibold uppercase tracking-[.14em] text-white/70 transition hover:bg-white/10">Sign out</button></div>
        </div>
        <div className="mb-7 flex flex-wrap gap-2">{TYPES.map((itemType) => <button type="button" key={itemType} onClick={() => { setType(itemType); setForm(emptyForm) }} className={`rounded-full border px-4 py-2 text-sm transition ${type === itemType ? 'border-gold-400 bg-gold-400 text-ink-950' : 'border-white/10 bg-white/5 text-white/65 hover:bg-white/10'}`}>{itemType}</button>)}</div>
        {error && <div className="mb-5 rounded-xl border border-red-400/25 bg-red-400/10 p-4 text-sm text-red-100">{error}</div>}
        <form onSubmit={submit} className="mb-8 grid gap-3 rounded-2xl border border-white/10 bg-white/[0.025] p-5 md:grid-cols-2">
          <input className="rounded-lg border border-white/10 bg-white/10 p-3" placeholder="Slug" value={form.slug} onChange={(event) => setForm({ ...form, slug: event.target.value })} required />
          <input className="rounded-lg border border-white/10 bg-white/10 p-3" placeholder="Title" value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} required />
          <textarea className="min-h-48 rounded-lg border border-white/10 bg-white/10 p-3 font-mono text-sm" aria-label="Data JSON" value={form.data} onChange={(event) => setForm({ ...form, data: event.target.value })} />
          <textarea className="min-h-48 rounded-lg border border-white/10 bg-white/10 p-3 font-mono text-sm" aria-label="Translations JSON" value={form.translations} onChange={(event) => setForm({ ...form, translations: event.target.value })} />
          <label className="flex items-center gap-3 text-sm text-white/65"><input type="checkbox" checked={form.is_active} onChange={(event) => setForm({ ...form, is_active: event.target.checked })} /> Active</label>
          <label className="flex items-center gap-3 text-sm text-white/65">Sort order <input type="number" className="w-24 rounded-lg border border-white/10 bg-white/10 p-2" value={form.sort_order} onChange={(event) => setForm({ ...form, sort_order: event.target.value })} /></label>
          <div className="flex gap-3 md:col-span-2"><button className="rounded-lg bg-gold-400 px-5 py-3 font-semibold text-ink-950">{editing ? `Update ${type}` : `Add ${type}`}</button>{editing && <button type="button" onClick={reset} className="rounded-lg border border-white/15 px-5 py-3 text-white/70">Cancel</button>}</div>
        </form>
        {loading ? <p className="text-white/55">Loading…</p> : <div className="space-y-2">{items.map((item) => <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.035] p-4"><div><strong>{item.title}</strong><span className="ms-3 text-white/40">{item.slug}</span>{!item.is_active && <span className="ms-3 rounded-full bg-white/10 px-2 py-1 text-[10px] uppercase text-white/45">inactive</span>}</div><div className="flex gap-2"><button type="button" onClick={() => edit(item)} className="rounded-lg bg-white/10 px-3 py-2 text-sm hover:bg-white/15">Edit</button><button type="button" onClick={() => remove(item.id)} className="rounded-lg bg-red-500/15 px-3 py-2 text-sm text-red-200 hover:bg-red-500/25">Delete</button></div></div>)}</div>}
      </div>
    </main>
  )
}
