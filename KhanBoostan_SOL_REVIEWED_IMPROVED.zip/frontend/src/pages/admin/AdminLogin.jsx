import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Navigate, useNavigate, useSearchParams } from 'react-router-dom'
import { loginAdmin } from '../../features/auth/authSlice.js'

export default function AdminLogin() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const { token, status, error } = useSelector((state) => state.auth)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  if (token) return <Navigate to="/admin" replace />

  const submit = async (event) => {
    event.preventDefault()
    const result = await dispatch(loginAdmin({ email, password }))
    if (loginAdmin.fulfilled.match(result)) navigate('/admin', { replace: true })
  }

  return (
    <main className="flex min-h-screen items-center bg-ink-950 px-4 py-20 text-white">
      <form onSubmit={submit} className="mx-auto w-full max-w-md space-y-4 rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl">
        <div>
          <p className="overline">Secure administration</p>
          <h1 className="display mt-2 text-3xl">Khan Boostan CMS</h1>
        </div>
        {searchParams.get('expired') && <p className="rounded-xl border border-amber-300/20 bg-amber-300/10 p-3 text-sm text-amber-100">Your admin session expired. Please sign in again.</p>}
        <label className="block text-sm text-white/60">Email<input className="mt-2 w-full rounded-xl border border-white/10 bg-white/10 p-3 text-white outline-none focus:border-gold-400/50" type="email" autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} required /></label>
        <label className="block text-sm text-white/60">Password<input className="mt-2 w-full rounded-xl border border-white/10 bg-white/10 p-3 text-white outline-none focus:border-gold-400/50" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required /></label>
        {error && <p className="rounded-xl border border-red-400/20 bg-red-400/10 p-3 text-sm text-red-200">{error}</p>}
        <button className="w-full rounded-xl bg-gold-400 px-4 py-3 font-semibold text-ink-950 transition hover:bg-gold-300 disabled:cursor-not-allowed disabled:opacity-60" disabled={status === 'loading'}>{status === 'loading' ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </main>
  )
}
