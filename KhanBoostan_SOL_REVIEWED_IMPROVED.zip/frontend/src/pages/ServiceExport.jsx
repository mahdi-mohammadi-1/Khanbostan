import ServiceDetail from './service-detail.jsx'

export default function ServiceExport() {
  return <ServiceDetail slug="export" kicker="Services · Export" />
}
