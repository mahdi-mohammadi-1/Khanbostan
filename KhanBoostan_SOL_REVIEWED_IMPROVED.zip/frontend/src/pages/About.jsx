import { Eye, Flag, ShieldCheck } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function About() {
  const { t, company } = useI18n()
  usePageMeta({ title: t('about.title'), description: t('about.intro'), path: '/about' })
  const values = t('about.values')

  return (
    <>
      <PageHeader kicker={t('about.kicker')} title={t('about.title')} intro={t('about.intro')} image="/img/meeting-1.jpg" crumbs={[{ label: t('nav.about') }]} />
      <section className="bg-white py-20 sm:py-28">
        <div className="container-x grid grid-cols-1 items-center gap-14 lg:grid-cols-2 lg:gap-20">
          <div><SectionHeading kicker={t('about.storyKicker')} title={t('about.storyTitle')} className="mb-7" /><Reveal><p className="text-[16px] leading-[1.9] text-neutral-600">{t('about.storyText')}</p></Reveal><Reveal delay={0.1} className="mt-7 rounded-xl border border-gold-500/25 bg-gold-50 p-5"><p className="font-medium text-ink-900">{company.address}</p></Reveal></div>
          <Reveal><div className="img-zoom overflow-hidden rounded-2xl shadow-panel"><img src="/img/warehouse-1.jpg" alt="Khan Boostan trade operations" className="aspect-[4/3] w-full object-cover" /></div></Reveal>
        </div>
      </section>

      <section className="bg-paper py-20 sm:py-24">
        <div className="container-x grid grid-cols-1 gap-6 lg:grid-cols-2">
          {[[Flag, t('about.missionTitle'), t('about.missionText')], [Eye, t('about.visionTitle'), t('about.visionText')]].map(([Icon, title, text], index) => <Reveal key={title} delay={index * 0.08}><div className="card h-full p-8"><span className="mb-5 flex h-12 w-12 items-center justify-center rounded-lg bg-gold-500/15 text-gold-700"><Icon className="h-6 w-6" /></span><h2 className="display text-3xl text-ink-900">{title}</h2><p className="mt-4 text-[15px] leading-relaxed text-neutral-500">{text}</p></div></Reveal>)}
        </div>
      </section>

      <section className="relative overflow-hidden bg-ink-950 py-20 sm:py-24">
        <div className="grain-overlay absolute inset-0" />
        <div className="container-x relative"><SectionHeading kicker={t('about.valuesTitle')} title={t('about.valuesTitle')} dark align="center" /><Stagger className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">{values.map((value) => <StaggerItem key={value}><div className="card-dark flex h-full items-center gap-4 p-6"><ShieldCheck className="h-6 w-6 shrink-0 text-gold-400" /><h3 className="display text-xl text-white">{value}</h3></div></StaggerItem>)}</Stagger></div>
      </section>
      <CTASection />
    </>
  )
}
