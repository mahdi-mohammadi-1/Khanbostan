import { useMemo, useState } from 'react'
import { Search, X } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { ProductCard } from '../components/Cards.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function Products() {
  const { t, products, dir } = useI18n()
  const [query, setQuery] = useState('')

  usePageMeta({ title: t('productsPage.title'), description: t('productsPage.intro'), path: '/products' })

  const filtered = useMemo(() => {
    const search = query.trim().toLowerCase()
    if (!search) return products
    return products.filter((product) => `${product.name} ${product.blurb} ${product.hsCode}`.toLowerCase().includes(search))
  }, [products, query])

  return (
    <>
      <PageHeader kicker={t('productsPage.kicker')} title={t('productsPage.title')} intro={t('productsPage.intro')} image="/img/containers-2.jpg" crumbs={[{ label: t('common.products') }]} />
      <section className="bg-paper py-14 sm:py-20">
        <div className="container-x">
          <Reveal className="flex flex-col gap-5 rounded-2xl border border-ink-950/[0.08] bg-white p-5 shadow-card sm:flex-row sm:items-center sm:justify-between sm:p-6">
            <div>
              <p className="display text-2xl text-ink-900">{products.length} {t('productsPage.countNote')}</p>
              <p className="mt-1 text-[13px] text-neutral-400">{t('common.showing')} {filtered.length} {t('common.of')} {products.length} {t('common.items')}</p>
            </div>
            <div className="relative w-full sm:max-w-sm">
              <Search className={`pointer-events-none absolute top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400 ${dir === 'rtl' ? 'right-4' : 'left-4'}`} />
              <input value={query} onChange={(event) => setQuery(event.target.value)} className={`input ${dir === 'rtl' ? '!pr-11 !pl-10' : '!pl-11 !pr-10'}`} placeholder={t('common.search')} aria-label={t('common.search')} />
              {query && <button type="button" onClick={() => setQuery('')} className={`absolute top-1/2 -translate-y-1/2 text-neutral-400 hover:text-ink-900 ${dir === 'rtl' ? 'left-3' : 'right-3'}`} aria-label={t('common.clearSearch')}><X className="h-4 w-4" /></button>}
            </div>
          </Reveal>

          {filtered.length === 0 ? (
            <div className="mt-12 rounded-2xl border border-dashed border-ink-950/15 bg-white p-14 text-center">
              <p className="display text-2xl text-ink-900">{t('common.noProducts')}</p>
              <p className="mt-2 text-[14px] text-neutral-500">{t('common.tryAnother')}</p>
              <button type="button" onClick={() => setQuery('')} className="btn-dark mt-6 !px-6 !py-3 text-[13px]">{t('common.clearSearch')}</button>
            </div>
          ) : (
            <Stagger className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3" gap={0.05}>
              {filtered.map((product, index) => <StaggerItem key={product.slug}><ProductCard p={product} index={index} /></StaggerItem>)}
            </Stagger>
          )}

          <Reveal className="mt-14 rounded-2xl border border-gold-500/25 bg-gold-50 p-7">
            <p className="text-[14.5px] leading-relaxed text-neutral-600"><strong className="font-semibold text-ink-900">{t('productsPage.catalogTitle')}</strong> {t('productsPage.catalogText')}</p>
          </Reveal>
        </div>
      </section>
      <CTASection title={t('productsPage.ctaTitle')} text={t('productsPage.ctaText')} />
    </>
  )
}
