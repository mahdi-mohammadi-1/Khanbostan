import ServiceDetail from './service-detail.jsx'

export default function ServiceLogistics() {
  return <ServiceDetail slug="logistics" kicker="Services · Logistics" />
}
