import { ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { categories, industries } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function Industries() {
  usePageMeta({
    title: 'Industries We Serve',
    description:
      'Khan Boostan Limited serves agriculture, food & beverage, energy, oil & gas, mining, construction, manufacturing, industrial materials and consumer goods sectors.',
    path: '/industries',
  })

  return (
    <>
      <PageHeader
        kicker="Industries"
        title="Industries we serve"
        intro="Sector-focused trade solutions — the right products, suppliers and logistics for each industry we support."
        image="/img/construction-1.jpg"
        crumbs={[{ label: 'Industries' }]}
      />

      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <Stagger className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3" gap={0.06}>
            {industries.map((ind) => {
              const relatedCats = ind.related.map((r) => categories.find((c) => c.slug === r)).filter(Boolean)
              return (
                <StaggerItem key={ind.title}>
                  <div className="card group flex h-full flex-col p-7 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/50 hover:shadow-panel">
                    <div className="mb-5 flex items-center gap-4">
                      <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-ink-950 text-gold-400 transition-colors duration-500 group-hover:bg-gold-500 group-hover:text-ink-950" style={{ width: 52, height: 52 }}>
                        <ind.icon className="h-5 w-5" />
                      </span>
                      <h2 className="display text-2xl text-ink-900">{ind.title}</h2>
                    </div>
                    <p className="text-[14px] leading-relaxed text-neutral-500">{ind.blurb}</p>
                    <div className="mt-auto pt-6">
                      <p className="mb-3 font-display text-[11px] font-semibold uppercase tracking-[0.2em] text-neutral-400">Relevant products</p>
                      <div className="flex flex-wrap gap-2">
                        {relatedCats.map((c) => (
                          <Link
                            key={c.slug}
                            to={`/products?cat=${c.slug}`}
                            className="chip !py-1.5 !text-[12px] transition-all hover:!border-gold-500 hover:!text-gold-700"
                          >
                            {c.name}
                            <ArrowRight className="h-3 w-3 text-gold-600" />
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                </StaggerItem>
              )
            })}
          </Stagger>
        </div>
      </section>

      <section className="bg-ink-950 py-20">
        <div className="container-x grid grid-cols-1 items-center gap-10 lg:grid-cols-2">
          <Reveal>
            <SectionHeading kicker="Sector Expertise" title="Serving your sector, end to end" dark className="mb-0" />
            <p className="mt-5 max-w-lg text-[15px] leading-relaxed text-white/55">
              Sector knowledge changes everything in trade: the right grade, the right supplier, the right packaging, the right corridor. Our team
              structures each engagement around the specific demands of your industry.
            </p>
          </Reveal>
          <Reveal delay={0.12}>
            <div className="img-zoom rounded-2xl">
              <img src="/img/refinery-2.jpg" alt="Industrial energy facility" loading="lazy" className="aspect-[16/9] w-full object-cover" />
            </div>
          </Reveal>
        </div>
      </section>

      <CTASection title="Tell us your sector and requirement" text="We will match the right products, origins and terms to your industry." />
    </>
  )
}
