import { Link, Navigate, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Calendar, Clock, MessageCircle } from 'lucide-react'
import { articles } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { ArticleCard } from '../components/Cards.jsx'
import { Reveal } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function Article() {
  const { slug } = useParams()
  const a = articles.find((x) => x.slug === slug)
  usePageMeta({
    title: a ? a.title : 'Article',
    description: a ? a.excerpt : 'News & insights — Khan Boostan Limited',
    path: `/news/${slug}`,
  })
  if (!a) return <Navigate to="/news" replace />

  const others = articles.filter((x) => x.slug !== slug).slice(0, 3)
  const idx = articles.findIndex((x) => x.slug === slug)
  const next = articles[idx + 1] || articles[0]

  return (
    <>
      <PageHeader
        kicker={a.category}
        title={a.title}
        image={a.image}
        crumbs={[{ label: 'News & Insights', to: '/news' }, { label: a.title.slice(0, 42) + '…' }]}
      >
        <span className="flex items-center gap-4 text-[13px] text-white/55">
          <span className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gold-400" />
            {new Date(a.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}
          </span>
          <span className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-gold-400" /> {a.read}
          </span>
        </span>
      </PageHeader>

      <section className="bg-white py-16 sm:py-20">
        <div className="container-x grid grid-cols-1 gap-14 lg:grid-cols-[1fr_340px]">
          {/* body */}
          <article className="prose-article max-w-3xl">
            <Reveal>
              <p className="!text-[19px] !leading-[1.8] !text-neutral-600">{a.excerpt}</p>
              {a.body.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </Reveal>

            <Reveal className="mt-10 flex flex-col items-start justify-between gap-5 rounded-2xl bg-ink-950 p-7 sm:flex-row sm:items-center">
              <div>
                <p className="display text-xl text-white">Need trade support on this topic?</p>
                <p className="mt-1 text-[13.5px] text-white/50">Our trade desk answers practical questions every working day.</p>
              </div>
              <Link to="/contact" className="btn-gold !px-6 !py-3 text-[13px]">
                <MessageCircle className="h-4 w-4" /> Ask the trade desk
              </Link>
            </Reveal>

            <Reveal className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-ink-950/10 pt-8">
              <Link to="/news" className="link-arrow text-[13px]">
                <ArrowLeft className="h-3.5 w-3.5" /> All articles
              </Link>
              <Link to={`/news/${next.slug}`} className="link-arrow text-[13px]">
                Next: {next.title.slice(0, 34)}… <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Reveal>
          </article>

          {/* sidebar */}
          <aside className="space-y-8">
            <Reveal>
              <div className="card p-6">
                <p className="overline mb-4">Categories</p>
                <ul className="space-y-2.5">
                  {[...new Set(articles.map((x) => x.category))].map((c) => (
                    <li key={c}>
                      <Link to="/news" className="group flex items-center justify-between text-[14px] text-neutral-600 transition-colors hover:text-gold-700">
                        {c}
                        <span className="rounded-full bg-paper px-2.5 py-0.5 text-[12px] font-semibold text-neutral-500 group-hover:bg-gold-500/15 group-hover:text-gold-700">
                          {articles.filter((x) => x.category === c).length}
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
            <Reveal delay={0.08}>
              <div className="card p-6">
                <p className="overline mb-4">Talk to us</p>
                <p className="text-[13.5px] leading-relaxed text-neutral-500">Direct answers from the people who structure the deals.</p>
                <Link to="/request-quote" className="btn-gold mt-5 w-full py-3 text-[13px]">
                  Request a Quote
                </Link>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>

      <section className="bg-paper py-20">
        <div className="container-x">
          <Reveal className="mb-10">
            <h2 className="display text-3xl text-ink-900">More insights</h2>
          </Reveal>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {others.map((o) => (
              <ArticleCard key={o.slug} a={o} />
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  )
}
