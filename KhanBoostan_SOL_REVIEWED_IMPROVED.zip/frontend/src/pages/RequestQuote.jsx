import { CheckCircle2 } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { QuoteForm } from '../components/Forms.jsx'
import { Reveal } from '../components/Reveal.jsx'

export default function RequestQuote() {
  const { t } = useI18n()
  const steps = t('quotePage.steps')
  usePageMeta({ title: t('quotePage.title'), description: t('quotePage.intro'), path: '/request-quote' })

  return (
    <>
      <PageHeader kicker={t('quotePage.kicker')} title={t('quotePage.title')} intro={t('quotePage.intro')} image="/img/containers-2.jpg" crumbs={[{ label: t('common.requestQuote') }]} />
      <section className="bg-paper py-16 sm:py-24">
        <div className="container-x grid grid-cols-1 gap-10 lg:grid-cols-[0.7fr_1.3fr] lg:gap-14">
          <Reveal><aside className="rounded-2xl bg-ink-950 p-8 text-white shadow-panel lg:sticky lg:top-28"><h2 className="display text-3xl">{t('quotePage.sideTitle')}</h2><ol className="mt-7 space-y-5">{steps.map((step, index) => <li key={step} className="flex gap-4"><span className="display flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gold-500 text-ink-950">{index + 1}</span><span className="pt-1 text-[14px] leading-relaxed text-white/65">{step}</span></li>)}</ol><div className="mt-8 flex items-center gap-3 border-t border-white/[0.08] pt-6 text-[13px] text-white/45"><CheckCircle2 className="h-5 w-5 text-gold-400" />B2B · Import · Export · Logistics</div></aside></Reveal>
          <Reveal delay={0.08}><div className="rounded-2xl border border-ink-950/[0.08] bg-white p-7 shadow-card sm:p-9"><QuoteForm /></div></Reveal>
        </div>
      </section>
    </>
  )
}
