import { Link } from 'react-router-dom'
import { ArrowRight, FileCheck2, Globe2, PackageSearch, SearchCheck, Ship, Truck } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { ServiceCard } from '../components/Cards.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

const icons = { Ship, PackageSearch, Globe2, SearchCheck, FileCheck2, Truck }

export default function Services() {
  const { t, services, dir } = useI18n()
  usePageMeta({ title: t('servicesPage.title'), description: t('servicesPage.intro'), path: '/services' })
  const extended = t('servicesPage.extendedItems')

  return (
    <>
      <PageHeader kicker={t('servicesPage.kicker')} title={t('servicesPage.title')} intro={t('servicesPage.intro')} image="/img/warehouse-2.jpg" crumbs={[{ label: t('common.services') }]} />
      <section className="bg-white py-20 sm:py-28">
        <div className="container-x">
          <SectionHeading kicker={t('servicesPage.portfolio')} title={t('servicesPage.whatWeDo')} intro={t('servicesPage.portfolioIntro')} />
          <Stagger className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3" gap={0.06}>
            {services.map((service) => <StaggerItem key={service.slug}><ServiceCard s={service} Icon={icons[service.icon] || Globe2} /></StaggerItem>)}
          </Stagger>
        </div>
      </section>

      <section className="relative overflow-hidden bg-ink-950 py-20 sm:py-28">
        <div className="grain-overlay absolute inset-0" />
        <div className="container-x relative grid grid-cols-1 items-center gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          <SectionHeading kicker={t('servicesPage.method')} title={t('servicesPage.methodTitle')} dark className="mb-0" />
          <Reveal><div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] p-8"><p className="text-[16px] leading-[1.9] text-white/60">{t('servicesPage.methodText')}</p><div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3">{['01','02','03','04','05','06'].map((number) => <span key={number} className="display rounded-lg border border-white/[0.08] bg-white/[0.03] py-4 text-center text-2xl text-gold-400">{number}</span>)}</div></div></Reveal>
        </div>
      </section>

      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <SectionHeading kicker={t('servicesPage.extended')} title={t('servicesPage.extendedTitle')} />
          <Stagger className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4" gap={0.05}>
            {extended.map(([title, text]) => <StaggerItem key={title}><div className="card h-full p-6"><span className="mb-3 block h-1 w-8 bg-gold-500" /><h3 className="display text-xl text-ink-900">{title}</h3><p className="mt-2 text-[13.5px] leading-relaxed text-neutral-500">{text}</p></div></StaggerItem>)}
          </Stagger>
          <Reveal className="mt-12 text-center"><Link to="/request-quote" className="link-arrow text-[14px]">{t('servicesPage.discuss')}<ArrowRight className={`h-4 w-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} /></Link></Reveal>
        </div>
      </section>
      <CTASection title={t('servicesPage.finalTitle')} text={t('servicesPage.finalText')} />
    </>
  )
}
