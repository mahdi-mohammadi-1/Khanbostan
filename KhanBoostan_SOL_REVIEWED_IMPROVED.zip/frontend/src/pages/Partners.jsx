import { Factory, Handshake, Landmark, Store, Truck } from 'lucide-react'
import { partnersNote, partnerTypes } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

const ICONS = { Factory, Store, Truck, Landmark, Handshake }

export default function Partners() {
  usePageMeta({
    title: 'Partners',
    description: 'Partners of Khan Boostan Limited — suppliers, manufacturers, buyers, logistics partners, distributors and strategic partners. Logos published with official permission only.',
    path: '/partners',
  })

  return (
    <>
      <PageHeader
        kicker="Partnership"
        title="Partners & network"
        intro="International trade is a network business — and we build ours on permission, trust and mutual performance."
        image="/img/meeting-2.jpg"
        crumbs={[{ label: 'Partners' }]}
      />

      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <Reveal className="mb-12 rounded-2xl border border-gold-500/30 bg-gold-50 p-6 text-center">
            <p className="mx-auto max-w-3xl text-[14.5px] leading-relaxed text-neutral-600">
              <strong className="font-semibold text-ink-900">Partner logos</strong> are published on this page only after official permission of
              each organization. {partnersNote}
            </p>
          </Reveal>

          <Stagger className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3" gap={0.07}>
            {partnerTypes.map((pt) => {
              const Icon = ICONS[pt.icon] || Handshake
              return (
                <StaggerItem key={pt.title}>
                  <div className="card group relative h-full overflow-hidden p-7 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/50 hover:shadow-panel">
                    <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-gold-100 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />
                    <span className="mb-5 flex h-12 w-12 items-center justify-center rounded-lg bg-ink-950 text-gold-400 transition-colors duration-500 group-hover:bg-gold-500 group-hover:text-ink-950">
                      <Icon className="h-5 w-5" />
                    </span>
                    <h3 className="display text-xl text-ink-900">{pt.title}</h3>
                    <p className="mt-2 text-[13.5px] leading-relaxed text-neutral-500">{pt.desc}</p>
                    <div className="mt-6 grid grid-cols-3 gap-3 border-t border-dashed border-ink-950/10 pt-6">
                      {[0, 1, 2].map((i) => (
                        <div key={i} className="flex aspect-[4/3] items-center justify-center rounded-lg border border-dashed border-ink-950/15 bg-white/60">
                          <span className="font-display text-[10px] font-semibold uppercase tracking-[0.16em] text-neutral-300">Logo</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </StaggerItem>
              )
            })}
          </Stagger>

          <Reveal delay={0.15} className="mt-16 text-center">
            <SectionHeading kicker="Become a Partner" title="Let's build the network together" align="center" className="mb-6" />
            <p className="mx-auto max-w-xl text-[14.5px] leading-relaxed text-neutral-500">
              Suppliers, buyers, distributors, logistics providers and institutions — if our markets match your ambitions, we would like to talk.
            </p>
          </Reveal>
        </div>
      </section>

      <CTASection title="Interested in a partnership?" text="Contact our management team — partnerships start with a conversation." />
    </>
  )
}
