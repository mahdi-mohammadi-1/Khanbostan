import { Clock3, Mail, MapPin, MessageCircle, Phone } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { ContactForm } from '../components/Forms.jsx'
import { Reveal } from '../components/Reveal.jsx'

export default function Contact() {
  const { t, company } = useI18n()
  usePageMeta({ title: t('contactPage.title'), description: t('contactPage.intro'), path: '/contact' })
  const contactItems = [
    [MapPin, t('common.address'), company.address], [Phone, t('common.phone'), company.phone], [Mail, t('common.email'), company.email], [Clock3, t('contactPage.hours'), t('contactPage.hoursValue')],
  ]

  return (
    <>
      <PageHeader kicker={t('contactPage.kicker')} title={t('contactPage.title')} intro={t('contactPage.intro')} image="/img/meeting-1.jpg" crumbs={[{ label: t('nav.contact') }]} />
      <section className="bg-paper py-16 sm:py-24">
        <div className="container-x grid grid-cols-1 gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          <div>
            <Reveal><h2 className="display text-3xl text-ink-900">{t('contactPage.detailsTitle')}</h2></Reveal>
            <div className="mt-7 space-y-4">
              {contactItems.map(([Icon, label, value], index) => <Reveal key={label} delay={index * 0.05}><div className="card flex items-start gap-4 p-5"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-ink-950 text-gold-400"><Icon className="h-5 w-5" /></span><div><p className="font-display text-[11px] font-semibold uppercase tracking-[0.14em] text-neutral-400">{label}</p><p className="mt-1 text-[14.5px] font-medium text-ink-900">{value}</p></div></div></Reveal>)}
            </div>
            <a href="https://wa.me/93000000000" target="_blank" rel="noreferrer" className="btn-dark mt-6 w-full py-4 text-[14px]"><MessageCircle className="h-5 w-5 text-gold-400" />{t('common.whatsapp')}</a>
          </div>
          <Reveal delay={0.08}><div className="rounded-2xl border border-ink-950/[0.08] bg-white p-7 shadow-card sm:p-9"><h2 className="display mb-7 text-3xl text-ink-900">{t('contactPage.formTitle')}</h2><ContactForm /></div></Reveal>
        </div>
      </section>
    </>
  )
}
