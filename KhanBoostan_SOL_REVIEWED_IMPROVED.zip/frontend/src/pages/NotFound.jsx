import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'

export default function NotFound() {
  const { t } = useI18n()
  usePageMeta({
    title: t('notFound.title'),
    description: t('notFound.text'),
    path: '/404',
  })
  return (
    <section className="relative flex min-h-[100svh] items-center overflow-hidden bg-ink-950">
      <div className="grain-overlay absolute inset-0" />
      <div
        className="pointer-events-none absolute inset-0 opacity-25"
        style={{ backgroundImage: 'url(/img/containers-1.jpg)', backgroundSize: 'cover', backgroundPosition: 'center' }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/70 to-ink-950/60" />
      <div className="container-x relative py-32 text-center">
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="display text-[26vw] leading-none text-white/[0.06] sm:text-[180px]" aria-hidden="true">
          404
        </motion.p>
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.15 }} className="-mt-10 sm:-mt-20">
          <h1 className="display text-4xl text-white sm:text-5xl">{t('notFound.title')}</h1>
          <p className="mx-auto mt-4 max-w-md text-[15px] text-white/55">{t('notFound.text')}</p>
          <div className="mt-9 flex flex-wrap justify-center gap-4">
            <Link to="/" className="btn-gold">
              {t('notFound.back')}
            </Link>
            <Link to="/contact" className="btn-outline">
              {t('notFound.contact')}
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
