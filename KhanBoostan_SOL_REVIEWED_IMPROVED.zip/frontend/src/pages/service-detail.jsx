import { Link } from 'react-router-dom'
import { ArrowRight, CheckCircle2 } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading, CTA } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function ServiceDetail({ slug }) {
  const { t, services, dir } = useI18n()
  const service = services.find((item) => item.slug === slug)
  usePageMeta({ title: service?.title || t('common.services'), description: service?.blurb || t('servicesPage.intro'), path: service?.route || '/services' })
  if (!service) return null
  const others = services.filter((item) => item.slug !== slug)

  return (
    <>
      <PageHeader kicker={`${t('common.services')} · ${service.title}`} title={service.title} intro={service.blurb} image={service.image} crumbs={[{ label: t('common.services'), to: '/services' }, { label: service.title }]} />
      <section className="bg-white py-20 sm:py-28">
        <div className="container-x grid grid-cols-1 gap-14 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <SectionHeading kicker={t('serviceDetail.capabilities')} title={t('serviceDetail.includes')} className="mb-8" />
            <Reveal><p className="text-[15.5px] leading-[1.85] text-neutral-600">{t('serviceDetail.body')}</p></Reveal>
            <Reveal delay={0.1} className="mt-8"><CTA to="/request-quote" variant="gold">{t('common.requestQuote')}</CTA></Reveal>
          </div>
          <Stagger className="grid grid-cols-1 gap-4 sm:grid-cols-2" gap={0.05}>
            {service.features.map((feature) => <StaggerItem key={feature}><div className="card flex h-full items-start gap-3.5 p-5"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-gold-600" /><span className="text-[14.5px] font-medium leading-snug text-ink-900">{feature}</span></div></StaggerItem>)}
          </Stagger>
        </div>
      </section>

      {service.steps.length > 0 && (
        <section className="relative overflow-hidden bg-ink-950 py-20 sm:py-28">
          <div className="grain-overlay absolute inset-0" />
          <div className="container-x relative">
            <SectionHeading kicker={t('serviceDetail.workflow')} title={t('serviceDetail.process')} intro={t('serviceDetail.processIntro')} dark align="center" />
            <Stagger className="mx-auto grid max-w-6xl grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3" gap={0.05}>
              {service.steps.map((step, index) => <StaggerItem key={`${step.t}-${index}`}><div className="card-dark h-full p-6"><span className="display text-4xl text-gold-500/40">{String(index + 1).padStart(2, '0')}</span><h3 className="display mt-4 text-xl text-white">{step.t}</h3><p className="mt-2 text-[13.5px] leading-relaxed text-white/50">{step.d}</p></div></StaggerItem>)}
            </Stagger>
          </div>
        </section>
      )}

      <section className="bg-paper py-20">
        <div className="container-x">
          <Reveal className="mb-8"><h2 className="display text-3xl text-ink-900">{t('serviceDetail.other')}</h2></Reveal>
          <div className="flex flex-wrap gap-3">
            {others.map((item) => <Link key={item.slug} to={item.route} className="chip group !py-3 !text-[14px] hover:!border-gold-500 hover:!text-gold-700">{item.title}<ArrowRight className={`h-3.5 w-3.5 ${dir === 'rtl' ? 'rotate-180' : ''}`} /></Link>)}
          </div>
        </div>
      </section>
      <CTASection title={t('serviceDetail.support')} text={t('serviceDetail.supportText')} />
    </>
  )
}
