import { Info, Send } from 'lucide-react'
import { Link } from 'react-router-dom'
import { projects, projectsNote } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { SectionHeading } from '../components/UI.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function Projects() {
  usePageMeta({
    title: 'Projects & Business Activities',
    description: 'Project portfolio of Khan Boostan Limited — structured and ready for verified project entries.',
    path: '/projects',
  })

  return (
    <>
      <PageHeader
        kicker="Track Record"
        title="Projects & activities"
        intro="A structured portfolio for our trading projects and business activities."
        image="/img/containers-1.jpg"
        crumbs={[{ label: 'Projects' }]}
      />

      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <Reveal className="mb-12 flex items-start gap-4 rounded-2xl border border-steel-500/25 bg-steel-100/60 p-6">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-steel-500" />
            <p className="text-[14.5px] leading-relaxed text-neutral-600">
              <strong className="font-semibold text-ink-900">Transparency note:</strong> {projectsNote} No projects are invented or estimated — this
              page shows the exact structure real entries will use.
            </p>
          </Reveal>

          <Stagger className="grid grid-cols-1 gap-6 md:grid-cols-3" gap={0.08}>
            {projects.map((p, i) => (
              <StaggerItem key={p.title}>
                <div className="card group h-full overflow-hidden transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/50 hover:shadow-panel">
                  <div className="relative flex h-44 items-center justify-center overflow-hidden bg-ink-950">
                    <div className="grain-overlay absolute inset-0" />
                    <span className="display text-7xl text-white/10 transition-colors duration-500 group-hover:text-gold-500/30">{String(i + 1).padStart(2, '0')}</span>
                    <span className="absolute bottom-4 left-4 rounded-md bg-white/10 px-3 py-1.5 font-display text-[10.5px] font-semibold uppercase tracking-[0.18em] text-white/70 backdrop-blur">
                      Entry pending
                    </span>
                  </div>
                  <div className="p-7">
                    <h3 className="display text-xl text-ink-900">{p.title}</h3>
                    <dl className="mt-4 space-y-2.5 text-[13.5px]">
                      {[
                        ['Industry', p.industry],
                        ['Country', p.country],
                        ['Year', p.year],
                      ].map(([k, v]) => (
                        <div key={k} className="flex justify-between gap-4 border-b border-dashed border-ink-950/10 pb-2">
                          <dt className="font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-neutral-400">{k}</dt>
                          <dd className="text-neutral-500">{v}</dd>
                        </div>
                      ))}
                    </dl>
                    <p className="mt-4 text-[13px] leading-relaxed text-neutral-400">{p.scope}</p>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </Stagger>

          <Reveal delay={0.15} className="mt-16">
            <SectionHeading kicker="Entry Structure" title="How projects will be presented" className="mb-8" />
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { t: 'Project name', d: 'A clear, factual title for the activity or transaction.' },
                { t: 'Scope & product', d: 'What was traded or delivered — product, volume, service.' },
                { t: 'Market & timing', d: 'Country, counterparty type and year of execution.' },
                { t: 'Results', d: 'Verified outcomes only — delivery, volume, timeline.' },
              ].map((x, i) => (
                <Reveal key={x.t} delay={i * 0.06}>
                  <div className="card h-full p-6">
                    <span className="display block text-3xl text-gold-500/40">{String(i + 1).padStart(2, '0')}</span>
                    <h4 className="display mt-2 text-lg text-ink-900">{x.t}</h4>
                    <p className="mt-1.5 text-[13px] leading-relaxed text-neutral-500">{x.d}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <CTASection title="Have a project in mind?" text="Tell us the scope — products, volumes and destination — and let's plan it together." />
    </>
  )
}
