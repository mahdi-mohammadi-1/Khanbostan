import ServiceDetail from './service-detail.jsx'

export default function ServiceSourcing() {
  return <ServiceDetail slug="sourcing" kicker="Services · Sourcing & Procurement" />
}
