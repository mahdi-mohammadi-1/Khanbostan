import { useMemo, useState } from 'react'
import { Search, X } from 'lucide-react'
import { articles } from '../lib/data.jsx'
import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { ArticleCard } from '../components/Cards.jsx'
import { Reveal, Stagger, StaggerItem } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function News() {
  usePageMeta({
    title: 'News & Insights',
    description: 'Trade guides, market insights and sourcing knowledge from the Khan Boostan Limited trade desk.',
    path: '/news',
  })

  const [q, setQ] = useState('')
  const [cat, setCat] = useState('All')

  const cats = ['All', ...new Set(articles.map((a) => a.category))]
  const featured = articles.find((a) => a.featured) || articles[0]

  const filtered = useMemo(() => {
    return articles.filter((a) => {
      const okCat = cat === 'All' || a.category === cat
      const okQ = !q || (a.title + ' ' + a.excerpt).toLowerCase().includes(q.toLowerCase())
      return okCat && okQ
    })
  }, [q, cat])

  return (
    <>
      <PageHeader
        kicker="News & Insights"
        title="Trade intelligence"
        intro="Practical guides and market insights for buyers, suppliers and trade professionals."
        image="/img/meeting-1.jpg"
        crumbs={[{ label: 'News & Insights' }]}
      />

      <section className="bg-paper py-16 sm:py-20">
        <div className="container-x">
          {/* featured */}
          <Reveal>
            <article className="group card grid grid-cols-1 overflow-hidden lg:grid-cols-2">
              <div className="img-zoom relative h-full min-h-[280px]">
                <img src={featured.image} alt="" loading="lazy" className="h-full w-full object-cover" />
                <span className="absolute left-5 top-5 rounded-md bg-gold-500 px-3 py-1.5 font-display text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-950">
                  Featured
                </span>
              </div>
              <div className="flex flex-col justify-center p-8 lg:p-12">
                <p className="overline mb-4">{featured.category} · {new Date(featured.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</p>
                <h2 className="display text-3xl leading-tight text-ink-900 transition-colors group-hover:text-gold-700 lg:text-4xl">{featured.title}</h2>
                <p className="mt-4 text-[15px] leading-relaxed text-neutral-500">{featured.excerpt}</p>
                <a href={`/news/${featured.slug}`} className="link-arrow mt-7 text-[14px]">
                  Read Article
                </a>
              </div>
            </article>
          </Reveal>

          {/* controls */}
          <Reveal className="mt-14 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-2">
              {cats.map((c) => (
                <button
                  key={c}
                  onClick={() => setCat(c)}
                  className={`chip ${cat === c ? '!border-gold-500 !bg-gold-500 !text-ink-950' : 'hover:border-gold-500/60'}`}
                >
                  {c}
                </button>
              ))}
            </div>
            <div className="relative w-full max-w-xs">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} className="input !pl-11" placeholder="Search articles…" aria-label="Search articles" />
              {q && (
                <button onClick={() => setQ('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-ink-900" aria-label="Clear search">
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </Reveal>

          {/* grid */}
          {filtered.length === 0 ? (
            <div className="mt-12 rounded-2xl border border-dashed border-ink-950/15 bg-white p-14 text-center">
              <p className="display text-2xl text-ink-900">No articles found</p>
              <button onClick={() => { setQ(''); setCat('All') }} className="btn-dark mt-6 !px-6 !py-3 text-[13px]">
                Reset filters
              </button>
            </div>
          ) : (
            <Stagger className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3" gap={0.07}>
              {filtered.map((a) => (
                <StaggerItem key={a.slug}>
                  <ArticleCard a={a} />
                </StaggerItem>
              ))}
            </Stagger>
          )}
        </div>
      </section>

      <CTASection title="Prefer answers to articles?" text="Our trade desk is available for your questions — email, phone or WhatsApp." />
    </>
  )
}
