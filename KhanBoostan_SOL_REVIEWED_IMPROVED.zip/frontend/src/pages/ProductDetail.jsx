import { Link, Navigate, useParams } from 'react-router-dom'
import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, ArrowRight, FileCheck2, Layers, MapPin, Package, Send, Timer, Truck } from 'lucide-react'
import { usePageMeta } from '../lib/seo.js'
import { useI18n } from '../i18n.jsx'
import PageHeader from '../components/PageHeader.jsx'
import { ProductCard } from '../components/Cards.jsx'
import { Reveal } from '../components/Reveal.jsx'
import CTASection from '../components/CTASection.jsx'

export default function ProductDetail() {
  const { slug } = useParams()
  const { t, products, dir } = useI18n()
  const product = products.find((item) => item.slug === slug)
  const [imageIndex, setImageIndex] = useState(0)

  usePageMeta({ title: product?.name || t('common.product'), description: product?.blurb || t('productsPage.intro'), path: `/products/${slug}` })
  if (!product) return <Navigate to="/products" replace />

  const gallery = [product.image, '/img/containers-1.jpg', '/img/warehouse-1.jpg']
  const related = products.filter((item) => item.slug !== product.slug).slice(0, 3)
  const specs = [
    [t('spec.origin'), product.origin, MapPin], [t('spec.grade'), product.grade, Layers], [t('spec.packaging'), product.packaging, Package],
    [t('spec.moq'), product.moq, Truck], [t('spec.hs'), product.hsCode, FileCheck2], [t('spec.terms'), product.incoterms, Send],
    [t('spec.lead'), product.leadTime, Timer], [t('spec.certifications'), product.certifications, FileCheck2],
  ]

  return (
    <>
      <PageHeader kicker={t('common.product')} title={product.name} intro={product.blurb} image={product.image} crumbs={[{ label: t('common.products'), to: '/products' }, { label: product.name }]} />
      <section className="bg-white py-14 sm:py-20">
        <div className="container-x grid grid-cols-1 gap-12 lg:grid-cols-[1.1fr_1fr]">
          <div>
            <div className="img-zoom relative overflow-hidden rounded-2xl shadow-panel">
              <motion.img key={imageIndex} src={gallery[imageIndex]} alt={product.name} initial={{ opacity: 0.4, scale: 1.04 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.45 }} className="aspect-[4/3] w-full object-cover" />
              <span className="absolute start-5 top-5 rounded-md bg-ink-950/85 px-3.5 py-1.5 font-display text-[11px] font-semibold uppercase tracking-[0.18em] text-gold-300 backdrop-blur">HS {product.hsCode}</span>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-4">
              {gallery.map((image, index) => <button type="button" key={image} onClick={() => setImageIndex(index)} className={`img-zoom overflow-hidden rounded-lg border-2 transition ${index === imageIndex ? 'border-gold-500 shadow-gold' : 'border-transparent opacity-60 hover:opacity-100'}`}><img src={image} alt="" className="aspect-[4/3] w-full object-cover" /></button>)}
            </div>
          </div>

          <div>
            <Reveal><p className="overline mb-3">{t('common.productOverview')}</p><p className="text-[15.5px] leading-[1.8] text-neutral-600">{product.blurb}</p></Reveal>
            <Reveal delay={0.08} className="mt-8">
              <h2 className="display mb-4 text-xl text-ink-900">{t('common.specifications')}</h2>
              <dl className="overflow-hidden rounded-xl border border-ink-950/10">
                {specs.map(([label, value, Icon], index) => (
                  <div key={label} className={`flex items-center justify-between gap-6 px-5 py-3.5 ${index % 2 === 0 ? 'bg-paper' : 'bg-white'} ${index > 0 ? 'border-t border-ink-950/[0.05]' : ''}`}>
                    <dt className="flex items-center gap-2.5 font-display text-[12px] font-semibold uppercase tracking-[0.12em] text-neutral-400"><Icon className="h-4 w-4 text-gold-600" />{label}</dt>
                    <dd className="text-end text-[13.5px] font-medium text-ink-900">{value}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
            <Reveal delay={0.14} className="mt-8 flex flex-wrap gap-4">
              <Link to={`/request-quote?product=${encodeURIComponent(product.name)}`} className="btn-gold flex-1 py-4 text-[15px] sm:flex-none sm:px-10"><Send className="h-4 w-4" />{t('common.requestQuote')}</Link>
              <Link to="/products" className="btn-outline !border-ink-950/20 !text-ink-900 hover:!border-gold-500 hover:!text-gold-600">
                {dir === 'rtl' ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}{t('common.backCatalog')}
              </Link>
            </Reveal>
            <Reveal delay={0.2} className="mt-8 rounded-xl border border-gold-500/25 bg-gold-50 p-5">
              <p className="text-[13px] leading-relaxed text-neutral-600"><strong className="font-semibold text-ink-900">{t('common.pricingTitle')}</strong> {t('common.pricingText')}</p>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="bg-paper py-20">
        <div className="container-x">
          <Reveal className="mb-10 flex items-end justify-between gap-6"><h2 className="display text-3xl text-ink-900 sm:text-4xl">{t('common.relatedProducts')}</h2><Link to="/products" className="link-arrow text-[13px]">{t('common.viewAll')}<ArrowRight className={`h-3.5 w-3.5 ${dir === 'rtl' ? 'rotate-180' : ''}`} /></Link></Reveal>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">{related.map((item, index) => <ProductCard key={item.slug} p={item} index={index} />)}</div>
        </div>
      </section>
      <CTASection title={`${t('common.interested')} ${product.name}`} text={t('common.sendQuantity')} />
    </>
  )
}
