import { usePageMeta } from '../lib/seo.js'
import PageHeader from '../components/PageHeader.jsx'
import { Reveal } from '../components/Reveal.jsx'
import { useI18n } from '../i18n.jsx'

export default function Legal({ page }) {
  const { t, dir } = useI18n()
  const data = t(`legal.${page}`)
  usePageMeta({
    title: data.title,
    description: data.intro,
    path: `/${page}`,
  })

  return (
    <>
      <PageHeader kicker={t('legal.kicker')} title={data.title} intro={data.intro} image="/img/meeting-2.jpg" crumbs={[{ label: data.title }]} />
      <section className="bg-white py-16 sm:py-24">
        <div className="container-x max-w-3xl">
          <div className="space-y-10">
            {data.sections.map(([title, text], i) => (
              <Reveal key={title} delay={Math.min(i * 0.03, 0.2)}>
                <div className={`${dir === 'rtl' ? 'border-r-2 pr-6' : 'border-l-2 pl-6'} border-gold-500/60`}>
                  <h2 className="display text-2xl text-ink-900">{title}</h2>
                  <p className="mt-3 text-[15px] leading-[1.85] text-neutral-600">{text}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-14">
            <p className="text-[13px] text-neutral-400">{t('legal.lastUpdated')}</p>
          </Reveal>
        </div>
      </section>
    </>
  )
}
