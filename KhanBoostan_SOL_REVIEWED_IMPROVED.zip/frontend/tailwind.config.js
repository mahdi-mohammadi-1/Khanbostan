/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#060B14',
          900: '#0A1220',
          800: '#0E192C',
          700: '#15243B',
          600: '#1E3250',
          500: '#2A4366',
        },
        gold: {
          50: '#FBF7EE',
          100: '#F6EDD9',
          200: '#ECDDB6',
          300: '#DFC88D',
          400: '#D0B069',
          500: '#C29A5F',
          600: '#A87F43',
          700: '#866233',
          800: '#674B29',
          900: '#4C3720',
        },
        steel: {
          100: '#DCE9F6',
          300: '#8FBDE0',
          400: '#3E8FD4',
          500: '#166BB2',
          600: '#125A96',
          700: '#0E4778',
          900: '#0A2A47',
        },
        paper: '#F7F6F2',
        mist: '#E9E7E1',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['"Barlow Condensed"', 'Inter', 'sans-serif'],
      },
      letterSpacing: {
        widest2: '0.22em',
      },
      boxShadow: {
        card: '0 1px 2px rgba(6,11,20,0.06), 0 12px 32px -12px rgba(6,11,20,0.16)',
        panel: '0 24px 80px -16px rgba(6,11,20,0.55)',
        gold: '0 12px 32px -8px rgba(194,154,95,0.45)',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        kenburns: {
          '0%': { transform: 'scale(1.05) translateY(0)' },
          '100%': { transform: 'scale(1.14) translateY(-1.5%)' },
        },
        pulseDot: {
          '0%': { transform: 'scale(0.6)', opacity: '0.9' },
          '100%': { transform: 'scale(2.6)', opacity: '0' },
        },
        dashFlow: {
          '0%': { strokeDashoffset: '240' },
          '100%': { strokeDashoffset: '0' },
        },
        floatY: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
      },
      animation: {
        marquee: 'marquee 32s linear infinite',
        kenburns: 'kenburns 22s ease-out forwards',
        'pulse-dot': 'pulseDot 2.4s ease-out infinite',
        dashflow: 'dashFlow 3.2s linear infinite',
        floaty: 'floatY 5s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
