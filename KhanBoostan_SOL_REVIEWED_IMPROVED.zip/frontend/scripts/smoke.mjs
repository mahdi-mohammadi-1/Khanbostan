// SSR smoke test v3 — renders each page inside a proper route context
import { createServer } from 'vite'
import react from '@vitejs/plugin-react'
import React from 'react'
import { renderToString } from 'react-dom/server'
import { MemoryRouter, Route, Routes } from 'react-router-dom'

const vite = await createServer({
  configFile: false,
  plugins: [react()],
  optimizeDeps: { noDiscovery: true, include: [] },
  server: { middlewareMode: true },
  appType: 'custom',
  logLevel: 'error',
})

const cases = [
  ['/src/pages/Home.jsx', '/', '*'],
  ['/src/pages/About.jsx', '/about', '*'],
  ['/src/pages/Products.jsx', '/products', '*'],
  ['/src/pages/ProductDetail.jsx', '/products/milling-wheat', '/products/:slug'],
  ['/src/pages/Services.jsx', '/services', '*'],
  ['/src/pages/ServiceImport.jsx', '/services/import', '*'],
  ['/src/pages/ServiceExport.jsx', '/services/export', '*'],
  ['/src/pages/ServiceSourcing.jsx', '/services/sourcing', '*'],
  ['/src/pages/ServiceLogistics.jsx', '/services/logistics', '*'],
  ['/src/pages/Markets.jsx', '/markets', '*'],
  ['/src/pages/Industries.jsx', '/industries', '*'],
  ['/src/pages/Projects.jsx', '/projects', '*'],
  ['/src/pages/Partners.jsx', '/partners', '*'],
  ['/src/pages/Certificates.jsx', '/certificates', '*'],
  ['/src/pages/News.jsx', '/news', '*'],
  ['/src/pages/Article.jsx', '/news/incoterms-2020-practical-guide', '/news/:slug'],
  ['/src/pages/Faq.jsx', '/faq', '*'],
  ['/src/pages/RequestQuote.jsx', '/request-quote', '*'],
  ['/src/pages/Contact.jsx', '/contact', '*'],
  ['/src/pages/Legal.jsx', '/privacy', '*'],
  ['/src/pages/NotFound.jsx', '/x', '*'],
]

let fail = 0
const { LanguageProvider } = await vite.ssrLoadModule('/src/i18n.jsx')
for (const language of ['en', 'fa', 'ru']) {
  for (const [mod, route, pattern] of cases) {
    try {
      const { default: Page } = await vite.ssrLoadModule(mod)
      const element = mod.includes('Legal.jsx') ? React.createElement(Page, { page: 'privacy' }) : React.createElement(Page)
      const html = renderToString(
        React.createElement(
          LanguageProvider,
          { initialLanguage: language },
          React.createElement(
            MemoryRouter,
            { initialEntries: [route] },
            React.createElement(Routes, null, React.createElement(Route, { path: pattern, element })),
          ),
        ),
      )
      const ok = html.length > 800
      console.log(`${ok ? 'OK ' : '?? '} ${language} ${route.padEnd(40)} ${String(html.length).padStart(6)} chars`)
      if (!ok) fail++
    } catch (e) {
      fail++
      console.log(`ERR ${language} ${route}: ${e.message}`)
      console.log(e.stack?.split('\n').slice(0, 5).join('\n'))
    }
  }
}
await vite.close()
console.log(fail === 0 ? '\nALL PAGES RENDER CLEANLY' : `\n${fail} PAGE(S) FAILED`)
process.exit(fail === 0 ? 0 : 1)
