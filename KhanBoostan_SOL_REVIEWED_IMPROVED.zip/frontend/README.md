# Khan Boostan Limited — Multilingual Trade Website

A responsive corporate website for Khan Boostan Limited, built with React 18, Vite, Tailwind CSS, Framer Motion and Lucide icons.

## Included in this release

- English, Persian/Dari and Russian language selector
- Automatic RTL layout for Persian/Dari and LTR layout for English/Russian
- Saved language preference in the visitor's browser
- Direct Import and Export links in desktop and mobile navigation
- One unified, searchable Products page with no category filters
- Localized product, service, market, contact, quotation and legal content
- Responsive navigation, modern trade-focused home page and production-ready build in `dist/`

## Start the website

```bash
npm install
npm run dev
```

Open `http://localhost:5173`.

## Build and verify

```bash
npm run build
npm run preview
npm run smoke
```

The production output is written to `dist/`.

## Main files

- `src/i18n.jsx` — all English, Persian/Dari and Russian translations
- `src/lib/data.jsx` — company, products and core business data
- `src/components/Header.jsx` — navigation and language selector
- `src/pages/Products.jsx` — unified product list without categories
- `src/pages/service-detail.jsx` — import/export processes
- `src/components/Forms.jsx` — quotation and contact forms

## Before publishing

1. Replace the placeholder phone and WhatsApp number in `src/lib/data.jsx` and `src/components/Footer.jsx`.
2. Confirm the company email, address and website domain.
3. Connect the quotation and contact forms to an email service, API or CRM.
4. Replace any placeholder certificates, projects or partner information with verified material only.
5. Deploy the contents of `dist/` to your hosting provider.

## یادداشت فارسی

برای ویرایش ترجمه‌های فارسی، انگلیسی و روسی فایل `src/i18n.jsx` را باز کنید. شماره تماس و واتساپ فعلاً نمونه است و باید پیش از نشر با معلومات واقعی شرکت تبدیل شود. فورم‌های تماس و درخواست نرخ نیز باید به ایمیل یا سیستم CRM شرکت وصل گردند.
