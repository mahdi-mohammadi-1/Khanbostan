# Khan Boostan — Cinematic Trade Journey Rebuild

## What changed
- Home rebuilt around a scroll-driven regional trade story.
- Branded KHAN BOOSTAN truck travels Afghanistan ↔ Uzbekistan, Turkmenistan, Iran, Pakistan, Tajikistan and China.
- 2.5D map uses SVG, CSS perspective and Framer Motion to avoid a heavy WebGL dependency on mobile.
- Direct navigation remains available at all times; the animation never replaces the business website.
- `prefers-reduced-motion` is supported.

## CMS ownership
The database is the source of truth for business content.
- `trade-corridors`: controls which country corridors are active and their order.
- `home-stories`: controls the six cinematic story panels, links and localized copy.
- Products/services continue to come from Laravel `/api/site/bootstrap`.
- Admin supports add, edit, delete, active/inactive and sort order for the new content types.

## Seed
From `/backend` after configuring MySQL in `.env`:

```bash
php artisan migrate:fresh --seed
php artisan serve
```

## Frontend
From `/frontend`:

```bash
npm install
npm run check
npm run dev
```

The frontend remains JavaScript/JSX only. No TypeScript was introduced.

## ECC-aligned review
Project-local workflow and reviewer agent instructions live under `.ecc/` and `.codex/agents/` and focus on exploration, UI review, mobile performance, security and verification.
