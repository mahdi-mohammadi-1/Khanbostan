# Khan Boostan + ECC

ECC is applied as an engineering harness, not as application runtime code. The website itself remains React/Vite/Redux/Context + Laravel/MySQL.

For every substantial change use this sequence:

`explore -> plan -> test -> implement -> review -> verify`

Recommended ECC skills for this codebase include TDD, coding standards, frontend patterns, backend patterns, API design, E2E testing, security review, verification loop, documentation lookup, deep research, brand discovery/voice, market research and strategic context management.

The full ECC native Codex plugin should be installed through `.ecc/install-native-codex.*`. Project-local Codex configuration and Khan Boostan-specific agent roles are already included in this repository.
