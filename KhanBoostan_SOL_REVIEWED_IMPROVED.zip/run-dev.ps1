$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Backend = Join-Path $Root 'backend'
$Frontend = Join-Path $Root 'frontend'

if (-not (Test-Path (Join-Path $Backend '.env'))) { throw 'backend/.env is missing. Run .\setup-windows.ps1 first.' }
if (-not (Test-Path (Join-Path $Frontend '.env'))) { throw 'frontend/.env is missing. Run .\setup-windows.ps1 first.' }
if (-not (Test-Path (Join-Path $Backend 'vendor/autoload.php'))) { throw 'Backend dependencies are missing. Run .\setup-windows.ps1 first.' }
if (-not (Test-Path (Join-Path $Frontend 'node_modules'))) { throw 'Frontend dependencies are missing. Run .\setup-windows.ps1 first.' }

Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$Backend'; php artisan optimize:clear; php artisan serve --host=127.0.0.1 --port=8000"
Start-Sleep -Seconds 2
Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$Frontend'; npm run dev -- --host 127.0.0.1 --port 5173"

Write-Host 'Backend:  http://127.0.0.1:8000' -ForegroundColor Green
Write-Host 'API:      http://127.0.0.1:8000/api/site/bootstrap' -ForegroundColor Green
Write-Host 'Frontend: http://127.0.0.1:5173' -ForegroundColor Green
Write-Host 'Admin:    http://127.0.0.1:5173/admin/login' -ForegroundColor Green
Write-Host 'Default local admin (unless changed during setup): admin@khanboostan.local / KhanBoostan@2026' -ForegroundColor Yellow
